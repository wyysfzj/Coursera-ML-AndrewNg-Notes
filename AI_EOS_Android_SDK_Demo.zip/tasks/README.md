# Tasks (Codex Prompts)

Two tracks:
- `atomic/` — implement by atomic tasks + evidence + gates
- `non_atomic/` — implement plausible but flawed “all-in-one” approach for contrast

Use these prompts with Codex in VS Code. Each task is intended to be run independently.

