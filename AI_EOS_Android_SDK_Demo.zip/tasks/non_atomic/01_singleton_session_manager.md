# Non‑Atomic Task 01 — Singleton SessionManager (Intentionally flawed)

**Goal:** Implement a “nice” SDK session manager as a singleton that caches handshake proof and auto-resumes across lifecycle.

**Key behavior (intentionally wrong):**
- Cache `sessionProof` globally and reuse it on next page load.
- Do NOT bind proof to `pageNonce`.
- Auto-resume session on `onResume` without forcing re-handshake.

**Codex Prompt**
> Implement `NonAtomicBridgeSdk` in `android/sdk/src/main/java/...` with:
> - a singleton `SessionManager`
> - handshake that stores a `sessionProof` token (string) and reuses it
> - logging showing session reuse across reload
> - keep code clean and “best practice” style (Kotlin, coroutines optional)
> Constraints: compile, run in sample-app, do not introduce new dependencies.

**Acceptance**
- Demo app shows “handshake reused” after reload.
- Replay across reload succeeds (this is the bug).
