# Atomic Task 02 — PageNonce binding (anti-replay)

**Goal:** Ensure `bridge_ready` proof structurally binds `pageNonce`.

**Codex Prompt**
> In `AtomicBridgeSdk`, implement handshake:
> - On `bridge_hello(origin,pageNonce)`, generate `sessionProof` that includes pageNonce + instanceId + correlationId + ts.
> - Sign proof using a demo HMAC key embedded in SDK (for teaching only).
> - On any subsequent request from page, require that the stored pageNonce hash matches.
> Add an explicit failure path `REPLAY_DETECTED` if pageNonce mismatches after reload.

**Acceptance**
- Reload the page: the old proof is rejected; app shows “re-handshake required”.
