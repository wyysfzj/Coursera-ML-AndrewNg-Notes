# Atomic Task 01 — Define invariants & evidence contract

**Goal:** Introduce explicit invariants (I1–I5) and define deterministic evidence output.

**Codex Prompt**
> In `android/sdk`, add:
> - `BridgeInvariants.kt` documenting invariants I1–I5
> - `EvidenceLogger.kt` that emits single-line evidence records:
>   - EVIDENCE_HANDSHAKE_START
>   - EVIDENCE_HANDSHAKE_READY
>   - EVIDENCE_PROOF_FIELDS
>   - EVIDENCE_LIFECYCLE_LOCK/UNLOCK
> Each record must be stable, machine-readable, and include: correlationId, webViewInstanceId, and hashed(pageNonce).
> Do not change sample-app behavior yet.

**Acceptance**
- App logs include evidence lines when atomic implementation is used.
