# Security Invariants (Lecture 02)

The bridge is only “secure” if **all** invariants hold.

## I1 — PageNonce Binding (anti-replay)
- `bridge_ready.sessionProof` MUST cryptographically bind the **pageNonce** received in `bridge_hello`.
- A proof from a previous page instance must be invalid for a new page instance.

## I2 — Origin + Top-Level Context Binding
- The SDK must bind session to:
  - verified page origin (host allow-list)
  - the current WebView instance identity (instanceId)
  - the current host Activity lifecycle epoch (foreground session)

## I3 — One active bridge session per WebView instance
- No global singleton session that can be “reused” across pages.
- A WebView reload is a new page instance => new handshake.

## I4 — Deterministic lifecycle policy
- Background => content protected (blur/overlay) and bridge locked.
- Foreground after threshold => re-handshake or re-auth gate (configurable).

## I5 — No silent auto-resume across incompatible state
- If page instance changes, cached proofs must be discarded.
- If policy changes (manifest version), resume token invalidation is mandatory (out of scope for this demo but noted).

