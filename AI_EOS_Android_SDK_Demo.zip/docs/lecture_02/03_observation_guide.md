# Observation Guide (Atomic vs Non-Atomic)

## What to do
1) Run the app with **Non-Atomic**
   - Load Demo Page
   - Tap "Send bridge_hello"
   - Tap "Request ping()"
   - Tap "Reload WebView" and repeat hello + ping
2) Switch to **Atomic**
   - Repeat the same steps
3) Use "Simulate Background → Foreground" and observe.

## What you should see

### Non-Atomic expected behavior (bad, but looks “fine”)
- After reload, the sessionProof is reused.
- Requests continue to succeed even though the page instance changed.
- This violates invariant I1/I3: proof is not bound to pageNonce + instance.

### Atomic expected behavior
- After reload, old proof becomes invalid; request fails with `REPLAY_DETECTED` or requires a new `bridge_hello`.
- After background/foreground exceeding threshold, atomic resets readiness and requires re-handshake.

## Evidence lines
Filter Logcat by tag: `AI_EOS_EVIDENCE`
You should see:
- EVIDENCE_HANDSHAKE_START
- EVIDENCE_HANDSHAKE_READY
- EVIDENCE_LIFECYCLE_LOCK/UNLOCK

