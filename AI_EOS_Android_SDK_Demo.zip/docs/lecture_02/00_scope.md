# Lecture 02 Scope

**Case:** Android SDK — WebView Bridge Session Establishment & Lifecycle Binding

We use two implementations to demonstrate why traditional story/PR-level governance fails under AI:
- a plausible, clean, “Android-best-practice” implementation that violates security invariants (Non‑Atomic)
- an invariant-first implementation decomposed into atomic tasks with deterministic gates (Atomic)

Deliverable of this lecture:
1) Atomic task decomposition
2) Failure-mode catalog (what goes wrong and why review/tests miss it)
3) Evidence model (what must be emitted / checked)
4) Gate candidates (what can be made deterministic)

