# Atomic Task Decomposition (Lecture 02)

We deliberately decompose Session Establishment into **atomic tasks** so that correctness becomes checkable.

## Task A — Define canonical handshake messages
- Input: `bridge_hello { origin, pageNonce, uiMode }`
- Output: `bridge_ready { echoed pageNonce, sessionProof }`
- Rule: `sessionProof` MUST include pageNonce, timestamp, correlationId, instanceId.

## Task B — Implement proof construction & verification
- Proof fields: `{origin, pageNonce, correlationId, instanceId, ts}`
- Signature: demo uses HMAC (for simplicity); real system uses JWS (ES256).
- Evidence: log line `EVIDENCE_PROOF_FIELDS` + hash.

## Task C — Bind proof to WebView instance + lifecycle epoch
- Store per-WebView `BridgeSession`.
- On new page load / reload: invalidate prior session.

## Task D — Enforce per-request gate
- Reject requests if:
  - handshake not completed
  - pageNonce mismatch
  - lifecycle state is backgrounded/locked

## Task E — Lifecycle control policy
- Background: lock + blur overlay
- Foreground: if `elapsed > threshold` require re-handshake

## Task F — Evidence emission
- Emit deterministic evidence lines into `artifacts/runtime_traces/*.log`
  - handshake start/end
  - nonce values (hashed)
  - session id / instance id
  - re-handshake reasons

## Task G — Negative tests (anti-cases)
- Replay `bridge_ready` after reload should fail.
- Background/foreground without re-handshake should fail if threshold exceeded.

