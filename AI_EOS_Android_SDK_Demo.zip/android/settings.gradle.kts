rootProject.name = "ai-eos-android-sdk-demo"
include(":sdk")
include(":sample-app")
