plugins {
  id("com.android.library")
  kotlin("android")
}

android {
  namespace = "com.example.aieos.sdk"
  compileSdk = 34

  defaultConfig {
    minSdk = 26
  }

  buildFeatures {
    buildConfig = true
  }

  kotlinOptions {
    jvmTarget = "17"
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }
}

dependencies {
  // no external dependencies for teaching baseline
}
