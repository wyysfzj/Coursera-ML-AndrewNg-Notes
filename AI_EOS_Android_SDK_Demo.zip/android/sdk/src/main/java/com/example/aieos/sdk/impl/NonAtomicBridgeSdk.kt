package com.example.aieos.sdk.impl

import android.app.Activity
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.example.aieos.sdk.BridgeConfig
import com.example.aieos.sdk.BridgeSdk
import com.example.aieos.sdk.EvidenceLogger
import com.example.aieos.sdk.internal.CryptoDemo
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicReference

/**
 * Intentionally flawed:
 * - Global singleton session proof reused across page reloads
 * - Proof does NOT bind pageNonce
 * - Auto-resume across lifecycle
 *
 * This is the "plausible" implementation that looks clean but violates invariants.
 */
class NonAtomicBridgeSdk : BridgeSdk {
  override val name: String = "Non-Atomic (intentionally flawed)"

  private var activity: Activity? = null
  private var webView: WebView? = null
  private var config: BridgeConfig? = null
  private val correlationId = EvidenceLogger.correlationId()
  private val webViewInstanceId = "wv-" + System.identityHashCode(this)

  private val cachedSessionProof = AtomicReference<String?>(null)

  override fun attach(activity: Activity, webView: WebView, config: BridgeConfig) {
    this.activity = activity
    this.webView = webView
    this.config = config

    webView.settings.javaScriptEnabled = true
    webView.addJavascriptInterface(BridgeJs(), "AndroidBridge")
    Log.i("AI_EOS", "Attached NonAtomicBridgeSdk cid=$correlationId")
  }

  override fun detach() {
    webView?.removeJavascriptInterface("AndroidBridge")
    webView = null
    activity = null
  }

  private inner class BridgeJs {
    @JavascriptInterface
    fun postMessage(json: String) {
      val msg = JSONObject(json)
      val type = msg.optString("type")
      when (type) {
        "bridge_hello" -> handleHello(msg)
        "request" -> handleRequest(msg)
      }
    }
  }

  private fun handleHello(msg: JSONObject) {
    val origin = msg.optString("origin")
    val pageNonce = msg.optString("pageNonce")

    // BUG: we do not bind proof to pageNonce; we reuse proof if present.
    val proof = cachedSessionProof.get() ?: run {
      val p = CryptoDemo.hmac("cid=$correlationId|origin=$origin|ts=${System.currentTimeMillis()}")
      cachedSessionProof.set(p)
      p
    }

    EvidenceLogger.handshakeStart(correlationId, webViewInstanceId, EvidenceLogger.hashNonce(pageNonce))
    EvidenceLogger.handshakeReady(correlationId, webViewInstanceId, EvidenceLogger.hashNonce(pageNonce), CryptoDemo.sha256Short(proof))

    sendToPage(JSONObject().apply {
      put("type", "bridge_ready")
      put("sessionProof", proof)
      put("note", "NonAtomic: proof may be reused across reloads (BUG)")
    })
  }

  private fun handleRequest(msg: JSONObject) {
    val reqName = msg.optString("name")
    val proof = msg.optString("sessionProof")
    // BUG: Accept any proof that matches cached proof; doesn't check pageNonce at all.
    val ok = (cachedSessionProof.get() != null && cachedSessionProof.get() == proof)
    sendToPage(JSONObject().apply {
      put("type", "response")
      put("ok", ok)
      put("name", reqName)
      put("note", if (ok) "NonAtomic: accepted" else "NonAtomic: rejected")
    })
  }

  private fun sendToPage(payload: JSONObject) {
    val js = "window.__bridge_onMessage(${JSONObject.quote(payload.toString())});"
    activity?.runOnUiThread { webView?.evaluateJavascript(js, null) }
  }
}
