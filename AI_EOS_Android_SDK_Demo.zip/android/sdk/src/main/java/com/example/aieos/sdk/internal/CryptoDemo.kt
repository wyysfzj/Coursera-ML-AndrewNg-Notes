package com.example.aieos.sdk.internal

import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Demo-only crypto. Production should use proper JWS/JWE and key mgmt.
 */
object CryptoDemo {
  private const val HMAC_ALG = "HmacSHA256"
  private val key = SecretKeySpec("DEMO_KEY_DO_NOT_USE".toByteArray(), HMAC_ALG)

  fun hmac(data: String): String {
    val mac = Mac.getInstance(HMAC_ALG)
    mac.init(key)
    return mac.doFinal(data.toByteArray()).joinToString("") { "%02x".format(it) }
  }

  fun sha256Short(data: String): String {
    val md = MessageDigest.getInstance("SHA-256")
    return md.digest(data.toByteArray()).take(8).joinToString("") { "%02x".format(it) }
  }
}
