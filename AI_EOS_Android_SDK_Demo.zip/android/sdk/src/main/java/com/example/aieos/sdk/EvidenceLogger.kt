package com.example.aieos.sdk

import android.util.Log
import java.security.MessageDigest
import java.util.UUID

object EvidenceLogger {
  private const val TAG = "AI_EOS_EVIDENCE"

  fun correlationId(): String = UUID.randomUUID().toString()

  fun hashNonce(pageNonce: String): String {
    val md = MessageDigest.getInstance("SHA-256")
    return md.digest(pageNonce.toByteArray()).take(8).joinToString("") { "%02x".format(it) }
  }

  fun e(line: String) {
    Log.i(TAG, line)
  }

  fun handshakeStart(correlationId: String, webViewInstanceId: String, pageNonceHash: String) =
    e("EVIDENCE_HANDSHAKE_START cid=$correlationId wv=$webViewInstanceId pn=$pageNonceHash")

  fun handshakeReady(correlationId: String, webViewInstanceId: String, pageNonceHash: String, proofHash: String) =
    e("EVIDENCE_HANDSHAKE_READY cid=$correlationId wv=$webViewInstanceId pn=$pageNonceHash proof=$proofHash")

  fun lifecycleLock(correlationId: String, webViewInstanceId: String, reason: String) =
    e("EVIDENCE_LIFECYCLE_LOCK cid=$correlationId wv=$webViewInstanceId reason=$reason")

  fun lifecycleUnlock(correlationId: String, webViewInstanceId: String, reason: String) =
    e("EVIDENCE_LIFECYCLE_UNLOCK cid=$correlationId wv=$webViewInstanceId reason=$reason")
}
