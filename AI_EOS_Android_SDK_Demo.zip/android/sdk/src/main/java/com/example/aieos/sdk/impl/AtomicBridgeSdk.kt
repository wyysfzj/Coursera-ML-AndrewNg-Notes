package com.example.aieos.sdk.impl

import android.app.Activity
import android.os.SystemClock
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.example.aieos.sdk.BridgeConfig
import com.example.aieos.sdk.BridgeSdk
import com.example.aieos.sdk.EvidenceLogger
import com.example.aieos.sdk.internal.CryptoDemo
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Atomic implementation (teaching-grade):
 * - Proof structurally binds pageNonce (I1)
 * - Session is per-WebView instance; reload requires re-handshake (I3)
 * - Lifecycle lock/unlock is explicit (I4)
 * - No silent auto-resume; mismatch => re-handshake required (I5)
 *
 * NOTE: Proof uses HMAC for demo only.
 */
class AtomicBridgeSdk : BridgeSdk {
  override val name: String = "Atomic (invariant-driven)"

  private var activity: Activity? = null
  private var webView: WebView? = null
  private var config: BridgeConfig? = null

  private val correlationId = EvidenceLogger.correlationId()
  private val webViewInstanceId = "wv-" + System.identityHashCode(this)

  private var currentPageNonceHash: String? = null
  private var currentProof: String? = null
  private var lastForegroundAtMs: Long = SystemClock.elapsedRealtime()

  private val ready = AtomicBoolean(false)
  private val locked = AtomicBoolean(false)

  override fun attach(activity: Activity, webView: WebView, config: BridgeConfig) {
    this.activity = activity
    this.webView = webView
    this.config = config

    webView.settings.javaScriptEnabled = true
    webView.addJavascriptInterface(BridgeJs(), "AndroidBridge")
    Log.i("AI_EOS", "Attached AtomicBridgeSdk cid=$correlationId")

    // In a real SDK this would be integrated with lifecycle callbacks
    locked.set(false)
    ready.set(false)
  }

  override fun detach() {
    webView?.removeJavascriptInterface("AndroidBridge")
    webView = null
    activity = null
  }

  /** Call from host Activity onResume to enforce policy (demo app does this). */
  fun onHostForeground() {
    val elapsed = (SystemClock.elapsedRealtime() - lastForegroundAtMs) / 1000
    lastForegroundAtMs = SystemClock.elapsedRealtime()
    if (elapsed >= (config?.reauthOnForegroundSeconds ?: 10)) {
      // Force re-handshake
      locked.set(false)
      ready.set(false)
      currentPageNonceHash = null
      currentProof = null
      EvidenceLogger.lifecycleUnlock(correlationId, webViewInstanceId, "foreground_rehandshake_required elapsed=${elapsed}s")
    }
  }

  /** Call from host Activity onPause to lock. */
  fun onHostBackground() {
    locked.set(true)
    EvidenceLogger.lifecycleLock(correlationId, webViewInstanceId, "background")
  }

  private inner class BridgeJs {
    @JavascriptInterface
    fun postMessage(json: String) {
      val msg = JSONObject(json)
      val type = msg.optString("type")
      when (type) {
        "bridge_hello" -> handleHello(msg)
        "request" -> handleRequest(msg)
      }
    }
  }

  private fun handleHello(msg: JSONObject) {
    if (locked.get()) {
      sendError("HANDSHAKE_BLOCKED", "locked_by_lifecycle")
      return
    }

    val origin = msg.optString("origin")
    val pageNonce = msg.optString("pageNonce")

    // Origin allow-list (simplified). Production should enforce https+host allow-list.
    val allowed = config?.allowedOrigins ?: setOf("file://demo")
    if (!allowed.contains(origin)) {
      sendError("ORIGIN_BLOCKED", "origin=$origin")
      return
    }

    val pnHash = EvidenceLogger.hashNonce(pageNonce)
    EvidenceLogger.handshakeStart(correlationId, webViewInstanceId, pnHash)

    // Proof MUST include pageNonce (I1)
    val proofPayload = "cid=$correlationId|origin=$origin|pn=$pnHash|wv=$webViewInstanceId|ts=${System.currentTimeMillis()}"
    val proof = CryptoDemo.hmac(proofPayload)

    currentPageNonceHash = pnHash
    currentProof = proof
    ready.set(true)

    EvidenceLogger.handshakeReady(correlationId, webViewInstanceId, pnHash, CryptoDemo.sha256Short(proof))

    sendToPage(JSONObject().apply {
      put("type", "bridge_ready")
      put("sessionProof", proof)
      put("pageNonceHash", pnHash)
      put("note", "Atomic: proof binds pageNonceHash; reload requires new hello")
    })
  }

  private fun handleRequest(msg: JSONObject) {
    if (locked.get()) {
      sendError("REQUEST_BLOCKED", "locked_by_lifecycle")
      return
    }
    if (!ready.get()) {
      sendError("HANDSHAKE_REQUIRED", "call bridge_hello first")
      return
    }
    val reqName = msg.optString("name")
    val proof = msg.optString("sessionProof")

    val ok = (currentProof != null && currentProof == proof)
    if (!ok) {
      // Replay / mismatch
      sendError("REPLAY_DETECTED", "proof_mismatch_requires_rehandshake")
      ready.set(false)
      currentProof = null
      currentPageNonceHash = null
      return
    }

    sendToPage(JSONObject().apply {
      put("type", "response")
      put("ok", true)
      put("name", reqName)
      put("note", "Atomic: accepted")
    })
  }

  private fun sendError(code: String, message: String) {
    sendToPage(JSONObject().apply {
      put("type", "error")
      put("code", code)
      put("message", message)
    })
  }

  private fun sendToPage(payload: JSONObject) {
    val js = "window.__bridge_onMessage(${JSONObject.quote(payload.toString())});"
    activity?.runOnUiThread { webView?.evaluateJavascript(js, null) }
  }
}
