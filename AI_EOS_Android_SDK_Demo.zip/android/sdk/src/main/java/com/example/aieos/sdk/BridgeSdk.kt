package com.example.aieos.sdk

import android.app.Activity
import android.webkit.WebView

/**
 * Single, stable SDK entry surface for the demo.
 * The app chooses an implementation (Atomic vs Non-Atomic) at runtime.
 */
interface BridgeSdk {
  val name: String
  fun attach(activity: Activity, webView: WebView, config: BridgeConfig)
  fun detach()
}

data class BridgeConfig(
  val allowedOrigins: Set<String> = setOf("file://demo"),
  val reauthOnForegroundSeconds: Long = 10,
)
