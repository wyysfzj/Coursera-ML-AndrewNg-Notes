package com.example.aieos.sdk

/**
 * Lecture 02 Invariants (reference only — enforced by AtomicBridgeSdk)
 *
 * I1 PageNonce Binding: proof MUST include pageNonce (anti-replay).
 * I2 Origin + Context Binding: bind to verified origin + WebView instance + lifecycle epoch.
 * I3 One active session per WebView instance (no global reuse).
 * I4 Deterministic lifecycle policy: background locks, foreground may require re-handshake.
 * I5 No silent auto-resume across incompatible state.
 */
object BridgeInvariants
