package com.example.aieos.sample

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.aieos.sample.databinding.ActivityMainBinding
import com.example.aieos.sdk.BridgeConfig
import com.example.aieos.sdk.BridgeSdk
import com.example.aieos.sdk.impl.AtomicBridgeSdk
import com.example.aieos.sdk.impl.NonAtomicBridgeSdk

class MainActivity : AppCompatActivity() {

  private lateinit var b: ActivityMainBinding
  private var sdk: BridgeSdk? = null
  private var atomicSdk: AtomicBridgeSdk? = null

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    b = ActivityMainBinding.inflate(layoutInflater)
    setContentView(b.root)

    b.btnLoad.setOnClickListener { loadDemoPage() }
    b.btnReload.setOnClickListener { b.webView.reload(); b.status.text = "Status: reloaded" }
    b.btnSimBgFg.setOnClickListener { simulateBgFg() }
    b.toggleAtomic.setOnCheckedChangeListener { _, _ -> attachSdk() }

    attachSdk()
  }

  override fun onResume() {
    super.onResume()
    atomicSdk?.onHostForeground()
  }

  override fun onPause() {
    atomicSdk?.onHostBackground()
    super.onPause()
  }

  private fun attachSdk() {
    sdk?.detach()
    atomicSdk = null

    val useAtomic = b.toggleAtomic.isChecked
    val impl: BridgeSdk = if (useAtomic) AtomicBridgeSdk().also { atomicSdk = it } else NonAtomicBridgeSdk()

    val cfg = BridgeConfig(
      allowedOrigins = setOf("file://demo"),
      reauthOnForegroundSeconds = 2 // small to demo quickly
    )
    impl.attach(this, b.webView, cfg)
    sdk = impl
    b.status.text = "Status: attached -> ${impl.name}"
  }

  private fun loadDemoPage() {
    val html = assets.open("bridge_demo.html").bufferedReader().use { it.readText() }
    b.webView.loadDataWithBaseURL("file://demo", html, "text/html", "utf-8", null)
    b.status.text = "Status: page loaded (${sdk?.name})"
  }

  private fun simulateBgFg() {
    // Demo: call background then foreground quickly; Atomic uses threshold to force re-handshake.
    atomicSdk?.onHostBackground()
    b.webView.postDelayed({
      atomicSdk?.onHostForeground()
      b.status.text = "Status: simulated bg→fg; observe whether re-handshake required"
    }, 2500)
  }
}
