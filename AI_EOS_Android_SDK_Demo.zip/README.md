# AI‑EOS Android SDK Demo (WebView Bridge Session Establishment & Lifecycle Binding)

This repo is a **teaching + experimentation project** for AI‑EOS Lecture 02:
**Atomic vs Non‑Atomic implementation** of WebView Bridge *Session Establishment & Lifecycle Binding* in an Android SDK.

## What you get
- `android/` — a runnable Android Studio/Gradle project (Kotlin)
  - `sdk/` — SDK library module exposing a single `BridgeSdk` API with **two implementations**
    - `NonAtomicBridgeSdk` — intentionally flawed “looks good” implementation
    - `AtomicBridgeSdk` — atomic-task, invariant-driven implementation
  - `sample-app/` — demo app to switch implementations at runtime and observe behavior
- `docs/` — lecture notes, invariants, failure modes, and “what to look for”
- `tasks/` — Codex prompts (Atomic & Non‑Atomic tracks) aligned to AI‑EOS
- `artifacts/` — demo HTML pages, golden traces, expected outputs

## Quick start
1) Open folder `android/` in Android Studio (recommended) or VS Code (Gradle).
2) Run the `sample-app` configuration on an emulator/device (minSdk 26).
3) In the app:
   - Choose **Non‑Atomic** or **Atomic**
   - Tap **Load Demo Page**
   - Observe:
     - handshake logs
     - lifecycle resume behavior
     - replay/mismatch detection
     - evidence output (trace lines)

## Key observation goal
- **Non‑Atomic**: “works” but allows replay/mismatch across lifecycle and page instances.
- **Atomic**: enforces deterministic invariants (pageNonce binding, per-page session, lifecycle re-auth policy).

> This is a demo. Do not use it as-is in production.

