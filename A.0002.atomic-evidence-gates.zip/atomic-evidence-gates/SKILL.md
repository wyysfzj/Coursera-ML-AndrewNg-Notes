---
name: atomic-evidence-gates
description: Use when executing, reviewing, or writing implementation tasks that must remain atomic, produce audit evidence, pass task gates, or coordinate one-task-per-agent work across Python, Go, Java/Spring Boot, Vue, or React projects.
---

# Atomic Evidence Gates

Use this skill to keep implementation work constrained to one explicit atomic task and to make completion claims depend on evidence artifacts plus gate checks.

## Non-Negotiable Start Gate

Before editing code, establish one of these inputs:

- One exact task file path for single-task execution.
- An explicit batch manifest with one exact task file path per execution agent.

If neither exists, stop and ask for one task file path or create a planning-only manifest. Do not implement from a broad plan, module name, feature request, or issue summary.

Read `references/atomic-task-discipline.md` when the task file or batch shape is unclear. Run:

```bash
python3 <skill-dir>/scripts/evidence_gate.py check-task <task-file>
```

## Execution Flow

1. Freeze the closure slice from the task file: exact behavior closed, explicit non-closure boundary, allowed files, verification commands, and follow-up task IDs.
2. Initialize evidence before edits:

```bash
python3 <skill-dir>/scripts/evidence_gate.py init <TASK-ID> --task-file <task-file> --allowlist <path> --allowlist <path>
```

3. Edit only files allowed by the task. If a new prerequisite, shared ownership conflict, or second closure slice appears, stop and split or replan.
4. Run checks through the evidence wrapper:

```bash
python3 <skill-dir>/scripts/evidence_gate.py run <TASK-ID> lint -- <lint command...>
python3 <skill-dir>/scripts/evidence_gate.py run <TASK-ID> test -- <test command...>
```

5. Finalize and validate evidence:

```bash
python3 <skill-dir>/scripts/evidence_gate.py finalize <TASK-ID> --status PASS
python3 <skill-dir>/scripts/evidence_gate.py validate <TASK-ID>
```

Read `references/evidence-gates.md` for artifact requirements, dirty-worktree baseline rules, and command matrices for Python, Go, Java/Spring Boot, Vue, and React.

## Gate Rules

- PASS requires `artifacts/<TASK-ID>/results.jsonl`, `summary.md`, `git/diff.patch`, required step results with `rc:0`, and dirty-baseline files when the task started dirty.
- FAIL and BLOCKED may have partial evidence, but any available logs must remain attached.
- Do not claim PASS until verification has run, evidence exists, scope compliance was checked, and no second closure slice was absorbed.
- In multi-agent runs, serialize edits to shared ownership files and validate each task independently.

## Output Contract

End every execution with:

- Task/runbook executed and executor role.
- Modified files.
- Verification commands and observed status.
- Evidence path under `artifacts/<TASK-ID>/`.
- Final status: PASS, FAIL, or BLOCKED.
- Exact closure slice completed.
- Explicit non-closure boundary respected.

For batch coordination, also report agent-to-task mapping, wave order, serialized shared-file decisions, and per-task summaries.
