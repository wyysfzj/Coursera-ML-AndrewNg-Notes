#!/usr/bin/env python3
"""Evidence-backed task gate helper.

This script is intentionally stack-neutral and stdlib-only. It records command
execution as JSONL, captures logs, writes git evidence, validates task evidence,
and gives starter commands for common stacks.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime
import fnmatch
import json
from pathlib import Path
import shlex
import subprocess
import sys
from typing import Iterable, Sequence


DEFAULT_REQUIRED_STEPS = ("lint", "test")

STACK_COMMANDS: dict[str, dict[str, list[str]]] = {
    "python": {
        "lint": [
            "ruff check --fix <allowlist-files>",
            "ruff format <allowlist-files>",
            "ruff check <allowlist-files>",
        ],
        "test": ["pytest <targeted-tests> -q"],
        "build_or_smoke": ["python -m py_compile <python-files>", "<api-or-ui-smoke-command>"],
    },
    "go": {
        "lint": ["gofmt -w <go-files>", "go vet <package-or-./...>"],
        "test": ["go test <package-or-./...>"],
        "build_or_smoke": ["go test <package> -run <smoke-test>", "<service-smoke-command>"],
    },
    "spring-boot": {
        "lint": ["./mvnw -q -DskipTests compile", "./gradlew compileJava"],
        "test": ["./mvnw test", "./gradlew test"],
        "build_or_smoke": ["./mvnw verify", "./gradlew check", "<endpoint-smoke-command>"],
    },
    "vue": {
        "lint": ["npm run lint -- <files>", "npm run typecheck"],
        "test": ["npm run test:unit -- <target>", "npm test -- <target>"],
        "build_or_smoke": ["npm run build", "npx playwright test <target>"],
    },
    "react": {
        "lint": ["npm run lint -- <files>", "npm run typecheck"],
        "test": ["npm test -- --runInBand", "npm run test -- <target>"],
        "build_or_smoke": ["npm run build", "npx playwright test <target>"],
    },
}

STACK_ALIASES = {
    "java": "spring-boot",
    "spring": "spring-boot",
    "springboot": "spring-boot",
    "recat": "react",
}

PROHIBITED_TASK_TEXT = (
    "if you want",
    "optionally",
    "you may choose",
    "ask me to add",
    "etc.",
    "and so on",
    "close the remaining module",
    "finish the whole chain",
    "complete backend/frontend parity",
    "close the remaining feasible scope",
)

REQUIRED_TASK_HEADINGS = (
    "Exact Closure Slice",
    "Explicit Non-Closure",
    "Remaining Follow-Up Task IDs",
    "Allowed Files",
    "Verification Commands",
    "Evidence Path",
)


@dataclass(frozen=True)
class CommandResult:
    rc: int
    stdout: str
    stderr: str


def timestamp() -> str:
    return datetime.now().strftime("%Y%m%dT%H%M%S")


def run_process(argv: Sequence[str], cwd: Path | None = None) -> CommandResult:
    proc = subprocess.run(
        list(argv),
        cwd=str(cwd) if cwd else None,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    return CommandResult(proc.returncode, proc.stdout, proc.stderr)


def repo_root() -> Path:
    result = run_process(("git", "rev-parse", "--show-toplevel"))
    if result.rc == 0 and result.stdout.strip():
        return Path(result.stdout.strip())
    return Path.cwd()


def git(args: Sequence[str], root: Path) -> CommandResult:
    return run_process(("git", *args), cwd=root)


def artifact_dir(root: Path, task_id: str) -> Path:
    return root / "artifacts" / task_id


def append_jsonl(path: Path, record: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")


def read_jsonl(path: Path) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    if not path.exists():
        return records
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{line_no}: invalid JSONL: {exc}") from exc
    return records


def normalize_path(path: str, root: Path) -> str:
    raw = Path(path)
    try:
        if raw.is_absolute():
            return raw.resolve().relative_to(root).as_posix()
    except ValueError:
        return raw.as_posix()
    return raw.as_posix().lstrip("./")


def parse_status_paths(status_text: str) -> list[str]:
    paths: list[str] = []
    for line in status_text.splitlines():
        if not line:
            continue
        path = line[3:]
        if " -> " in path:
            path = path.split(" -> ", 1)[1]
        paths.append(path)
    return paths


def is_allowed(path: str, allowlist: Iterable[str], task_id: str) -> bool:
    if path == "artifacts/" or path.startswith(f"artifacts/{task_id}/"):
        return True
    for pattern in allowlist:
        normalized = pattern.rstrip("/")
        if normalized.endswith("/**"):
            prefix = normalized[:-3].rstrip("/")
            if path == prefix or path.startswith(prefix + "/"):
                return True
        if path == normalized or path.startswith(normalized + "/"):
            return True
        if fnmatch.fnmatch(path, pattern):
            return True
    return False


def load_task_meta(art_dir: Path) -> dict[str, object]:
    meta_path = art_dir / "task.json"
    if not meta_path.exists():
        return {}
    return json.loads(meta_path.read_text(encoding="utf-8"))


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def command_as_string(argv: Sequence[str]) -> str:
    return " ".join(shlex.quote(part) for part in argv)


def cmd_init(args: argparse.Namespace) -> int:
    root = repo_root()
    task_id = args.task_id
    art_dir = artifact_dir(root, task_id)
    task_file = normalize_path(args.task_file, root)
    allowlist = [normalize_path(path, root) for path in args.allowlist]

    status_before = git(("status", "--porcelain"), root)
    dirty_paths = parse_status_paths(status_before.stdout) if status_before.rc == 0 else []
    baseline_dirty = bool(dirty_paths)

    art_dir.mkdir(parents=True, exist_ok=True)
    (art_dir / "outputs").mkdir(exist_ok=True)
    (art_dir / "git").mkdir(exist_ok=True)
    (art_dir / "commands.jsonl").touch(exist_ok=True)
    (art_dir / "results.jsonl").touch(exist_ok=True)

    meta = {
        "task_id": task_id,
        "task_file": task_file,
        "allowlist": allowlist,
        "init_ts": timestamp(),
        "baseline_dirty": baseline_dirty,
        "repo_root": root.as_posix(),
    }
    write_text(art_dir / "task.json", json.dumps(meta, ensure_ascii=False, indent=2) + "\n")

    if baseline_dirty:
        diff_parts: list[str] = []
        if allowlist:
            unstaged = git(("diff", "--", *allowlist), root)
            staged = git(("diff", "--cached", "--", *allowlist), root)
            diff_parts.extend(part for part in (unstaged.stdout, staged.stdout) if part)
        write_text(art_dir / "baseline_allowlist.diff", "\n".join(diff_parts))
        external = [
            path
            for path in dirty_paths
            if not is_allowed(path, allowlist, task_id)
        ]
        write_text(
            art_dir / "baseline_external_files.txt",
            "\n".join(sorted(external)) + ("\n" if external else ""),
        )

    print(f"Initialized evidence at {art_dir.relative_to(root)}")
    if baseline_dirty:
        print("Dirty baseline captured.")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    root = repo_root()
    task_id = args.task_id
    art_dir = artifact_dir(root, task_id)
    art_dir.mkdir(parents=True, exist_ok=True)
    (art_dir / "outputs").mkdir(exist_ok=True)

    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        print("Missing command after --", file=sys.stderr)
        return 2

    ts = timestamp()
    step = args.step
    log_path = art_dir / "outputs" / f"{ts}_{step}.log"
    cwd = Path(args.cwd).resolve() if args.cwd else root

    append_jsonl(
        art_dir / "commands.jsonl",
        {
            "ts": ts,
            "step": step,
            "cwd": cwd.as_posix(),
            "cmd": command_as_string(command),
        },
    )

    proc = subprocess.run(
        command,
        cwd=str(cwd),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    write_text(log_path, proc.stdout)
    append_jsonl(
        art_dir / "results.jsonl",
        {
            "ts": ts,
            "step": step,
            "rc": proc.returncode,
            "log": log_path.relative_to(root).as_posix(),
        },
    )

    if proc.returncode != 0:
        print(f"Command failed with rc={proc.returncode}. See {log_path.relative_to(root)}")
    else:
        print(f"Command passed. See {log_path.relative_to(root)}")
    return proc.returncode


def cmd_finalize(args: argparse.Namespace) -> int:
    root = repo_root()
    task_id = args.task_id
    art_dir = artifact_dir(root, task_id)
    git_dir = art_dir / "git"
    git_dir.mkdir(parents=True, exist_ok=True)

    diff = git(("diff",), root)
    staged = git(("diff", "--cached"), root)
    write_text(git_dir / "diff.patch", (diff.stdout or "") + (staged.stdout or ""))
    write_text(git_dir / "status.txt", git(("status", "-sb"), root).stdout)
    rev = git(("rev-parse", "HEAD"), root)
    write_text(git_dir / "rev.txt", rev.stdout if rev.rc == 0 else "unknown\n")

    summary_path = art_dir / "summary.md"
    if args.summary_file:
        summary_source = Path(args.summary_file)
        summary_text = summary_source.read_text(encoding="utf-8")
    elif summary_path.exists():
        summary_text = summary_path.read_text(encoding="utf-8")
    else:
        notes = args.notes or ""
        summary_text = (
            f"# {task_id} Summary\n\n"
            "## Status\n"
            f"- Final status: {args.status}\n\n"
            "## Task\n"
            "- Role: \n"
            "- Runbook: \n"
            "- Closure slice: \n"
            "- Non-closure boundary: \n\n"
            "## Modified Files\n"
            "- \n\n"
            "## Verification\n"
            "- \n\n"
            "## Scope Compliance\n"
            "- \n\n"
            "## Notes\n"
            f"- {notes}\n"
        )
    write_text(summary_path, summary_text)
    print(f"Finalized evidence at {art_dir.relative_to(root)}")
    return 0


def validate_required_files(art_dir: Path, required: list[str]) -> list[str]:
    missing: list[str] = []
    for rel in required:
        if not (art_dir / rel).exists():
            missing.append(rel)
    return missing


def cmd_validate(args: argparse.Namespace) -> int:
    root = repo_root()
    task_id = args.task_id
    art_dir = artifact_dir(root, task_id)
    if not art_dir.exists():
        print(f"Missing artifacts/{task_id}", file=sys.stderr)
        return 1

    required_files = ["summary.md", "results.jsonl", "git/diff.patch"]
    missing = validate_required_files(art_dir, required_files)
    if missing:
        print("Missing required evidence: " + ", ".join(missing), file=sys.stderr)
        return 1

    meta = load_task_meta(art_dir)
    if meta.get("baseline_dirty") is True:
        dirty_missing = validate_required_files(
            art_dir,
            ["baseline_allowlist.diff", "baseline_external_files.txt"],
        )
        if dirty_missing:
            print(
                "Missing dirty-baseline evidence: " + ", ".join(dirty_missing),
                file=sys.stderr,
            )
            return 1

    try:
        results = read_jsonl(art_dir / "results.jsonl")
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    required_steps = args.required_step or list(DEFAULT_REQUIRED_STEPS)
    missing_steps: list[str] = []
    for step in required_steps:
        if not any(record.get("step") == step and record.get("rc") == 0 for record in results):
            missing_steps.append(step)
    if missing_steps:
        print(
            "Missing successful required steps: " + ", ".join(missing_steps),
            file=sys.stderr,
        )
        return 1

    allowlist = [str(path) for path in meta.get("allowlist", [])]
    baseline_external_path = art_dir / "baseline_external_files.txt"
    baseline_external = set()
    if baseline_external_path.exists():
        baseline_external = {
            line.strip()
            for line in baseline_external_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        }
    status = git(("status", "--porcelain"), root)
    if status.rc == 0 and allowlist:
        dirty_paths = parse_status_paths(status.stdout)
        new_external = sorted(
            path
            for path in dirty_paths
            if not is_allowed(path, allowlist, task_id) and path not in baseline_external
        )
        if new_external:
            print(
                "Dirty files outside task allowlist appeared after init: "
                + ", ".join(new_external),
                file=sys.stderr,
            )
            return 1

    print("Task Gate PASS")
    return 0


def heading_exists(text: str, heading: str) -> bool:
    needles = {f"# {heading}", f"## {heading}", f"### {heading}"}
    return any(line.strip() in needles for line in text.splitlines())


def cmd_check_task(args: argparse.Namespace) -> int:
    task_path = Path(args.task_file)
    if not task_path.exists():
        print(f"Task file not found: {task_path}", file=sys.stderr)
        return 2
    text = task_path.read_text(encoding="utf-8")
    lower_text = text.lower()

    failures: list[str] = []
    for phrase in PROHIBITED_TASK_TEXT:
        if phrase in lower_text:
            failures.append(f"prohibited broad or conditional phrase: {phrase}")
    for heading in REQUIRED_TASK_HEADINGS:
        if not heading_exists(text, heading):
            failures.append(f"missing required heading: {heading}")

    if "None" not in text and "Remaining Follow-Up Task IDs" in text:
        print("Warning: follow-up task IDs are present but no explicit `None` marker was found.")

    if failures:
        print("Atomic task check FAIL", file=sys.stderr)
        for failure in failures:
            print(f"- {failure}", file=sys.stderr)
        return 1

    print("Atomic task check PASS")
    return 0


def detect_stacks(root: Path) -> list[str]:
    stacks: list[str] = []
    if any((root / name).exists() for name in ("pyproject.toml", "requirements.txt", "setup.py")):
        stacks.append("python")
    if (root / "go.mod").exists():
        stacks.append("go")
    if any((root / name).exists() for name in ("pom.xml", "mvnw", "build.gradle", "gradlew")):
        stacks.append("spring-boot")
    package_json = root / "package.json"
    if package_json.exists():
        text = package_json.read_text(encoding="utf-8", errors="ignore").lower()
        if "vue" in text:
            stacks.append("vue")
        if "react" in text:
            stacks.append("react")
    frontend_pkg = root / "frontend" / "package.json"
    if frontend_pkg.exists():
        text = frontend_pkg.read_text(encoding="utf-8", errors="ignore").lower()
        if "vue" in text and "vue" not in stacks:
            stacks.append("vue")
        if "react" in text and "react" not in stacks:
            stacks.append("react")
    return stacks


def print_stack_commands(stack: str) -> None:
    commands = STACK_COMMANDS[stack]
    print(f"# {stack}")
    for step, values in commands.items():
        print(f"## {step}")
        for command in values:
            print(f"- {command}")


def cmd_commands(args: argparse.Namespace) -> int:
    root = repo_root()
    raw_stack = args.stack.lower()
    stack = STACK_ALIASES.get(raw_stack, raw_stack)
    if stack == "auto":
        detected = detect_stacks(root)
        if not detected:
            print("No stack detected. Use --stack python|go|spring-boot|vue|react.")
            return 1
        for item in detected:
            print_stack_commands(item)
        return 0
    if stack not in STACK_COMMANDS:
        print(f"Unsupported stack: {args.stack}", file=sys.stderr)
        return 2
    print_stack_commands(stack)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Atomic task evidence gate helper")
    sub = parser.add_subparsers(dest="command_name", required=True)

    init = sub.add_parser("init", help="initialize artifacts/<TASK-ID>")
    init.add_argument("task_id")
    init.add_argument("--task-file", required=True)
    init.add_argument("--allowlist", action="append", default=[], help="allowed file/path/glob")
    init.set_defaults(func=cmd_init)

    run = sub.add_parser("run", help="run a command and capture evidence")
    run.add_argument("task_id")
    run.add_argument("step")
    run.add_argument("--cwd", help="working directory for the command")
    run.add_argument("command", nargs=argparse.REMAINDER)
    run.set_defaults(func=cmd_run)

    finalize = sub.add_parser("finalize", help="write git evidence and summary skeleton")
    finalize.add_argument("task_id")
    finalize.add_argument("--status", choices=("PASS", "FAIL", "BLOCKED"), required=True)
    finalize.add_argument("--summary-file")
    finalize.add_argument("--notes")
    finalize.set_defaults(func=cmd_finalize)

    validate = sub.add_parser("validate", help="validate required evidence and gate results")
    validate.add_argument("task_id")
    validate.add_argument("--required-step", action="append", help="required successful step")
    validate.set_defaults(func=cmd_validate)

    check_task = sub.add_parser("check-task", help="validate atomic task markdown shape")
    check_task.add_argument("task_file")
    check_task.set_defaults(func=cmd_check_task)

    commands = sub.add_parser("commands", help="print recommended commands by stack")
    commands.add_argument("--stack", default="auto")
    commands.set_defaults(func=cmd_commands)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
