# Atomic Task Discipline

## Required Input

Execution starts only from:

- One exact task file path, or
- A batch manifest where each row assigns exactly one task file path to one agent.

Without that input, remain in planning mode. Do not implement from a module name, backlog item, broad plan, or partial acceptance note.

## Atomic Task Acceptance

A ready task file must state:

- Exact closure slice: the single behavior, endpoint, service rule, page capability, query, doc change, or QA audit it closes.
- Explicit non-closure: what is excluded.
- Remaining follow-up task IDs, or `None`.
- Allowed files.
- Required verification.
- Evidence path.

Reject or rewrite a task that uses broad wording such as:

- close the remaining module
- finish the whole chain
- complete backend/frontend parity
- close the remaining feasible scope

## Legacy Atomic Writing Standard

When writing a new atomic task from scratch, include these sections in order:

1. Title with task ID and concrete responsibility.
2. Design references with real source-of-truth paths.
3. Target with exactly one atomic anchor file where the task definition requires it.
4. Scope decision marked FIXED and explicitly denying expansion.
5. Exact models, APIs, components, fields, behavior, and response/status expectations.
6. Non-scope with explicit exclusions.
7. Prompt requiring exact implementation, no optional behavior, and no clarification questions.

Avoid conditional language:

- if you want
- optionally
- you may choose
- ask me to add
- audit fields without enumeration
- etc.
- and so on

## Multi-Agent Rules

- One execution agent owns one task file path.
- Two agents must not concurrently edit the same task file or shared ownership file.
- Shared ownership files require serialization, including router wiring, shared schemas, permission registries, common exports, frontend API clients, route registries, shared stores, and shared constants.
- If a task discovers a new prerequisite, shared ownership conflict, or unreachable state transition, stop and replan. Do not stretch the current closure slice.

## Story Shape and Runbook

For written specs, implementation plans, batch manifests, multi-task work, or multi-wave execution, record:

- `shared_file_density`
- `prereq_dependency_density`
- `be_fe_coupling`
- `evidence_cost`
- `chosen_runbook`

Valid runbooks:

- `P0-single-lane-story`
- `P0-prereq-heavy-story`
- `P0-multi-lane-parallel-story`
- `P0-frontend-heavy-story`

Do not start execution until classification and runbook are recorded in both the spec and plan.

## Scope Review Checklist

Before PASS:

- The task file answers what exact behavior is closed.
- Every modified source file is in the allowed files list.
- No unrelated refactor, second endpoint, second service rule, or extra UI capability was added.
- Shared ownership files were serialized.
- Verification commands match the task and the technology stack.
- Evidence gate passes for this task ID.
