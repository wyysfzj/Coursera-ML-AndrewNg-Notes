# Evidence-Backed Gate-Controlled Execution

## Artifact Layout

Use one evidence directory per task:

```text
artifacts/<TASK-ID>/
  commands.jsonl
  results.jsonl
  summary.md
  git/
    diff.patch
    status.txt
    rev.txt
  outputs/
    <timestamp>_<step>.log
  baseline_allowlist.diff          # required when task started dirty
  baseline_external_files.txt      # required when task started dirty
```

Do not store secrets, tokens, credentials, or PII in logs. Redact command arguments when needed before running evidence capture.

## Required PASS Evidence

PASS requires:

- `results.jsonl` with required step records and `rc:0`.
- `summary.md` explaining commands, results, closure slice, non-closure boundary, and scope compliance.
- `git/diff.patch` scoped to the task result.
- Dirty baseline files when `init` recorded a dirty worktree.
- A successful task gate validation.

FAIL and BLOCKED may have partial evidence. Attach what exists and state the blocker precisely.

## Script Usage

`scripts/evidence_gate.py` is stack-neutral and uses only Python standard library.

Initialize evidence:

```bash
python3 <skill-dir>/scripts/evidence_gate.py init <TASK-ID> \
  --task-file tasks/backend/BE-API-001.md \
  --allowlist backend/app/modules/cases/api.py \
  --allowlist backend/tests/test_cases_api.py
```

Run checks:

```bash
python3 <skill-dir>/scripts/evidence_gate.py run <TASK-ID> lint -- ruff check backend/app/modules/cases/api.py
python3 <skill-dir>/scripts/evidence_gate.py run <TASK-ID> test -- pytest backend/tests/test_cases_api.py -q
```

Finalize and validate:

```bash
python3 <skill-dir>/scripts/evidence_gate.py finalize <TASK-ID> --status PASS --notes "Targeted lint and tests passed."
python3 <skill-dir>/scripts/evidence_gate.py validate <TASK-ID>
```

Inspect suggested commands:

```bash
python3 <skill-dir>/scripts/evidence_gate.py commands --stack python
python3 <skill-dir>/scripts/evidence_gate.py commands --stack go
python3 <skill-dir>/scripts/evidence_gate.py commands --stack spring-boot
python3 <skill-dir>/scripts/evidence_gate.py commands --stack vue
python3 <skill-dir>/scripts/evidence_gate.py commands --stack react
```

## Stack Command Matrix

Choose task-scoped commands first. Run full repo commands only when the task, runbook, or batch close requires them.

| Stack | Lint/Format Step | Test Step | Build/Smoke Step |
| --- | --- | --- | --- |
| Python | `ruff check --fix <files>`, `ruff format <files>`, `ruff check <files>` | `pytest <target> -q` | framework smoke, e.g. curl or Playwright |
| Go | `gofmt -w <files>`, `go vet ./...` or package-scoped vet | `go test ./...` or package-scoped tests | service smoke or `go test` integration tags |
| Java/Spring Boot | `./mvnw -q -DskipTests compile` or `./gradlew compileJava` | `./mvnw test` or `./gradlew test` | `./mvnw verify`, `./gradlew check`, or endpoint smoke |
| Vue | `npm run lint -- <files>` when supported, or project lint | `npm run test:unit -- <target>` when supported | `npm run typecheck`, `npm run build`, Playwright smoke |
| React | `npm run lint -- <files>` when supported, or project lint | `npm test -- --runInBand` or targeted test command | `npm run typecheck`, `npm run build`, Playwright smoke |

If package scripts differ, inspect `package.json`, `pyproject.toml`, `go.mod`, `pom.xml`, or Gradle files and map local commands into the required steps:

- `lint`: static checks, formatting checks, type checks, compile-only checks.
- `test`: targeted unit, integration, API, UI, or smoke tests required by the task.
- `task_gate`: the final validation command for the evidence directory.

## Gate Failure Handling

When a required command fails:

- Keep the failed log in `outputs/`.
- Fix only inside the current closure slice and allowed files.
- Re-run the same step through the wrapper.
- If the fix requires a new closure slice or shared prerequisite, stop and mark BLOCKED or replan.

## Dirty Baseline Rule

If `init` detects a dirty worktree before edits, PASS requires:

- `baseline_allowlist.diff`: pre-task diff for allowlisted files.
- `baseline_external_files.txt`: pre-task dirty files outside the allowlist.

This prevents accepting unrelated pre-existing changes as part of the task.
