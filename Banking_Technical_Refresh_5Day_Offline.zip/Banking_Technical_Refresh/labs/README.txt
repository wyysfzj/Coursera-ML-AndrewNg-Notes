JAVA 17 CRASH-COURSE LABS / Java 17 速成实验
========================================

适用范围 / Scope
这是可重复执行的教学代码，无真实银行数据、网络请求或数据库写入。
Day 1 演示有界线程池的准入与拒绝；Day 4 演示纯函数的边界条件测试。
这些执行记录由本学习包制作时运行得到，不代表你个人做过的项目或生产验证。
This pack contains educational reproductions, not candidate project evidence.

要求 / Requirements
JDK 17 或更新版，包含 jdk.compiler 模块；不需要 Maven、Gradle、JUnit 或联网下载。
仅运行网站不需要 Java。运行这些实验才需要 JDK。
java -version
java --list-modules
安装了完整 JDK 时可用 javac；本包的脚本使用同一个 JDK 编译器模块，
命令是 java -m jdk.compiler/com.sun.tools.javac.Main。

一键执行 / Run all
1. 解压整个下载包。
2. 打开终端并进入 labs 文件夹。
3. macOS/Linux: sh run-all.sh
   Windows CMD: run-all.cmd
   Windows PowerShell: .\run-all.cmd
脚本只在 labs/.build 中生成课堂代码的 class 文件。
预期先看到 Day 1 全通过，然后 RED 故意失败，随后 GREEN 和 REFACTOR 全通过。
The deliberate RED stage returns exit code 1; the runner treats that as expected.

实验一 / Day 1 — Bounded capacity and explicit rejection
------------------------------------------------------
情景：假设 PAPI 适配层需要隔离一个慢下游。演示容量极小，是为了观察行为，
不是建议生产只配置 1 个线程。

执行顺序：
1. 线程池 core=1, max=1，队列 ArrayBlockingQueue(1)。
2. 第一个请求进入 worker，并等待 release latch。
3. 主线程确认 worker 已启动，再提交第二个请求，恰好填满一个队列槽。
4. 第三个请求没有空闲 worker，也没有队列空间，因此 AbortPolicy 抛出
   RejectedExecutionException。
5. finally 释放 latch，再 shutdown/awaitTermination，两个已接收请求完成。

为什么确定可重复：测试以 CountDownLatch 协调状态，不依赖 sleep 猜测时序。
await 中的秒数是防止实验挂住的保护，不是延迟 SLA 或性能断言。
worker 内的异常通过 AtomicReference 传回主线程，避免后台失败被遗漏。

实际运行：6 个断言通过，2 个请求被接收，1 个被拒绝，已接收请求没有丢失。
请读 records/ACTUAL_EXECUTION.txt 查看实际 JDK 版本、命令和标准输出。

练习：
A. 将队列容量从 1 改成 2，预测第三个请求会发生什么，再运行。
B. 为什么无限队列即使设置 maximumPoolSize=100 也不能解决所有慢下游问题？
C. 如果改用 CallerRunsPolicy，提交请求的线程会发生什么？
D. 拒绝发生后，对 API 调用方应给怎样的可重试/不可重试语义？

详解：
A. 第三个请求会进入第二个队列槽，原来“必须拒绝”的断言失败。修改测试前
   先解释这是容量规则改变，不是线程池 bug。恢复原配置再进入下一课。
B. 到达 core 数后优先入队；无限队列不满，通常不会为这些排队任务扩展到 max。
   等待堆积会消耗内存、拉长尾延迟；更大容量不等于下游吞吐提高。
C. 调用 execute 的线程自己执行任务，形成一种反馈；若它是请求处理线程，
   也会被阻塞。它不是“免费成功”或任何场景都安全的选择。
D. 在服务边界明确返回过载；容量耗尽通常考虑服务暂不可用语义，限流则按
   API 契约处理。不要静默丢弃并返回成功。重试仍须预算、退避和幂等性。

面试口述：
“I bounded both worker concurrency and the queue, and made overload explicit.
The test coordinates worker state with latches, so it verifies admission behavior
without relying on timing guesses. This protects one resource boundary; real
requests still need deadlines, downstream connection limits, and observability.”

限制：本实验未实现 HTTP 连接池、取消传播、超时、监控或生产 sizing。
生产线程池通常是应用级受控资源，不应每次请求创建一个池。

实验二 / Day 4 — RED → GREEN → REFACTOR
---------------------------------------
验收契约（本课堂定义，不代表银行真实规则）：
- 输入 amount, usedToday, dailyLimit, availableBalance 都必须非 null。
- amount > 0，其余输入 >= 0，否则 INVALID_INPUT。
- usedToday + amount > dailyLimit，返回 DAILY_LIMIT；等于限额可以接受。
- 若通过限额检查而 amount > availableBalance，返回 INSUFFICIENT_BALANCE。
- 其余返回 ACCEPT；输入校验优先于限额，限额优先于余额。
- 所有数值按同一币种、同一单位解释；课堂不限制小数位数，不进行舍入。
- 它只是一个无副作用判断函数，ACCEPT 不代表扣款完成。

文件：
Decision.java               结果类型
TransferPolicy.java         不同版本共用的接口
RedTransferPolicy.java      故意把日累计“>”写成“>=”
GreenTransferPolicy.java    最小修复：比较结果 >=0 改成 >0
RefactoredTransferPolicy.java   在全绿后抽取输入检查，保持判断次序
TransferAcceptanceTest.java 同一组 21 个独立、显式预期的验收用例

RED 的正确原因：
100 + 900 = 1000，契约允许等于限额，而 Red 返回 DAILY_LIMIT。
还有十进制边界、scale 差异、一分钱边界，共 4 个失败。
这不是编译错误、网络失败或测试环境故障，而是明确的行为不符合验收。

GREEN：
只改变限额比较条件，把 >=0 改成 >0。同一组测试变为 21/21 通过。
没有修改期望值、删除失败用例或放宽验收。

REFACTOR：
把 null/signum 校验命名为 positive 与 nonNegative。
保持 INVALID_INPUT → DAILY_LIMIT → INSUFFICIENT_BALANCE → ACCEPT 的次序。
同一组 21/21 再次通过。重构关注可读性，不能偷偷改变业务规则。

为何用 BigDecimal：
从字符串构造 0.1、0.2、0.3，避免把二进制 double 的近似值带进计算。
compareTo 比较数值；1.00 与 1 的比较结果为 0。equals 还比较 scale，
因此不适合直接表达此处“数值相等”的业务判断。

必须理解的边界：
21 个测试只是选定输入的证据，不能证明所有输入正确。
测试代码中标注的 holdout 是独立评审用例示范；本包公开这些用例，因此它们
不是对你或未来 agent 真正保密的 holdout。实际评估应由不同角色维护冻结集。
同时超日限额和余额不足时，这里规定 DAILY_LIMIT 优先；不要把这个课堂约定
当成已核实的银行业务规则。

30 分钟建议：
0–5 分钟：先读契约，遮住实现，手算 5 个边界结果。
5–12 分钟：编译并运行 red，定位 4 个失败是不是同一个根因。
12–20 分钟：自己从 RED 文件复制并修正，验证不改测试也能全绿。
20–25 分钟：对照 REFACTOR，解释短路校验与优先级为何保持不变。
25–30 分钟：口述风险与下一层测试：并发扣款、幂等、持久化和交易边界。

额外练习（可手工做 mutation check）：
1. 将余额检查 > 改成 >=。预期 exact_balance 被测试拦截。
2. 从累计限额计算移除 usedToday。预期 over_daily_limit 被拦截。
3. 将余额检查放到日限额检查前。预期 holdout_daily_before_balance 被拦截。
先预测再运行，不要修改预期使错误实现通过。

单独执行 / Individual commands
在 labs/day1 中：
java Day1BackpressureLab.java

在 labs/day4 中（编译命令是一整行）：
java -m jdk.compiler/com.sun.tools.javac.Main -d build Decision.java TransferPolicy.java RedTransferPolicy.java GreenTransferPolicy.java RefactoredTransferPolicy.java TransferAcceptanceTest.java
java -cp build TransferAcceptanceTest red
java -cp build TransferAcceptanceTest green
java -cp build TransferAcceptanceTest refactor

实际记录 / Actual run results
records/RED.txt          21 cases: 17 pass, 4 fail, exit 1 (intentional)
records/GREEN.txt        21 cases: 21 pass, 0 fail, exit 0
records/REFACTOR.txt     21 cases: 21 pass, 0 fail, exit 0
records/ACTUAL_EXECUTION.txt   combined runtime, commands, and logs

官方扩展阅读 / Official references
ThreadPoolExecutor (Java 17):
https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/util/concurrent/ThreadPoolExecutor.html
BigDecimal (Java 17):
https://docs.oracle.com/en/java/javase/17/docs/api/java.base/java/math/BigDecimal.html
