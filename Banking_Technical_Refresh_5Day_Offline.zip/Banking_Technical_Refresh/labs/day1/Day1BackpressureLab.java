import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Educational PAPI-like admission-control exercise, Java 17, no HTTP or bank data.
 * The latches make overload deterministic: worker #1 cannot finish while the
 * main thread queues request #2 and submits request #3. Timeouts are only guards
 * against a stuck exercise, not performance assertions.
 */
public final class Day1BackpressureLab {
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        System.out.println("PASS " + message);
    }

    public static void main(String[] args) throws Exception {
        var started = new CountDownLatch(1);
        var release = new CountDownLatch(1);
        var completed = new AtomicInteger();
        var workerFailure = new AtomicReference<Throwable>();
        var executor = new ThreadPoolExecutor(
                1, 1, 0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<Runnable>(1),
                new ThreadPoolExecutor.AbortPolicy());
        boolean rejected = false;
        try {
            executor.execute(() -> {
                started.countDown();
                try {
                    if (!release.await(10, TimeUnit.SECONDS)) {
                        throw new AssertionError("Release guard timed out");
                    }
                    completed.incrementAndGet();
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    workerFailure.compareAndSet(null, interrupted);
                } catch (Throwable failure) {
                    workerFailure.compareAndSet(null, failure);
                }
            });

            check(started.await(5, TimeUnit.SECONDS), "first request entered worker");
            executor.execute(completed::incrementAndGet);
            check(executor.getQueue().size() == 1, "second request occupies sole queue slot");

            try {
                executor.execute(completed::incrementAndGet);
            } catch (RejectedExecutionException overloaded) {
                rejected = true;
            }
            check(rejected, "third request rejected explicitly at admission boundary");
            check(executor.getQueue().size() == 1, "overload did not grow queue");
        } finally {
            // Release before waiting for shutdown: otherwise this exercise deadlocks.
            release.countDown();
            executor.shutdown();
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                executor.shutdownNow();
                if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                    throw new AssertionError("Executor failed to terminate");
                }
            }
        }

        if (workerFailure.get() != null) {
            throw new AssertionError("Worker failed", workerFailure.get());
        }
        check(completed.get() == 2, "exactly two accepted requests completed");
        check(executor.isTerminated(), "executor terminated and released resources");
        System.out.println("SUMMARY: 6 assertions passed; 2 accepted; 1 rejected; 0 lost accepted requests.");
    }
}
