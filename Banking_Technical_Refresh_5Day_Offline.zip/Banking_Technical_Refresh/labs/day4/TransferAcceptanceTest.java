import java.math.BigDecimal;
import java.util.List;

/**
 * Acceptance oracle is explicit expected business outcomes, not a copied formula.
 * Same unchanged cases exercise all three implementation versions. No dependencies.
 * The last three cases are designated review/holdout examples in the lesson;
 * because they ship in this pack, they are not hidden from you or a future agent.
 */
public final class TransferAcceptanceTest {
    record Case(String name, String amount, String used, String limit,
                String balance, Decision expected) {}

    private static BigDecimal decimal(String value) {
        return value == null ? null : new BigDecimal(value);
    }

    public static void main(String[] args) {
        if (args.length != 1) throw new IllegalArgumentException("Use red, green, or refactor");
        TransferPolicy policy = switch (args[0]) {
            case "red" -> new RedTransferPolicy();
            case "green" -> new GreenTransferPolicy();
            case "refactor" -> new RefactoredTransferPolicy();
            default -> throw new IllegalArgumentException("Unknown stage: " + args[0]);
        };
        List<Case> cases = List.of(
            new Case("within_limit", "100", "200", "1000", "500", Decision.ACCEPT),
            new Case("exact_daily_limit", "100", "900", "1000", "100", Decision.ACCEPT),
            new Case("over_daily_limit", "100.01", "900", "1000", "500", Decision.DAILY_LIMIT),
            new Case("insufficient_balance", "50.01", "0", "1000", "50", Decision.INSUFFICIENT_BALANCE),
            new Case("exact_balance", "50.00", "0", "1000", "50.0", Decision.ACCEPT),
            new Case("zero_amount", "0", "0", "1000", "500", Decision.INVALID_INPUT),
            new Case("negative_amount", "-0.01", "0", "1000", "500", Decision.INVALID_INPUT),
            new Case("null_amount", null, "0", "1000", "500", Decision.INVALID_INPUT),
            new Case("null_used", "1", null, "1000", "500", Decision.INVALID_INPUT),
            new Case("null_limit", "1", "0", null, "500", Decision.INVALID_INPUT),
            new Case("null_balance", "1", "0", "1000", null, Decision.INVALID_INPUT),
            new Case("negative_used", "1", "-1", "1000", "500", Decision.INVALID_INPUT),
            new Case("negative_limit", "1", "0", "-1", "500", Decision.INVALID_INPUT),
            new Case("negative_balance", "1", "0", "1000", "-1", Decision.INVALID_INPUT),
            new Case("zero_limit", "0.01", "0", "0", "1", Decision.DAILY_LIMIT),
            new Case("zero_balance", "0.01", "0", "1000", "0", Decision.INSUFFICIENT_BALANCE),
            new Case("decimal_string_boundary", "0.1", "0.2", "0.3", "0.1", Decision.ACCEPT),
            new Case("scale_independence", "1.00", "9.0", "10.000", "1", Decision.ACCEPT),
            new Case("holdout_one_cent_boundary", "0.01", "999.99", "1000", "0.01", Decision.ACCEPT),
            new Case("holdout_daily_before_balance", "100.01", "900", "1000", "1", Decision.DAILY_LIMIT),
            new Case("holdout_invalid_before_limits", "1", "2000", "1000", "-1", Decision.INVALID_INPUT)
        );
        int failures = 0;
        System.out.println("STAGE: " + args[0].toUpperCase());
        for (Case test : cases) {
            Decision actual = policy.decide(decimal(test.amount()), decimal(test.used()),
                    decimal(test.limit()), decimal(test.balance()));
            boolean pass = actual == test.expected();
            if (!pass) failures++;
            System.out.printf("%s %-34s expected=%-20s actual=%s%n",
                    pass ? "PASS" : "FAIL", test.name(), test.expected(), actual);
        }
        System.out.printf("SUMMARY: total=%d passed=%d failed=%d%n",
                cases.size(), cases.size() - failures, failures);
        if (failures > 0) System.exit(1);
    }
}
