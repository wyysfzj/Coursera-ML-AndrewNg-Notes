import java.math.BigDecimal;

/** Pure decision only; no account mutation, currency conversion, or payment execution. */
public interface TransferPolicy {
    Decision decide(BigDecimal amount, BigDecimal usedToday,
                    BigDecimal dailyLimit, BigDecimal availableBalance);
}
