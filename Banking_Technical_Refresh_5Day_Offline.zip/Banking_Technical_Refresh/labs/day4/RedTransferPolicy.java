import java.math.BigDecimal;

/** Deliberate defect: equality with the daily limit is wrongly rejected. */
public final class RedTransferPolicy implements TransferPolicy {
    @Override
    public Decision decide(BigDecimal amount, BigDecimal usedToday,
                           BigDecimal dailyLimit, BigDecimal availableBalance) {
        if (amount == null || usedToday == null || dailyLimit == null || availableBalance == null
                || amount.signum() <= 0 || usedToday.signum() < 0
                || dailyLimit.signum() < 0 || availableBalance.signum() < 0) {
            return Decision.INVALID_INPUT;
        }
        if (usedToday.add(amount).compareTo(dailyLimit) >= 0) { // BUG: should be > 0
            return Decision.DAILY_LIMIT;
        }
        if (amount.compareTo(availableBalance) > 0) {
            return Decision.INSUFFICIENT_BALANCE;
        }
        return Decision.ACCEPT;
    }
}
