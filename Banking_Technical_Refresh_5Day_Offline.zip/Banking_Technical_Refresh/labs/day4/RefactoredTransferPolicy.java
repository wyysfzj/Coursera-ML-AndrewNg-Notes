import java.math.BigDecimal;

/** Refactor after green: name validation, keeping decision ordering unchanged. */
public final class RefactoredTransferPolicy implements TransferPolicy {
    @Override
    public Decision decide(BigDecimal amount, BigDecimal usedToday,
                           BigDecimal dailyLimit, BigDecimal availableBalance) {
        if (!positive(amount) || !nonNegative(usedToday)
                || !nonNegative(dailyLimit) || !nonNegative(availableBalance)) {
            return Decision.INVALID_INPUT;
        }
        BigDecimal totalToday = usedToday.add(amount);
        if (totalToday.compareTo(dailyLimit) > 0) return Decision.DAILY_LIMIT;
        if (amount.compareTo(availableBalance) > 0) return Decision.INSUFFICIENT_BALANCE;
        return Decision.ACCEPT;
    }

    private static boolean positive(BigDecimal value) {
        return value != null && value.signum() > 0;
    }

    private static boolean nonNegative(BigDecimal value) {
        return value != null && value.signum() >= 0;
    }
}
