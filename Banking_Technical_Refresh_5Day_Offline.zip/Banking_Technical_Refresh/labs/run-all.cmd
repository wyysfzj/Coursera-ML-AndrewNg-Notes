@echo off
setlocal
pushd "%~dp0"
if not exist .build\day1 mkdir .build\day1
if not exist .build\day4 mkdir .build\day4
java -m jdk.compiler/com.sun.tools.javac.Main -d .build\day1 day1\Day1BackpressureLab.java
if errorlevel 1 goto fail
java -cp .build\day1 Day1BackpressureLab
if errorlevel 1 goto fail
java -m jdk.compiler/com.sun.tools.javac.Main -d .build\day4 day4\Decision.java day4\TransferPolicy.java day4\RedTransferPolicy.java day4\GreenTransferPolicy.java day4\RefactoredTransferPolicy.java day4\TransferAcceptanceTest.java
if errorlevel 1 goto fail
java -cp .build\day4 TransferAcceptanceTest red
set "red_exit=%ERRORLEVEL%"
if not "%red_exit%"=="1" goto fail
java -cp .build\day4 TransferAcceptanceTest green
if errorlevel 1 goto fail
java -cp .build\day4 TransferAcceptanceTest refactor
if errorlevel 1 goto fail
echo All lab stages reproduced. RED exit 1 is intentional; GREEN and REFACTOR pass.
popd
exit /b 0
:fail
echo Lab reproduction failed. Check your JDK 17 or newer installation.
popd
exit /b 1
