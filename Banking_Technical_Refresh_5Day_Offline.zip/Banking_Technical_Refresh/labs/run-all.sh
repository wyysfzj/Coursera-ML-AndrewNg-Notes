#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p .build/day1 .build/day4
java -m jdk.compiler/com.sun.tools.javac.Main -d .build/day1 day1/Day1BackpressureLab.java
java -cp .build/day1 Day1BackpressureLab
java -m jdk.compiler/com.sun.tools.javac.Main -d .build/day4 day4/Decision.java day4/TransferPolicy.java day4/RedTransferPolicy.java day4/GreenTransferPolicy.java day4/RefactoredTransferPolicy.java day4/TransferAcceptanceTest.java
set +e
java -cp .build/day4 TransferAcceptanceTest red
red_exit=$?
set -e
if [ "$red_exit" -ne 1 ]; then
    echo "Unexpected RED result: expected exit 1, got $red_exit" >&2
    exit 1
fi
java -cp .build/day4 TransferAcceptanceTest green
java -cp .build/day4 TransferAcceptanceTest refactor
echo "All lab stages reproduced. RED exit 1 is intentional; GREEN and REFACTOR pass."
