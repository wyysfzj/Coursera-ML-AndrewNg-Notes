
# OB‑AT‑01 — Repo Bootstrap & Contract Scaffolding

## Objective
- Create the foundational contract and repo structure for the Open Banking Consent Setup service.
- This task sets up the initial project structure, including the core dependencies, and prepares the repo for further task development.

## Scope (allowed files)
- `cmd/server/main.go`
- `internal/httpapi/*`
- `api/openapi.yaml`
- `README.md`

## Forbidden moves (negative constraints)
- No business logic
- No storage implementation
- No caching

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-01/commands.jsonl`
- `artifacts/OB-AT-01/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-01/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-01/results.jsonl`
- `artifacts/OB-AT-01/summary.md`

## Required evidence / checks
- `go test ./...` should pass
- `openapi.yaml` must exist and match handler routes (manual review for v1)

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Task scope completed
- Forbidden moves not present
- Evidence Bundle generated and gates pass
