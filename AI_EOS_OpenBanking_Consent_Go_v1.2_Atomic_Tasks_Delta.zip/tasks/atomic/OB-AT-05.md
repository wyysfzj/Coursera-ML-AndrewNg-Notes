
# OB‑AT‑05 — Consent Creation Handler (POST /consents) — Atomic Path Only

## Objective
- Implement the `POST /consents` endpoint to handle consent creation.
- Ensure that the consent creation is idempotent, validates the necessary fields, and returns a 201 response with `consent_id`, `expires_at`, and `challenge`.

## Scope (allowed files)
- `internal/httpapi/handler.go`
- `internal/atomic/consent/service.go`

## Forbidden moves (negative constraints)
- No GET implementation
- No state machine framework (keep simple)
- No additional endpoints

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-05/commands.jsonl`
- `artifacts/OB-AT-05/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-05/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-05/results.jsonl`
- `artifacts/OB-AT-05/summary.md`

## Required evidence / checks
- `go test ./...` should pass
- `gofmt` clean
- `POST /consents` should return `201` with correct fields
- Idempotency logic should work as expected

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Task scope completed
- Forbidden moves not present
- Evidence Bundle generated and gates pass
