
# OB‑AT‑03 — Signature Verification + Ed25519 (Client Authentication)

## Objective
- Implement signature verification for the `POST /consents` endpoint using Ed25519 for client authentication.
- Ensure that requests are signed and validated using a client-specific public key.
- Reject any requests with invalid signatures.

## Scope (allowed files)
- `internal/security/registry.go`
- `internal/atomic/consent/signature.go`

## Forbidden moves (negative constraints)
- No fallback authentication methods
- No accepting unsigned requests
- No logging of secrets

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-03/commands.jsonl`
- `artifacts/OB-AT-03/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-03/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-03/results.jsonl`
- `artifacts/OB-AT-03/summary.md`

## Required evidence / checks
- Signature verification tests must pass (e.g., correct signature matching)
- `gofmt` clean

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Task scope completed
- Forbidden moves not present
- Evidence Bundle generated and gates pass
