
# OB‑AT‑04 — Idempotency Key + Request Hash Binding

## Objective
- Implement idempotency key functionality to ensure that requests with the same idempotency key return the same response.
- Bind the idempotency key to the request hash to prevent replay attacks.

## Scope (allowed files)
- `internal/atomic/consent/idempotency.go`
- `internal/atomic/consent/store.go`

## Forbidden moves (negative constraints)
- No upsert logic without binding request hash
- No returning existing response without checking request hash
- No caching without proper expiration and validation

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-04/commands.jsonl`
- `artifacts/OB-AT-04/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-04/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-04/results.jsonl`
- `artifacts/OB-AT-04/summary.md`

## Required evidence / checks
- Same idempotency key with different payload returns `409 Conflict`
- `go test ./...` should pass
- `gofmt` clean

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Task scope completed
- Forbidden moves not present
- Evidence Bundle generated and gates pass
