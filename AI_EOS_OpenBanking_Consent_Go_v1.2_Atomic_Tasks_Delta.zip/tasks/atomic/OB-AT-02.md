
# OB‑AT‑02 — Domain Model + Invariants (Consent, Status, Expiry)

## Objective
- Implement the domain models for Consent and related entities (e.g., Status, Expiry).
- Ensure the models correctly represent the Open Banking Consent data structure and apply the necessary validation (e.g., expiration sanity, status transitions).

## Scope (allowed files)
- `internal/consent/consent.go`
- `internal/consent/service.go`

## Forbidden moves (negative constraints)
- No HTTP handlers
- No persistence
- No business logic outside of the model layer

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-02/commands.jsonl`
- `artifacts/OB-AT-02/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-02/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-02/results.jsonl`
- `artifacts/OB-AT-02/summary.md`

## Required evidence / checks
- `go test ./...` should pass
- `gofmt` clean

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Task scope completed
- Forbidden moves not present
- Evidence Bundle generated and gates pass
