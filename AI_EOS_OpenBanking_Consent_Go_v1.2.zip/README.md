# AI‑EOS Open Banking Consent Setup (Go) — Atomic vs Non‑Atomic Teaching Repo

This repository is a **lecture-grade** reference implementation for an **AI-first · Task-driven · Evidence-backed · Gate-controlled**
Engineering Operating System (AI‑EOS), using an **Open Banking Consent Setup** backend in **Go**.

## What you can do with this repo
- Run the same API in two modes:
  - **Atomic** (governed, evidence-backed, gate-friendly)
  - **Non-Atomic** (intentionally “reasonable” but dangerous; demonstrates failure modes)
- Teach AI‑EOS Lectures 1–5 using a backend domain.
- Execute Atomic Tasks and generate **Evidence Bundles** under `artifacts/<TASK_ID>/...` following the FPMS pattern.

## Quick start

### Run servers
Atomic (port 8080):
```bash
make run-atomic
```

Non-Atomic (port 8081):
```bash
make run-nonatomic
```

### Observe differences (curl demos)
Atomic (expects signature + idempotency hash binding):
```bash
make demo-atomic
```

Non-Atomic (accepts missing signature + idempotency malleability):
```bash
make demo-nonatomic
```

### Invariant tests (behavior gates)
Atomic (PASS):
```bash
make test-invariants-atomic
```

Non-Atomic (FAIL — expected, to demonstrate why governance matters):
```bash
make test-invariants-nonatomic
```

### Generate Evidence Bundle (FPMS-style)
```bash
make eos TASK=OB-AT-05
```
Output: `artifacts/OB-AT-05/...`

## Repo layout
- `docs/lectures/` — Lecture 1–5 (this case)
- `tasks/atomic/` — 10 atomic tasks (8–12 requested)
- `tasks/non_atomic/` — Copilot prompts / anti-pattern scripts
- `tools/eos/` — Evidence Bundle runner + diff gate
- `cmd/server/` — Server binary (mode chosen by `EOS_MODE`)
- `cmd/sign/` — Demo signer for Atomic requests
- `internal/atomic/` — governed implementation
- `internal/non_atomic/` — intentionally unsafe implementation
- `scripts/` — demo scripts

## Disclaimer
Non‑Atomic mode is intentionally insecure and exists only for teaching AI‑EOS.

## Standards (v1.2)
- `docs/standards/Conformance_Suite_Spec_v1.md`
- `docs/standards/Traceability_Matrix_Consent_Setup_v1.md`

### Multi-client access control demo (INV-03)
```bash
make run-atomic
bash scripts/demo_atomic_multiclient.sh
```
