#!/usr/bin/env bash
set -euo pipefail
BASE="http://localhost:8080"
echo "== Atomic multi-client demo against ${BASE} =="

payload='{"customer_id":"cust-001","scopes":["accounts.basic:read"],"expires_at":"2030-01-01T00:00:00Z","redirect_uri":"https://example.com/cb"}'

echo "-- Create as demo-client"
sig="$(go run ./cmd/sign --client-id demo-client --method POST --path /consents --idempotency idem-mc --body "${payload}")"
resp="$(curl -s -w "\n%{http_code}" -X POST "${BASE}/consents" \
  -H "Content-Type: application/json" \
  -H "X-Client-Id: demo-client" \
  -H "Idempotency-Key: idem-mc" \
  -H "X-Signature: ${sig}" \
  --data "${payload}")"
body="$(echo "${resp}" | head -n1)"
code="$(echo "${resp}" | tail -n1)"
echo "  status=${code}"
echo "  body=${body}"
consent_id="$(echo "${body}" | sed -n 's/.*"consent_id":"\([^"]*\)".*/\1/p')"

echo
echo "-- Attempt GET as demo-client-2 (should be 404 non-leak)"
sig2="$(go run ./cmd/sign --client-id demo-client-2 --method GET --path "/consents/${consent_id}" --idempotency "-" --body "")"
curl -s -o /dev/null -w "  status=%{http_code}\n" -X GET "${BASE}/consents/${consent_id}" \
  -H "X-Client-Id: demo-client-2" \
  -H "X-Signature: ${sig2}"
