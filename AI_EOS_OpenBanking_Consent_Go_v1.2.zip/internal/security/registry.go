package security

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"strings"
)

// Teaching-only deterministic seeds (DO NOT USE IN PRODUCTION).
var (
	demoSeed1Hex = "6636576d097ed085d9a283377f694e33d28b7a32a869df53544591e3c7d7b658" // demo-client
	demoSeed2Hex = "939e081121c33b5a7ff63945f2dc9d6e2bb64dff7a2dc1de6ec89748c155e4f2" // demo-client-2
)

func demoPrivateKeyFromSeedHex(seedHex string) ed25519.PrivateKey {
	seed, _ := hex.DecodeString(seedHex)
	return ed25519.NewKeyFromSeed(seed)
}

// DemoPrivateKeyFor returns a deterministic demo private key for a known demo client.
// Panics if client is unknown (teaching repo).
func DemoPrivateKeyFor(clientID string) ed25519.PrivateKey {
	switch clientID {
	case "demo-client":
		return demoPrivateKeyFromSeedHex(demoSeed1Hex)
	case "demo-client-2":
		return demoPrivateKeyFromSeedHex(demoSeed2Hex)
	default:
		panic("unknown demo client: " + clientID)
	}
}

// DemoPublicKeyFor returns the matching public key for the demo client.
func DemoPublicKeyFor(clientID string) ed25519.PublicKey {
	priv := DemoPrivateKeyFor(clientID)
	return priv.Public().(ed25519.PublicKey)
}

type ClientRegistry struct {
	pubKeys map[string]ed25519.PublicKey
}

func NewClientRegistry() *ClientRegistry {
	return &ClientRegistry{pubKeys: map[string]ed25519.PublicKey{
		"demo-client":   DemoPublicKeyFor("demo-client"),
		"demo-client-2": DemoPublicKeyFor("demo-client-2"),
	}}
}

func (r *ClientRegistry) PublicKey(clientID string) (ed25519.PublicKey, bool) {
	pk, ok := r.pubKeys[clientID]
	return pk, ok
}

// Canonical forms the signature input.
// Canonical MUST bind method, path, idempotency key (or "-"), and body hash.
// This is a governance artifact: if canonicalization changes, it must be versioned.
func Canonical(method, path, idem, body string) string {
	if idem == "" {
		idem = "-"
	}
	sum := sha256.Sum256([]byte(body))
	bodyHash := fmt.Sprintf("%x", sum[:])
	return strings.ToUpper(method) + "\n" + path + "\n" + idem + "\n" + bodyHash
}

func VerifyEd25519Signature(pub ed25519.PublicKey, canonical string, sigB64 string) bool {
	sig, err := base64.StdEncoding.DecodeString(sigB64)
	if err != nil {
		return false
	}
	return ed25519.Verify(pub, []byte(canonical), sig)
}
