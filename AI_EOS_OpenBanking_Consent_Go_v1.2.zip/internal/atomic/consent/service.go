package consent

import (
	"context"
	"log"
	"time"

	"ai-eos-openbanking-consent/internal/audit"
	core "ai-eos-openbanking-consent/internal/consent"
)

type Service struct {
	Store    *Store
	Verifier *SignatureVerifier
	Idem     *Idempotency
	Audit    audit.Sink
	Logger   *log.Logger
	Now      func() time.Time
}

func NewService(store *Store, verifier *SignatureVerifier, idem *Idempotency, auditSink audit.Sink, logger *log.Logger) *Service {
	return &Service{
		Store:    store,
		Verifier: verifier,
		Idem:     idem,
		Audit:    auditSink,
		Logger:   logger,
		Now:      func() time.Time { return time.Now().UTC() },
	}
}

func (s *Service) Evidencef(format string, args ...any) {
	s.Logger.Printf("AI_EOS_EVIDENCE "+format, args...)
}

func (s *Service) CreateConsent(ctx context.Context, req core.CreateRequest, meta core.Meta) (core.CreateResponse, int, error) {
	meta.Path = "/consents"
	meta.Method = "POST"

	_, requestHash, _, err := s.Verifier.VerifyOrReject(ctx, meta)
	if err != nil {
		s.Evidencef("EVIDENCE_SIGNATURE_VERIFIED ok=false client_id=%s", meta.ClientID)
		return core.CreateResponse{}, 401, err
	}
	s.Evidencef("EVIDENCE_SIGNATURE_VERIFIED ok=true client_id=%s", meta.ClientID)

	expiresAt, err2 := time.Parse(time.RFC3339, req.ExpiresAt)
	if err2 != nil {
		return core.CreateResponse{}, 400, core.ErrInvalidRequest
	}
	if err3 := core.ValidateExpiry(expiresAt, s.Now()); err3 != nil {
		return core.CreateResponse{}, 400, err3
	}

	if resp, replay, status, err4 := s.Idem.Check(ctx, meta.IdempotencyKey, requestHash); err4 != nil {
		return core.CreateResponse{}, status, err4
	} else if replay {
		return resp, status, nil
	}

	consentID := newID("cns")
	challenge := newChallenge()

	c := core.Consent{
		ID:          consentID,
		ClientID:    meta.ClientID,
		CustomerID:  req.CustomerID,
		Scopes:      append([]string(nil), req.Scopes...),
		ExpiresAt:   expiresAt,
		Status:      core.StatusAwaitingAuthorization,
		Challenge:   challenge,
		CreatedAt:   s.Now(),
		UpdatedAt:   s.Now(),
		RequestHash: requestHash,
		Idempotency: meta.IdempotencyKey,
	}
	s.Store.PutConsent(c)

	resp := core.CreateResponse{
		ConsentID: consentID,
		ExpiresAt: expiresAt.Format(time.RFC3339),
		Status:    c.Status,
		Challenge: challenge,
	}

	s.Idem.Remember(meta.IdempotencyKey, requestHash, resp, consentID)

	_ = s.Audit.Record(ctx, audit.Event{
		TS:       s.Now(),
		Type:     "consent.created",
		Consent:  consentID,
		ClientID: meta.ClientID,
		Meta: map[string]string{
			"scopes_count": itoa(len(req.Scopes)),
			"expires_at":   resp.ExpiresAt,
			"req_hash":     requestHash[:12],
		},
	})

	s.Evidencef("EVIDENCE_CONSENT_CREATED consent_id=%s client_id=%s", consentID, meta.ClientID)
	return resp, 201, nil
}

func (s *Service) GetConsent(ctx context.Context, consentID string, meta core.Meta) (core.Consent, int, error) {
	meta.Path = "/consents/" + consentID
	meta.Method = "GET"

	_, _, _, err := s.Verifier.VerifyOrReject(ctx, meta)
	if err != nil {
		s.Evidencef("EVIDENCE_SIGNATURE_VERIFIED ok=false client_id=%s", meta.ClientID)
		return core.Consent{}, 401, err
	}
	s.Evidencef("EVIDENCE_SIGNATURE_VERIFIED ok=true client_id=%s", meta.ClientID)

	c, ok := s.Store.GetConsent(consentID)
	if !ok {
		return core.Consent{}, 404, core.ErrNotFound
	}
	if c.ClientID != meta.ClientID {
		s.Evidencef("EVIDENCE_ACCESS_DENIED consent_id=%s client_id=%s", consentID, meta.ClientID)
		return core.Consent{}, 404, core.ErrNotFound
	}
	s.Evidencef("EVIDENCE_ACCESS_GRANTED consent_id=%s client_id=%s", consentID, meta.ClientID)
	return c, 200, nil
}

func itoa(i int) string {
	if i == 0 {
		return "0"
	}
	b := [20]byte{}
	pos := len(b)
	for i > 0 {
		pos--
		b[pos] = byte('0' + (i % 10))
		i /= 10
	}
	return string(b[pos:])
}
