package consent

import (
	"crypto/rand"
	"encoding/base32"
	"encoding/base64"
	"fmt"
	"time"
)

func newID(prefix string) string {
	b := make([]byte, 16)
	_, _ = rand.Read(b)
	enc := base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(b)
	return fmt.Sprintf("%s_%d_%s", prefix, time.Now().UTC().UnixNano(), enc)
}

func newChallenge() string {
	b := make([]byte, 32)
	_, _ = rand.Read(b)
	return base64.RawURLEncoding.EncodeToString(b)
}
