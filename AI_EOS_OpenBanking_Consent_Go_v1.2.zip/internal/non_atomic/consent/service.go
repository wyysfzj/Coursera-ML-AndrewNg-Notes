package consent

import (
	"context"
	"encoding/json"
	"log"
	"sync"
	"time"

	core "ai-eos-openbanking-consent/internal/consent"
)

type Service struct {
	mu       sync.Mutex
	consents map[string]core.Consent
	idem     map[string]string // key -> consentID (NO request-hash binding)
	logger   *log.Logger
	now      func() time.Time
}

func NewService(logger *log.Logger) *Service {
	return &Service{
		consents: make(map[string]core.Consent),
		idem:     make(map[string]string),
		logger:   logger,
		now:      func() time.Time { return time.Now().UTC() },
	}
}

func (s *Service) CreateConsent(ctx context.Context, req core.CreateRequest, meta core.Meta) (core.CreateResponse, int, error) {
	// Intentionally unsafe:
	// - no signature verification
	// - idempotency key optional
	// - if idempotency key exists, return existing consent regardless of payload
	// - logs raw request (PII risk)
	b, _ := json.Marshal(req)
	s.logger.Printf("NON_ATOMIC create req=%s client_id=%s idem=%s", string(b), meta.ClientID, meta.IdempotencyKey)

	expiresAt, err := time.Parse(time.RFC3339, req.ExpiresAt)
	if err != nil {
		return core.CreateResponse{}, 400, core.ErrInvalidRequest
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	if meta.IdempotencyKey != "" {
		if existingID, ok := s.idem[meta.IdempotencyKey]; ok {
			c := s.consents[existingID]
			return core.CreateResponse{ConsentID: c.ID, ExpiresAt: c.ExpiresAt.Format(time.RFC3339), Status: c.Status, Challenge: c.Challenge}, 200, nil
		}
	}

	consentID := "cns_na_" + time.Now().UTC().Format("20060102T150405.000000000Z07:00")
	challenge := "na-challenge" // intentionally non-random

	c := core.Consent{
		ID:         consentID,
		ClientID:   meta.ClientID,
		CustomerID: req.CustomerID,
		Scopes:     append([]string(nil), req.Scopes...),
		ExpiresAt:  expiresAt,
		Status:     core.StatusAwaitingAuthorization,
		Challenge:  challenge,
		CreatedAt:  s.now(),
		UpdatedAt:  s.now(),
	}
	s.consents[consentID] = c
	if meta.IdempotencyKey != "" {
		s.idem[meta.IdempotencyKey] = consentID
	}

	return core.CreateResponse{ConsentID: consentID, ExpiresAt: expiresAt.Format(time.RFC3339), Status: c.Status, Challenge: challenge}, 201, nil
}

func (s *Service) GetConsent(ctx context.Context, consentID string, meta core.Meta) (core.Consent, int, error) {
	// Intentionally unsafe:
	// - no signature verification
	// - no client binding (any client can read)
	s.mu.Lock()
	defer s.mu.Unlock()
	c, ok := s.consents[consentID]
	if !ok {
		return core.Consent{}, 404, core.ErrNotFound
	}
	return c, 200, nil
}
