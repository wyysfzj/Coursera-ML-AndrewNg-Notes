# Task packs

- `tasks/atomic/` — 10 atomic tasks (OB-AT-01…OB-AT-10)
- `tasks/non_atomic/` — Copilot prompts / anti-pattern scripts

Atomic tasks are intended to be executed sequentially and to produce Evidence Bundles under:
`artifacts/<TASK_ID>/...`
