# OB-AT-08 — Non-Atomic reference implementation (intentionally unsafe)

## Objective
Implement exactly the capabilities described for this task, and nothing else.

## Scope (allowed files)
- `internal/non_atomic/*`
- `scripts/*`

## Forbidden moves (negative constraints)
- Do NOT “fix” non-atomic mode
- Keep it plausible-but-wrong

## Evidence Bundle requirements (FPMS-style)
Generate:
- `artifacts/OB-AT-08/commands.jsonl`
- `artifacts/OB-AT-08/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-08/outputs/*_format.log`, `*_vet.log`, `*_test.log`
- `artifacts/OB-AT-08/results.jsonl`
- `artifacts/OB-AT-08/summary.md`

## Required evidence / checks
- Demo scripts show diff
- Invariant tests fail in non-atomic mode

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Scope completed
- Forbidden moves absent
- Evidence Bundle generated
