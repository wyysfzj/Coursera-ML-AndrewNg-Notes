# OB-AT-10 — Evidence Bundle runner + diff gate

## Objective
Implement exactly the capabilities described for this task, and nothing else.

## Scope (allowed files)
- `tools/eos/*`
- `artifacts/_template/*`

## Forbidden moves (negative constraints)
- Everything recorded
- Gate reads results.jsonl only

## Evidence Bundle requirements (FPMS-style)
Generate:
- `artifacts/OB-AT-10/commands.jsonl`
- `artifacts/OB-AT-10/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-10/outputs/*_format.log`, `*_vet.log`, `*_test.log`
- `artifacts/OB-AT-10/results.jsonl`
- `artifacts/OB-AT-10/summary.md`

## Required evidence / checks
- make eos generates bundle
- diff gate enforceable via ALLOW_FILES

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Scope completed
- Forbidden moves absent
- Evidence Bundle generated
