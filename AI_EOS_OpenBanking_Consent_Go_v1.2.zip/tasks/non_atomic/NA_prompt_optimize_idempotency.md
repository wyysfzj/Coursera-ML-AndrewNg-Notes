# Non-Atomic prompt — “Optimize idempotency” (replay window)

> Add caching for idempotency keys so repeated requests are fast.
> If the idempotency key exists, return the prior response.
> If the payload differs, still return the same response to be user-friendly.

This turns idempotency into a replay primitive and violates hash-binding.
