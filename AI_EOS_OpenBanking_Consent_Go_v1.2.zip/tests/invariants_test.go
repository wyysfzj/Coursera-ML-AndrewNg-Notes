package tests

import (
	"bytes"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"regexp"
	"testing"
	"time"

	"ai-eos-openbanking-consent/internal/httpapi"
	"ai-eos-openbanking-consent/internal/security"
)

func TestInvariants(t *testing.T) {
	mode := os.Getenv("EOS_MODE")
	if mode == "" {
		mode = "atomic"
	}

	ts := httptest.NewServer(httpapi.NewHandler(mode, testLogger(t)))
	defer ts.Close()

	// Base request (valid)
	payload := map[string]any{
		"customer_id":  "cust-001",
		"scopes":       []string{"accounts.basic:read"},
		"expires_at":   "2030-01-01T00:00:00Z",
		"redirect_uri": "https://example.com/cb",
	}
	body, _ := json.Marshal(payload)

	// INV‑01: Signature required for POST /consents (this should FAIL in non-atomic mode)
	{
		req, _ := http.NewRequest("POST", ts.URL+"/consents", bytes.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Client-Id", "demo-client")
		req.Header.Set("Idempotency-Key", "idem-1")
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		_ = resp.Body.Close()

		if resp.StatusCode != 401 {
			t.Fatalf("%s: INV-01 expected 401 without signature, got %d", mode, resp.StatusCode)
		}
	}

	if mode != "atomic" {
		return
	}

	// Create with valid signature -> 201/200
	var consentID string
	var challenge1 string
	{
		sig := signAs("demo-client", "POST", "/consents", "idem-1", string(body))
		req, _ := http.NewRequest("POST", ts.URL+"/consents", bytes.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Client-Id", "demo-client")
		req.Header.Set("Idempotency-Key", "idem-1")
		req.Header.Set("X-Signature", sig)

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != 201 && resp.StatusCode != 200 {
			b, _ := io.ReadAll(resp.Body)
			t.Fatalf("atomic: expected 201/200, got %d body=%s", resp.StatusCode, string(b))
		}
		var out map[string]any
		_ = json.NewDecoder(resp.Body).Decode(&out)
		consentID, _ = out["consent_id"].(string)
		challenge1, _ = out["challenge"].(string)
		if consentID == "" || challenge1 == "" {
			t.Fatalf("atomic: missing consent_id/challenge in response")
		}
	}

	// INV‑02: Idempotency binds request hash (mismatch => 409)
	{
		payload2 := map[string]any{
			"customer_id":  "cust-001",
			"scopes":       []string{"accounts.detail:read"},
			"expires_at":   "2030-01-01T00:00:00Z",
			"redirect_uri": "https://example.com/cb",
		}
		body2, _ := json.Marshal(payload2)
		sig2 := signAs("demo-client", "POST", "/consents", "idem-1", string(body2))
		req, _ := http.NewRequest("POST", ts.URL+"/consents", bytes.NewReader(body2))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Client-Id", "demo-client")
		req.Header.Set("Idempotency-Key", "idem-1")
		req.Header.Set("X-Signature", sig2)

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != 409 {
			b, _ := io.ReadAll(resp.Body)
			t.Fatalf("atomic: INV-02 expected 409, got %d body=%s", resp.StatusCode, string(b))
		}
	}

	// INV‑03: Client binding on reads (mismatch => 404 non-leak)
	{
		sig := signAs("demo-client-2", "GET", "/consents/"+consentID, "-", "")
		req, _ := http.NewRequest("GET", ts.URL+"/consents/"+consentID, nil)
		req.Header.Set("X-Client-Id", "demo-client-2")
		req.Header.Set("X-Signature", sig)

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		_ = resp.Body.Close()

		if resp.StatusCode != 404 {
			t.Fatalf("atomic: INV-03 expected 404 for cross-client read, got %d", resp.StatusCode)
		}
	}

	// INV‑01 (again): GET requires signature
	{
		req, _ := http.NewRequest("GET", ts.URL+"/consents/"+consentID, nil)
		req.Header.Set("X-Client-Id", "demo-client")
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		_ = resp.Body.Close()
		if resp.StatusCode != 401 {
			t.Fatalf("atomic: INV-01 expected 401 on GET without signature, got %d", resp.StatusCode)
		}
	}

	// INV‑04: response must not leak customer_id
	{
		sig := signAs("demo-client", "GET", "/consents/"+consentID, "-", "")
		req, _ := http.NewRequest("GET", ts.URL+"/consents/"+consentID, nil)
		req.Header.Set("X-Client-Id", "demo-client")
		req.Header.Set("X-Signature", sig)

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		defer resp.Body.Close()
		b, _ := io.ReadAll(resp.Body)
		if bytes.Contains(b, []byte("customer_id")) {
			t.Fatalf("atomic: INV-04 leaked customer_id in response: %s", string(b))
		}
	}

	// INV‑05: expiry sanity
	{
		// invalid RFC3339 -> 400
		bad := map[string]any{
			"customer_id":  "cust-001",
			"scopes":       []string{"accounts.basic:read"},
			"expires_at":   "not-a-time",
			"redirect_uri": "https://example.com/cb",
		}
		bb, _ := json.Marshal(bad)
		sig := signAs("demo-client", "POST", "/consents", "idem-exp-1", string(bb))
		req, _ := http.NewRequest("POST", ts.URL+"/consents", bytes.NewReader(bb))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Client-Id", "demo-client")
		req.Header.Set("Idempotency-Key", "idem-exp-1")
		req.Header.Set("X-Signature", sig)

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		_ = resp.Body.Close()
		if resp.StatusCode != 400 {
			t.Fatalf("atomic: INV-05 expected 400 for invalid expiry, got %d", resp.StatusCode)
		}
	}

	{
		// near-expiry (< now+60s) -> 400
		near := map[string]any{
			"customer_id":  "cust-001",
			"scopes":       []string{"accounts.basic:read"},
			"expires_at":   time.Now().UTC().Add(30 * time.Second).Format(time.RFC3339),
			"redirect_uri": "https://example.com/cb",
		}
		bb, _ := json.Marshal(near)
		sig := signAs("demo-client", "POST", "/consents", "idem-exp-2", string(bb))
		req, _ := http.NewRequest("POST", ts.URL+"/consents", bytes.NewReader(bb))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Client-Id", "demo-client")
		req.Header.Set("Idempotency-Key", "idem-exp-2")
		req.Header.Set("X-Signature", sig)

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		_ = resp.Body.Close()
		if resp.StatusCode != 400 {
			t.Fatalf("atomic: INV-05 expected 400 for near-expiry, got %d", resp.StatusCode)
		}
	}

	// INV‑06: challenge quality (uniqueness + charset)
	{
		re := regexp.MustCompile(`^[A-Za-z0-9_-]+$`)
		seen := map[string]bool{challenge1: true}

		for i := 0; i < 3; i++ {
			idem := "idem-chal-" + itoa(i)
			sig := signAs("demo-client", "POST", "/consents", idem, string(body))
			req, _ := http.NewRequest("POST", ts.URL+"/consents", bytes.NewReader(body))
			req.Header.Set("Content-Type", "application/json")
			req.Header.Set("X-Client-Id", "demo-client")
			req.Header.Set("Idempotency-Key", idem)
			req.Header.Set("X-Signature", sig)

			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				t.Fatalf("request failed: %v", err)
			}
			defer resp.Body.Close()
			if resp.StatusCode != 201 && resp.StatusCode != 200 {
				b, _ := io.ReadAll(resp.Body)
				t.Fatalf("atomic: expected 201/200, got %d body=%s", resp.StatusCode, string(b))
			}
			var out map[string]any
			_ = json.NewDecoder(resp.Body).Decode(&out)
			chal, _ := out["challenge"].(string)
			if chal == "" || len(chal) < 16 {
				t.Fatalf("atomic: INV-06 challenge too short/empty")
			}
			if !re.MatchString(chal) {
				t.Fatalf("atomic: INV-06 challenge has invalid charset: %q", chal)
			}
			if seen[chal] {
				t.Fatalf("atomic: INV-06 challenge repeated: %q", chal)
			}
			seen[chal] = true
		}
	}
}

func signAs(clientID, method, path, idem, body string) string {
	priv := security.DemoPrivateKeyFor(clientID)
	if len(priv) != ed25519.PrivateKeySize {
		panic("bad demo private key")
	}
	canonical := security.Canonical(method, path, idem, body)
	sig := ed25519.Sign(priv, []byte(canonical))
	return base64.StdEncoding.EncodeToString(sig)
}

func itoa(i int) string {
	if i == 0 {
		return "0"
	}
	b := [20]byte{}
	pos := len(b)
	for i > 0 {
		pos--
		b[pos] = byte('0' + (i % 10))
		i /= 10
	}
	return string(b[pos:])
}

func testLogger(t *testing.T) *log.Logger {
	return log.New(io.Discard, "", 0)
}
