# Standards Changelog

## v1.2
- **Conformance Suite**: promoted INV‑05 (expiry sanity) and INV‑06 (challenge quality) to first‑class behavior gates.
- **INV‑03**: expanded to **multi‑client** conformance (cross‑client read must be 404).
- **Evidence output**: `results.jsonl` upgraded to the **extended schema**: `check`, `result`, `severity`, `maps`, optional `notes`.
- **Repo wiring**: added `demo-client-2` keys for deterministic multi‑client tests.
- **EOS runner**: emits conformance + pii_scan results with `maps` back to invariants.

## v1.1
- Added conformance execution and PII scan gate.
- Added standards docs (Conformance + Traceability).
