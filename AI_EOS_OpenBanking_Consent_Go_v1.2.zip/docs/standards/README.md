# Standards (AI‑EOS) — v1.2

- `Evidence_Spec_v1.md` — Evidence Bundle semantics (FPMS-style)
- `Conformance_Suite_Spec_v1.md` — Deterministic conformance checks for the Consent Setup Constitution (updated v1.2)
- `Traceability_Matrix_Consent_Setup_v1.md` / `.csv` — Invariant ↔ Task ↔ Evidence ↔ Gate ↔ Code mapping (updated v1.2)
- `CHANGELOG.md` — Standards change history

v1.2 highlights:
- Multi-client conformance for INV‑03 (cross-client read must be 404)
- INV‑05 and INV‑06 are required behavior gates
- `results.jsonl` emits extended schema: `check,result,severity,maps,notes?`
