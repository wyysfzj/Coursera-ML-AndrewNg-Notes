# Lectures (Case: Open Banking Consent Setup, Go)

- L01 — Why AI breaks traditional governance (failure space)
- L02 — Atomic Task as the minimum governance unit (task system)
- L03 — Taming Copilot with Atomic Tasks (prompt discipline)
- L04 — Evidence Bundles (FPMS-style artifacts)
- L05 — Gate-controlled engineering (deterministic gates)

Deliver with:
- VS Code
- Copilot (GPT‑5)
- This repository
