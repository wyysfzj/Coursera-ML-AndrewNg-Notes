# Lecture 01 — Why AI breaks traditional engineering governance (Open Banking Consent Setup)

## The point
This is not “AI makes mistakes”.
This is: **traditional SDLC governance units (story/PR/review) become invalid under AI throughput and variance.**

## The case surface
We implement **Consent Setup** for an Open Banking-style workflow:

- `POST /consents` creates a consent arrangement in **AWAITING_AUTHORIZATION**
- Response returns: `consent_id`, `challenge`, `expires_at`
- The request must be:
  - **Authenticated** (client identity)
  - **Integrity-protected** (signature)
  - **Idempotent** (Idempotency-Key)
  - **Non-malleable under replay** (idempotency binds request hash)

## Why governance fails under AI
### Failure mode A — “Helpful” abstraction creates replay windows
Copilot’s natural move: cache idempotency keys and “reuse response”.
Result: **idempotency becomes a replay primitive**.

### Failure mode B — Missing cryptographic binding
Copilot might accept `X-Client-Id` without signature verification.
Looks reasonable. Tests might pass. Yet it violates the invariant:
> consent creation must be integrity protected.

### Failure mode C — Open-ended diffs
A single prompt often yields:
- handlers + storage + middleware + error refactors
Review becomes heuristic sampling.

## The Non-Atomic demo
Non-Atomic mode intentionally shows:
- missing signature accepted
- idempotency key can be reused with a different payload

That’s “engineer-friendly” but governance-illegal.

## Transition to AI‑EOS
Therefore:
- governance unit must be **Atomic Tasks**
- trust replaced by **Evidence Bundles**
- merge controlled by **deterministic gates**
