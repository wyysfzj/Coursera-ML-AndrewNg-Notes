#!/usr/bin/env bash
set -euo pipefail

TASK_ID="${1:-}"
if [[ -z "${TASK_ID}" ]]; then
  echo "Usage: tools/eos/eos.sh <TASK_ID>"
  exit 1
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
ART_DIR="${ROOT_DIR}/artifacts/${TASK_ID}"
OUT_DIR="${ART_DIR}/outputs"
GIT_DIR="${ART_DIR}/git"

mkdir -p "${OUT_DIR}" "${GIT_DIR}"

ts() { date -u +"%Y%m%dT%H%M%SZ"; }

COMMANDS_FILE="${ART_DIR}/commands.jsonl"
RESULTS_FILE="${ART_DIR}/results.jsonl"
SUMMARY_FILE="${ART_DIR}/summary.md"

: > "${COMMANDS_FILE}"
: > "${RESULTS_FILE}"

record_cmd() {
  local cmd="$1"
  echo "{\"ts\":\"$(ts)\",\"cmd\":\"${cmd//\"/\\\"}\"}" >> "${COMMANDS_FILE}"
}

run_and_capture() {
  local name="$1"; shift
  local logfile="${OUT_DIR}/$(ts)_${name}.log"
  local cmd="$*"
  record_cmd "${cmd}"
  set +e
  bash -lc "${cmd}" > "${logfile}" 2>&1
  local ec=$?
  set -e
  echo "${ec}" > "${logfile}.exitcode"
  return "${ec}"
}

# Git evidence
record_cmd "git rev-parse HEAD"
git rev-parse HEAD > "${GIT_DIR}/rev.txt"
record_cmd "git status --porcelain"
git status --porcelain > "${GIT_DIR}/status.txt"
record_cmd "git diff"
git diff > "${GIT_DIR}/diff.patch"

fmt_ec=0
vet_ec=0
test_ec=0
diff_ec=0

run_and_capture "format" "test -z \"\$(gofmt -l .)\""; fmt_ec=$? || true
run_and_capture "vet" "go vet ./..."; vet_ec=$? || true
run_and_capture "test" "go test ./..."; test_ec=$? || true

# Conformance (behavior gates for constitutional invariants)
conf_ec=0
run_and_capture "conformance" "EOS_MODE=atomic go test ./tests -run TestInvariants -v"; conf_ec=$? || true

# PII scan (static heuristic; excludes training-only non_atomic by default)
pii_ec=0
run_and_capture "pii_scan" "bash tools/eos/gates/pii_scan.sh"; pii_ec=$? || true

ALLOW_FILES="${ALLOW_FILES:-}"
if [[ -n "${ALLOW_FILES}" ]]; then
  run_and_capture "diff_gate" "bash tools/eos/gates/diff_gate.sh \"${ALLOW_FILES}\""; diff_ec=$? || true
else
  record_cmd "diff gate skipped (ALLOW_FILES not set)"
fi


jsonl() {
  local check="$1" result="$2" severity="$3" maps="$4" notes="${5:-}"
  # maps is a JSON array string, e.g. '["INV-01","INV-02"]'
  if [[ -z "${notes}" ]]; then
    echo "{\"check\":\"${check}\",\"result\":\"${result}\",\"severity\":\"${severity}\",\"maps\":${maps}}" >> "${RESULTS_FILE}"
  else
    # Escape quotes inside notes to keep JSON valid.
    echo "{\"check\":\"${check}\",\"result\":\"${result}\",\"severity\":\"${severity}\",\"maps\":${maps},\"notes\":\"${notes//\"/\\\"}\"}" >> "${RESULTS_FILE}"
  fi
}



# Write machine-readable results (extended schema)
# Severity policy (teaching defaults):
# - format/vet/test/diff_scope/conformance are BLOCKER
# - pii_scan is CRITICAL (blocks release; recommended BLOCKER in regulated envs)
# Maps provide traceability back to constitutional invariants.

[[ "${fmt_ec}" -eq 0 ]] && jsonl "format" "pass" "BLOCKER" '["GOV-BASELINE"]' || jsonl "format" "fail" "BLOCKER" '["GOV-BASELINE"]'
[[ "${vet_ec}" -eq 0 ]] && jsonl "vet" "pass" "BLOCKER" '["GOV-BASELINE"]' || jsonl "vet" "fail" "BLOCKER" '["GOV-BASELINE"]'
[[ "${test_ec}" -eq 0 ]] && jsonl "test" "pass" "BLOCKER" '["GOV-BASELINE"]' || jsonl "test" "fail" "BLOCKER" '["GOV-BASELINE"]'
[[ "${conf_ec}" -eq 0 ]] && jsonl "conformance" "pass" "BLOCKER" '["INV-01","INV-02","INV-03","INV-04","INV-05","INV-06"]' || jsonl "conformance" "fail" "BLOCKER" '["INV-01","INV-02","INV-03","INV-04","INV-05","INV-06"]'
[[ "${pii_ec}" -eq 0 ]] && jsonl "pii_scan" "pass" "CRITICAL" '["INV-04"]' || jsonl "pii_scan" "fail" "CRITICAL" '["INV-04"]'

if [[ -n "${ALLOW_FILES}" ]]; then
  [[ "${diff_ec}" -eq 0 ]] && jsonl "diff_scope" "pass" "BLOCKER" '["AI-EOS-SCOPE"]' || jsonl "diff_scope" "fail" "BLOCKER" '["AI-EOS-SCOPE"]'
fi

if [[ ! -f "${SUMMARY_FILE}" ]]; then
  cp "${ROOT_DIR}/artifacts/_template/summary.md" "${SUMMARY_FILE}"
fi

echo "Evidence Bundle written to: ${ART_DIR}"
echo "Gate inputs: ${RESULTS_FILE}"
