#!/usr/bin/env bash
set -euo pipefail

# Teaching-grade heuristic scan for common PII leakage patterns in the **atomic** code paths.
# Excludes internal/non_atomic (training-only).
#
# Design goal:
# - deterministic
# - low false-positive rate
# - blocks the most common AI-introduced failure: "log the whole request for debugging"

paths=(
  "internal/httpapi"
  "internal/atomic"
  "internal/audit"
)

# Deterministic regex patterns.
# NOTE: We intentionally do NOT scan for bare 'customer_id' because it appears in JSON struct tags.
patterns=(
  # raw payload logging
  "Printf\\(.*%s.*raw"
  "Printf\\(.*%s.*body"
  "logger\\.Printf\\(.*%s.*raw"
  "logger\\.Printf\\(.*%s.*body"

  # logging marshaled requests (common debug anti-pattern)
  "logger\\.Printf\\(.*req=%s"
  "Printf\\(.*req=%s"
  "json\\.Marshal\\(req\\)"

  # explicit customer_id in logging statements (more specific than scanning struct tags)
  "logger\\.Printf\\(.*customer_id"
  "Printf\\(.*customer_id"
  "Println\\(.*customer_id"
)

bad=0

for p in "${paths[@]}"; do
  if [[ ! -d "${p}" ]]; then
    continue
  fi
  for pat in "${patterns[@]}"; do
    hits="$(grep -RIn --include='*.go' -E "${pat}" "${p}" || true)"
    if [[ -n "${hits}" ]]; then
      echo "PII_SCAN_HIT pattern=${pat}"
      echo "${hits}"
      bad=1
    fi
  done
done

if [[ "${bad}" -ne 0 ]]; then
  exit 1
fi

echo "pii_scan: ok"
