package main

import (
	"crypto/ed25519"
	"encoding/base64"
	"flag"
	"fmt"

	"ai-eos-openbanking-consent/internal/security"
)

func main() {
	clientID := flag.String("client-id", "demo-client", "demo client id (demo-client or demo-client-2)")
	method := flag.String("method", "POST", "HTTP method")
	path := flag.String("path", "/consents", "HTTP path")
	idempotency := flag.String("idempotency", "-", "Idempotency-Key (or '-')")
	body := flag.String("body", "", "raw JSON body")
	flag.Parse()

	priv := security.DemoPrivateKeyFor(*clientID)
	if len(priv) != ed25519.PrivateKeySize {
		panic("bad demo private key")
	}

	canonical := security.Canonical(*method, *path, *idempotency, *body)
	sig := ed25519.Sign(priv, []byte(canonical))
	fmt.Print(base64.StdEncoding.EncodeToString(sig))
}
