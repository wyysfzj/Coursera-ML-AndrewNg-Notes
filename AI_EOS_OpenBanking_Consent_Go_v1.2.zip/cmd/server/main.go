package main

import (
	"context"
	"flag"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"ai-eos-openbanking-consent/internal/httpapi"
)

func main() {
	addr := flag.String("addr", ":8080", "listen address")
	flag.Parse()

	mode := os.Getenv("EOS_MODE")
	if mode == "" {
		mode = "atomic"
	}

	logger := log.New(os.Stdout, "", log.LstdFlags)
	h := httpapi.NewHandler(mode, logger)

	srv := &http.Server{
		Addr:         *addr,
		Handler:      h,
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 10 * time.Second,
	}

	go func() {
		logger.Printf("server starting mode=%s addr=%s", mode, *addr)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Fatalf("listen: %v", err)
		}
	}()

	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGINT, syscall.SIGTERM)
	<-stop

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	logger.Printf("server stopping")
	_ = srv.Shutdown(ctx)
}
