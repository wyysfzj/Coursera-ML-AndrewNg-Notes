# Evidence Bundle Template

Each atomic task produces:
`artifacts/<TASK_ID>/...`

This directory provides templates only.
