package com.example.catalog.service;
import com.fasterxml.jackson.databind.*; import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import org.springframework.stereotype.Component; import java.util.*; import java.util.regex.*;
@Component public class SpecParser {
  private final ObjectMapper yaml = new ObjectMapper(new YAMLFactory());
  private final ObjectMapper json = new ObjectMapper();
  public enum SpecKind { openapi, graphql, asyncapi, grpc, unknown }
  public record Endpoint(String method, String path) {}
  public SpecKind detectKind(String filename, String content){
    String lower = filename.toLowerCase(Locale.ROOT);
    if (lower.endsWith(".graphql") || content.contains("type Query") || content.contains("schema {")) return SpecKind.graphql;
    try { JsonNode n = parseYamlOrJson(content); if (n!=null){ if (n.has("openapi")) return SpecKind.openapi; if (n.has("asyncapi")) return SpecKind.asyncapi; } } catch(Exception ignore){}
    return SpecKind.unknown;
  }
  public JsonNode parseYamlOrJson(String s) throws Exception { if (s.trim().startsWith("{")) return json.readTree(s); return yaml.readTree(s); }
  public java.util.List<Endpoint> extractOpenApi(JsonNode root){
    java.util.List<Endpoint> out = new java.util.ArrayList<>(); if (root==null || !root.has("paths")) return out;
    JsonNode paths = root.get("paths"); java.util.Iterator<String> it = paths.fieldNames();
    while(it.hasNext()){ String p = it.next(); JsonNode pathItem = paths.get(p);
      for(String m: java.util.List.of("get","post","put","delete","patch","options","head","trace")){
        if (pathItem.has(m)) out.add(new Endpoint(m.toUpperCase(Locale.ROOT), p));
      }
    } return out;
  }
  public java.util.List<Endpoint> extractGraphQL(String sdl){
    java.util.List<Endpoint> out = new java.util.ArrayList<>(); java.util.regex.Pattern block = java.util.regex.Pattern.compile("type\s+(Query|Mutation)\s*\{([^}]*)\}", java.util.regex.Pattern.MULTILINE);
    var mt = block.matcher(sdl); while (mt.find()){ String kind = mt.group(1).toUpperCase(Locale.ROOT); String body = mt.group(2);
      for (String line : body.split("\n")){ String l = line.trim(); if (l.isEmpty() || l.startsWith("#")) continue;
        String name = l.split("\(")[0].split(":")[0].trim(); if (!name.isEmpty()) out.add(new Endpoint(kind, name)); } }
    return out;
  }
}