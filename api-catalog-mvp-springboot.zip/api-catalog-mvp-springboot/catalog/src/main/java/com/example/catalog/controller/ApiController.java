package com.example.catalog.controller;
import com.example.catalog.domain.ApiEntity; import com.example.catalog.repo.*; import lombok.RequiredArgsConstructor; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequiredArgsConstructor public class ApiController {
  private final ApiRepository apiRepo; private final ApiVersionRepository verRepo;
  @GetMapping("/apis") public java.util.Map<String,Object> list(){ java.util.List<ApiEntity> all = apiRepo.findAll(); return java.util.Map.of("items", all); }
  @GetMapping("/apis/{id}") public java.util.Map<String,Object> one(@PathVariable java.util.UUID id){ ApiEntity api = apiRepo.findById(id).orElseThrow(); return java.util.Map.of("api", api, "versions", api.getVersions(), "tags", api.getTags()); }
}