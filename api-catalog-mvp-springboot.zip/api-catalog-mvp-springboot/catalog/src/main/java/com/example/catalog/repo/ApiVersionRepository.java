package com.example.catalog.repo;
import com.example.catalog.domain.*; import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional; import java.util.UUID;
public interface ApiVersionRepository extends JpaRepository<ApiVersionEntity, UUID> {
  Optional<ApiVersionEntity> findByApiAndVersion(ApiEntity api, String version);
}