package com.example.catalog.domain;
import jakarta.persistence.*; import lombok.*; import java.time.Instant;
@Entity @Table(name="api_versions", uniqueConstraints=@UniqueConstraint(columnNames={"api_id","version"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ApiVersionEntity {
  @Id @GeneratedValue private java.util.UUID id;
  @ManyToOne(optional=false) @JoinColumn(name="api_id") private ApiEntity api;
  @Column(nullable=false) private String version;
  @Column(nullable=false) private String status;
  @Column(nullable=false) private String kind;
  @Column(name="spec_uri", nullable=false) private String specUri;
  @Column(name="spec_sha256", nullable=false) private String specSha256;
  @Column(name="published_by") private String publishedBy;
  @Column(name="published_at") private Instant publishedAt;
}