package com.example.catalog.config;
import org.springframework.context.annotation.*; import org.springframework.beans.factory.annotation.Value;
import software.amazon.awssdk.auth.credentials.*; import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.*; import software.amazon.awssdk.services.s3.S3Configuration;
import java.net.URI;
@Configuration public class S3Config {
  @Bean S3Client s3Client(@Value("${app.s3.endpoint}") String endpoint, @Value("${app.s3.region}") String region,
    @Value("${app.s3.accessKey}") String accessKey, @Value("${app.s3.secretKey}") String secretKey,
    @Value("${app.s3.pathStyle:true}") boolean pathStyle) {
    return S3Client.builder()
      .credentialsProvider(StaticCredentialsProvider.create(AwsBasicCredentials.create(accessKey, secretKey)))
      .endpointOverride(URI.create(endpoint)).region(Region.of(region))
      .serviceConfiguration(S3Configuration.builder().pathStyleAccessEnabled(pathStyle).build()).build();
  }
}