package com.example.catalog.search;
import lombok.RequiredArgsConstructor; import org.opensearch.client.opensearch.OpenSearchClient;
import org.opensearch.client.opensearch.core.SearchRequest; import org.opensearch.client.opensearch.core.SearchResponse;
import org.opensearch.client.json.JsonData; import org.springframework.beans.factory.annotation.Value; import org.springframework.stereotype.Service;
import java.io.StringReader; import java.util.Map;
@Service @RequiredArgsConstructor public class SearchService {
  private final OpenSearchClient client; @Value("${app.opensearch.index-alias}") String alias;
  public String search(String q, Map<String,String> filters) throws Exception {
    String query = (q==null) ? "" : q.replace(""","\\"");
    StringBuilder filterJson = new StringBuilder();
    for (var e: filters.entrySet()) { if (!filterJson.isEmpty()) filterJson.append(","); filterJson.append("{\"term\":{\"").append(e.getKey()).append("\":\"").append(e.getValue()).append("\"}}"); }
    String body = "{\n  \"size\": 10,\n  \"query\": { \"bool\": { \"must\": [ { \"multi_match\": { \"query\": \"" + query + "\", \"fields\": [\"name^4\",\"summary^2\",\"endpoints.path\"] } } ], \"filter\": [ " + filterJson.toString() + " ] } },\n  \"aggs\": { \"by_domain\": { \"terms\": { \"field\": \"domain\" } }, \"by_type\": { \"terms\": { \"field\": \"type\" } }, \"by_status\": { \"terms\": { \"field\": \"status\" } } }\n}";
    SearchRequest req = SearchRequest.of(s -> s.index(alias).withJson(new StringReader(body))); SearchResponse<JsonData> res = client.search(req, JsonData.class); return res.toString();
  }
}