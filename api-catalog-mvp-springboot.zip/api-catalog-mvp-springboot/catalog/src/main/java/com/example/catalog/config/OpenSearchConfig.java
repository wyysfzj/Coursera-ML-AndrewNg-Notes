package com.example.catalog.config;
import com.fasterxml.jackson.databind.ObjectMapper; import org.apache.http.HttpHost;
import org.opensearch.client.json.jackson.JacksonJsonpMapper; import org.opensearch.client.transport.OpenSearchTransport;
import org.opensearch.client.transport.rest_client.RestClientTransport; import org.opensearch.client.RestClient;
import org.opensearch.client.opensearch.OpenSearchClient; import org.springframework.context.annotation.*;
@Configuration public class OpenSearchConfig {
  @Bean OpenSearchClient openSearchClient(){
    RestClient rest = RestClient.builder(HttpHost.create("http://localhost:9200")).build();
    OpenSearchTransport t = new RestClientTransport(rest, new JacksonJsonpMapper(new ObjectMapper()));
    return new OpenSearchClient(t);
  }
}