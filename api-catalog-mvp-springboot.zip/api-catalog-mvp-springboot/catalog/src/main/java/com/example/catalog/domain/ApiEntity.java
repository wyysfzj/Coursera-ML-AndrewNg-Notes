package com.example.catalog.domain;
import jakarta.persistence.*; import lombok.*; import java.util.*;
@Entity @Table(name="apis") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ApiEntity {
  @Id @GeneratedValue private java.util.UUID id;
  @Column(name="api_key", unique=true, nullable=false) private String apiKey;
  @Column(name="display_name", nullable=false) private String displayName;
  private String summary; private String domain;
  @Column(name="owner_team", nullable=false) private String ownerTeam;
  @Column(name="lifecycle_status", nullable=false) private String lifecycleStatus;
  @Column(name="default_version") private String defaultVersion;
  @ElementCollection @CollectionTable(name="api_tags", joinColumns=@JoinColumn(name="api_id")) @Column(name="tag")
  private java.util.Set<String> tags = new java.util.HashSet<>();
  @OneToMany(mappedBy="api", cascade=CascadeType.ALL, orphanRemoval=true, fetch=FetchType.LAZY)
  private java.util.List<ApiVersionEntity> versions = new java.util.ArrayList<>();
}