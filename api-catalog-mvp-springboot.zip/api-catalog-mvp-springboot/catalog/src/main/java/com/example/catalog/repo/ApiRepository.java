package com.example.catalog.repo;
import com.example.catalog.domain.ApiEntity; import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional; import java.util.UUID;
public interface ApiRepository extends JpaRepository<ApiEntity, UUID> { Optional<ApiEntity> findByApiKey(String apiKey); }