package com.example.catalog.service;
import com.example.catalog.domain.*; import com.example.catalog.repo.*; import com.example.catalog.service.SpecParser.*; import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional; import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.services.s3.*; import software.amazon.awssdk.core.sync.RequestBody; import software.amazon.awssdk.services.s3.model.*;
import java.nio.charset.StandardCharsets; import java.security.MessageDigest; import java.time.Instant; import java.util.*;
@Service @RequiredArgsConstructor public class UploadService {
  private final ApiRepository apiRepo; private final ApiVersionRepository verRepo; private final SpecParser parser; private final S3Client s3;
  @org.springframework.beans.factory.annotation.Value("${app.s3.bucket}") String bucket;
  public record SearchDoc(java.util.UUID apiId, String name, String summary, String type, String domain,
                   String ownerTeam, String status, java.util.List<java.util.Map<String,String>> endpoints,
                   java.util.List<String> tags, String version, String specUri, String updatedAt) {}
  @Transactional public UploadResult handleUpload(String displayName, String summary, String domain,
                                   String ownerTeam, String type, String version,
                                   java.util.List<String> tags, MultipartFile specFile) throws Exception {
    String apiKey = slugify(displayName); byte[] bytes = specFile.getBytes(); String sha256 = sha256Hex(bytes);
    String orig = specFile.getOriginalFilename(); String safeName = (orig==null||orig.isBlank()) ? "openapi.yaml" : orig.replaceAll("[^a-zA-Z0-9._-]","_");
    String key = "specs/" + apiKey + "/" + version + "/" + safeName; ensureBucket(bucket);
    s3.putObject(PutObjectRequest.builder().bucket(bucket).key(key).build(), RequestBody.fromBytes(bytes));
    String specUri = "s3://" + bucket + "/" + key;
    String content = new String(bytes, StandardCharsets.UTF_8);
    SpecKind detected = parser.detectKind(safeName, content);
    if (detected == SpecKind.unknown) throw new IllegalArgumentException("Unsupported or invalid spec");
    java.util.List<Endpoint> eps = (detected == SpecKind.openapi) ? parser.extractOpenApi(parser.parseYamlOrJson(content))
      : (detected == SpecKind.graphql) ? parser.extractGraphQL(content) : java.util.List.of();
    ApiEntity api = apiRepo.findByApiKey(apiKey).orElseGet(() -> ApiEntity.builder().apiKey(apiKey).displayName(displayName).ownerTeam(ownerTeam).lifecycleStatus("published").build());
    api.setDisplayName(displayName); api.setSummary(summary); api.setDomain(domain); api.setOwnerTeam(ownerTeam); api.getTags().addAll(tags); api.setDefaultVersion(version); api = apiRepo.save(api);
    ApiVersionEntity ver = verRepo.findByApiAndVersion(api, version).orElseGet(() -> ApiVersionEntity.builder().api(api).version(version).status("published").build());
    ver.setKind(detected.name()); ver.setSpecUri(specUri); ver.setSpecSha256(sha256); ver.setPublishedBy("uploader"); ver.setPublishedAt(Instant.now()); verRepo.save(ver);
    java.util.List<java.util.Map<String,String>> epMaps = new java.util.ArrayList<>(); for (Endpoint e : eps) epMaps.add(java.util.Map.of("method", e.method(), "path", e.path()));
    SearchDoc doc = new SearchDoc(api.getId(), displayName, summary, type, domain, ownerTeam, "published", epMaps, tags, version, specUri, Instant.now().toString());
    return new UploadResult(api.getId(), version, specUri, sha256, doc);
  }
  private void ensureBucket(String bucket){ try { s3.headBucket(h->h.bucket(bucket)); } catch(software.amazon.awssdk.services.s3.model.NoSuchBucketException e){ s3.createBucket(c->c.bucket(bucket)); } }
  private String slugify(String s){ return s.toLowerCase().replaceAll("[^a-z0-9]+","-").replaceAll("(^-|-$)",""); }
  private String sha256Hex(byte[] b) throws Exception { var md = java.security.MessageDigest.getInstance("SHA-256"); byte[] d = md.digest(b); var sb=new StringBuilder(); for(byte x: d) sb.append(String.format("%02x",x)); return sb.toString(); }
  public record UploadResult(java.util.UUID apiId, String version, String specUri, String sha256, SearchDoc doc) {}
}