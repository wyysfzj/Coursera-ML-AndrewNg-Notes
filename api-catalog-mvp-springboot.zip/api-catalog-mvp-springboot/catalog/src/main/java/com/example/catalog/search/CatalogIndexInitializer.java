package com.example.catalog.search;
import jakarta.annotation.PostConstruct; import lombok.RequiredArgsConstructor; import org.opensearch.client.opensearch.OpenSearchClient;
import org.springframework.beans.factory.annotation.Value; import org.springframework.stereotype.Component;
@Component @RequiredArgsConstructor public class CatalogIndexInitializer {
  private final OpenSearchClient client;
  @Value("${app.opensearch.index-name}") String indexName; @Value("${app.opensearch.index-alias}") String indexAlias;
  @PostConstruct public void init() throws Exception {
    if (client.indices().existsAlias(e->e.name(indexAlias)).value()) return;
    String body = "{\"settings\":{\"analysis\":{\"analyzer\":{\"path_analyzer\":{\"type\":\"custom\",\"tokenizer\":\"path_hierarchy\",\"filter\":[\"lowercase\"]},\"catalog_text\":{\"type\":\"custom\",\"tokenizer\":\"standard\",\"filter\":[\"lowercase\"]}}}},\"mappings\":{\"properties\":{\"apiId\":{\"type\":\"keyword\"},\"name\":{\"type\":\"text\",\"analyzer\":\"catalog_text\",\"fields\":{\"kw\":{\"type\":\"keyword\"}}},\"summary\":{\"type\":\"text\",\"analyzer\":\"catalog_text\"},\"type\":{\"type\":\"keyword\"},\"domain\":{\"type\":\"keyword\"},\"owner_team\":{\"type\":\"keyword\"},\"tags\":{\"type\":\"keyword\"},\"status\":{\"type\":\"keyword\"},\"version\":{\"type\":\"keyword\"},\"endpoints\":{\"properties\":{\"method\":{\"type\":\"keyword\"},\"path\":{\"type\":\"text\",\"analyzer\":\"path_analyzer\"}}},\"updated_at\":{\"type\":\"date\"}}}}";
    if (!client.indices().exists(e->e.index(indexName)).value()) client.indices().create(c->c.index(indexName).withJson(new java.io.StringReader(body)));
    client.indices().putAlias(a->a.index(indexName).name(indexAlias));
  }
}