package com.example.catalog.controller;
import com.example.catalog.service.UploadService; import lombok.RequiredArgsConstructor;
import org.opensearch.client.opensearch.OpenSearchClient; import org.opensearch.client.opensearch.core.IndexRequest;
import org.springframework.beans.factory.annotation.Value; import org.springframework.http.MediaType; import org.springframework.web.bind.annotation.*; import org.springframework.web.multipart.MultipartFile;
import java.util.*;
@RestController @RequiredArgsConstructor public class UploadController {
  private final UploadService uploadService; private final OpenSearchClient osClient;
  @Value("${app.opensearch.index-alias}") String alias; @Value("${app.admin-token}") String adminToken;
  @PostMapping(path="/upload", consumes=MediaType.MULTIPART_FORM_DATA_VALUE) public Map<String,Object> upload(
    @RequestHeader(name="X-Admin-Token", required=false) String token, @RequestParam String displayName, @RequestParam String summary,
    @RequestParam String domain, @RequestParam String ownerTeam, @RequestParam(defaultValue="REST") String type,
    @RequestParam String version, @RequestParam(required=false) String tags, @RequestParam MultipartFile spec) throws Exception {
    if (adminToken!=null && !adminToken.isBlank()) if (token==null || !token.equals(adminToken)) throw new org.springframework.web.server.ResponseStatusException(org.springframework.http.HttpStatus.UNAUTHORIZED, "Invalid token");
    java.util.List<String> tagList = (tags==null || tags.isBlank()) ? java.util.List.of() : java.util.Arrays.stream(tags.split(",")).map(String::trim).filter(s->!s.isEmpty()).toList();
    var result = uploadService.handleUpload(displayName, summary, domain, ownerTeam, type.toUpperCase(), version, tagList, spec);
    var idx = IndexRequest.of(i->i.index(alias).id(result.apiId().toString()).document(result.doc())); osClient.index(idx);
    return java.util.Map.of("apiId", result.apiId(), "version", result.version(), "specUri", result.specUri(), "sha256", result.sha256());
  }
}