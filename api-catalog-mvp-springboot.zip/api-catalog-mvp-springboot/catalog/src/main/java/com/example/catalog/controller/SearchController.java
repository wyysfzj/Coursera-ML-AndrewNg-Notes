package com.example.catalog.controller;
import com.example.catalog.search.SearchService; import lombok.RequiredArgsConstructor; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequiredArgsConstructor public class SearchController {
  private final SearchService searchService;
  @GetMapping("/search") public String search(@RequestParam(required=false) String q, @RequestParam(required=false) String filters) throws Exception {
    Map<String,String> f = new LinkedHashMap<>(); if (filters!=null && !filters.isBlank()) for (String kv: filters.split(",")){ String[] parts = kv.split(":"); if (parts.length==2) f.put(parts[0], parts[1]); }
    return searchService.search(q, f);
  }
}