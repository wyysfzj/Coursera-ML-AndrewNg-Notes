# API Catalog MVP (Java Spring Boot)
## Start infra
docker compose up -d
## Run app
cd catalog
./mvnw spring-boot:run  # or: mvn spring-boot:run
## Upload
curl -X POST "http://localhost:8080/upload" -H "X-Admin-Token: dev-upload-token" -F "displayName=Payments API" -F "summary=Create and refund payments" -F "domain=payments" -F "ownerTeam=fintech-core" -F "type=REST" -F "version=1.2.0" -F "tags=refunds,pci" -F "spec=@./openapi.yaml"
## Search
http://localhost:8080/search?q=refund&filters=domain:payments,status:published
## List
http://localhost:8080/apis
