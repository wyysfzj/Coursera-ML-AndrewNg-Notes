
# OB‑AT‑03 — PII Minimization and Logging Control

## Objective
- Ensure that no sensitive data (e.g., `customer_id`) is included in the response or logs.
- Implement logging control to redact any sensitive data before it is written to the logs.

## Static Gate
- **Check**: Ensure that no raw request body or `customer_id` is logged.
- **Location**: Verify logging control and data redaction mechanisms in `internal/httpapi/handler.go` and `internal/atomic/consent/service.go`.

## Behavior Gate
- **Check**: Confirm that `customer_id` does not appear in the response or logs.
- **Location**: Perform runtime tests to ensure no sensitive data is leaked in responses or logs.

## Scope (allowed files)
- `internal/httpapi/handler.go`
- `internal/atomic/consent/service.go`

## Forbidden Moves (negative constraints)
- No raw request body logging.
- No `customer_id` in response or logs.

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-03/commands.jsonl`
- `artifacts/OB-AT-03/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-03/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-03/results.jsonl`
- `artifacts/OB-AT-03/summary.md`

## Gates
- **Static Gate**: Ensure that no raw request body or `customer_id` is logged.
- **Behavior Gate**: Confirm that `customer_id` does not appear in the response or logs.

## Prompt for Copilot
```markdown
Ensure that sensitive data such as `customer_id` is not logged or exposed in the response.
Implement a redaction mechanism for logging and responses to prevent leaking sensitive data.
```

## CURL Example
```bash
curl -s -X GET -H "X-Client-Id: demo-client" -H "X-Signature: <signature>" http://localhost:8080/consents/{consent_id}
```

## Definition of Done
- Task scope completed.
- Forbidden moves not present.
- Evidence Bundle generated and gates pass.
