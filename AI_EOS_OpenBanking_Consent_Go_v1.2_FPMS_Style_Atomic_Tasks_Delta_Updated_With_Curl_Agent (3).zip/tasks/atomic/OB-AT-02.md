
# OB‑AT‑02 — Idempotency Key + Request Hash Binding

## Objective
- Implement the functionality to bind the Idempotency-Key to the request hash, ensuring that requests with the same key and request hash return the same response.
- Reject requests with the same Idempotency-Key and different request hashes, returning a `409 Conflict`.

## Static Gate
- **Check**: Verify the request hash binding logic is implemented correctly in `idempotency.go`.
- **Location**: Ensure the logic for binding Idempotency-Key to the request hash is implemented in `internal/atomic/consent/idempotency.go`.

## Behavior Gate
- **Check**: Perform runtime tests to confirm that requests with the same Idempotency-Key but different payloads return a `409 Conflict`.
- **Location**: Verify the behavior through testing that different payloads with the same Idempotency-Key return the appropriate status code.

## Scope (allowed files)
- `internal/atomic/consent/idempotency.go`
- `internal/atomic/consent/store.go`

## Forbidden moves (negative constraints)
- No upsert logic without binding request hash.
- No returning existing response without checking request hash.

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-02/commands.jsonl`
- `artifacts/OB-AT-02/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-02/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-02/results.jsonl`
- `artifacts/OB-AT-02/summary.md`

## Gates
- **Static Gate**: Verify the request hash binding logic is implemented correctly in `idempotency.go`.
- **Behavior Gate**: Test that requests with the same Idempotency-Key but different payloads return a `409 Conflict`.

## Prompt for Copilot
```markdown
Implement the functionality to bind the Idempotency-Key to the request hash.
Ensure that requests with the same key and request hash return the same response.
If the Idempotency-Key is the same but the request hash differs, return `409 Conflict`.
```

## CURL Example
```bash
curl -s -X POST -H "Content-Type: application/json" -H "Idempotency-Key: test-key-1" -d '{"customer_id":"c1","scopes":["accounts.read"],"expires_at":"2030-01-01T00:00:00Z"}' http://localhost:8080/consents
curl -s -X POST -H "Content-Type: application/json" -H "Idempotency-Key: test-key-1" -d '{"customer_id":"c1","scopes":["accounts.write"],"expires_at":"2030-01-01T00:00:00Z"}' http://localhost:8080/consents
```

## Definition of Done
- Task scope completed.
- Forbidden moves not present.
- Evidence Bundle generated and gates pass.
