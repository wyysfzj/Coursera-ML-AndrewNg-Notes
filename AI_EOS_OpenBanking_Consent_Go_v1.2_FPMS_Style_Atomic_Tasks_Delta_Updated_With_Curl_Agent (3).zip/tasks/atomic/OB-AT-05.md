
# OB‑AT‑05 — Consent Retrieval and Client Binding (GET /consents/{consent_id})

## Objective
- Implement the `GET /consents/{consent_id}` endpoint to retrieve consent by `consent_id`.
- Ensure that the client retrieving consent is the one who created it (client binding).
- Return `404` for any other client attempting to access the consent.

## Static Gate
- **Check**: Ensure no consent listing endpoints exist.
- **Location**: Verify that the code ensures client binding by checking the `client_id` associated with `consent_id`.

## Behavior Gate
- **Check**: Confirm that a cross-client access attempt results in `404`.
- **Location**: Test that any client that did not create the consent receives a `404 Not Found`.

## Scope (allowed files)
- `internal/httpapi/handler.go`
- `internal/atomic/consent/service.go`

## Forbidden Moves (negative constraints)
- No listing of consents.
- No admin bypass.

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-05/commands.jsonl`
- `artifacts/OB-AT-05/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-05/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-05/results.jsonl`
- `artifacts/OB-AT-05/summary.md`

## Gates
- **Behavior Gate**: Ensure that cross-client access results in `404`.
- **Static Gate**: Ensure no admin bypass exists.

## Prompt for Copilot
```markdown
Implement the `GET /consents/{consent_id}` endpoint.
Ensure that only the client who created the consent can retrieve it.
For any other client, return a `404` error.
```

## CURL Example
```bash
curl -s -X GET -H "X-Client-Id: demo-client" http://localhost:8080/consents/{consent_id}
```

## Definition of Done
- Task scope completed.
- Forbidden moves not present.
- Evidence Bundle generated and gates pass.
