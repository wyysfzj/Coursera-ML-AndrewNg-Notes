
# OB‑AT‑04 — Consent Creation and Idempotency Enforcement (POST /consents)

## Objective
- Implement the `POST /consents` endpoint to create a consent.
- Ensure that the consent creation is idempotent, validates the necessary fields, and returns a `201` response with `consent_id`, `expires_at`, and `challenge`.

## Static Gate
- **Check**: Ensure there are no unnecessary endpoint implementations.
- **Location**: Verify that no extra endpoints or unneeded state machine logic are added in `internal/httpapi/handler.go`.

## Behavior Gate
- **Check**: Test that the `POST /consents` request returns `201` with the correct fields.
- **Location**: Confirm via runtime testing that the response includes `consent_id`, `expires_at`, and `challenge`.

## Scope (allowed files)
- `internal/httpapi/handler.go`
- `internal/atomic/consent/service.go`

## Forbidden moves (negative constraints)
- No GET implementation.
- No additional endpoints.
- No state machine framework (keep simple).

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-04/commands.jsonl`
- `artifacts/OB-AT-04/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-04/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-04/results.jsonl`
- `artifacts/OB-AT-04/summary.md`

## Gates
- **Behavior Gate**: Ensure that the `POST /consents` request returns `201` with the correct fields.
- **Static Gate**: Ensure no unnecessary code is introduced.

## Prompt for Copilot
```markdown
Implement the `POST /consents` endpoint to create a consent.
Ensure the consent creation is idempotent and returns the required fields: `consent_id`, `expires_at`, and `challenge`.
If the request is missing the required fields or the Idempotency-Key is incorrect, return `409 Conflict`.
```

## CURL Example
```bash
curl -s -X POST -H "Content-Type: application/json" -H "Idempotency-Key: test-key" -d '{"customer_id":"c1","scopes":["accounts.read"],"expires_at":"2030-01-01T00:00:00Z"}' http://localhost:8080/consents
```

## Definition of Done
- Task scope completed.
- Forbidden moves not present.
- Evidence Bundle generated and gates pass.
