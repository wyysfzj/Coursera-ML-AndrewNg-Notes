
# OB‑AT‑01 — Request Signature Verification (Ed25519)

## Objective
- Implement signature verification for `POST /consents` requests using Ed25519 for client authentication.
- Ensure that requests are signed, and reject any requests that are not properly signed.

## Static Gate
- **Check**: Ensure that the signature verification logic is correctly implemented in the `signature.go` file.
- **Location**: Verify that `internal/atomic/consent/signature.go` includes the necessary signature validation logic.

## Behavior Gate
- **Check**: Test that unsigned requests are rejected (should return `401`).
- **Location**: Perform runtime tests to confirm that unsigned requests are rejected by the server.

## Scope (allowed files)
- `internal/security/registry.go`
- `internal/atomic/consent/signature.go`

## Forbidden moves (negative constraints)
- No fallback authentication methods
- No accepting unsigned requests

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-01/commands.jsonl`
- `artifacts/OB-AT-01/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-01/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-01/results.jsonl`
- `artifacts/OB-AT-01/summary.md`

## Gates
- **Static Gate**: Ensure that the signature verification logic is correctly implemented in the `signature.go` file.
- **Behavior Gate**: Test that unsigned requests are rejected (should return `401`).

## Prompt for Copilot
```markdown
Implement signature verification for `POST /consents` requests using Ed25519 for client authentication.
Ensure that requests are signed, and reject any requests that are not properly signed.
Check for the signature header and perform the necessary validation.
Return a 401 Unauthorized error if the signature is missing or invalid.
```

## CURL Example
```bash
curl -s -X POST -H "Content-Type: application/json" -H "X-Signature: <valid_signature>" -H "X-Client-Id: demo-client" http://localhost:8080/consents -d '{"customer_id":"c1","scopes":["accounts.read"],"expires_at":"2030-01-01T00:00:00Z"}'
```

## Definition of Done
- Task scope completed.
- Forbidden moves not present.
- Evidence Bundle generated and gates pass.
