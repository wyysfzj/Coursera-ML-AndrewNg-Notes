# AI‑EOS Evidence Specification v1.0 (Repo-local)

This repo implements FPMS-style Evidence Bundles in:
- `tools/eos/eos.sh`
- `artifacts/_template/`

Definition:
- Evidence Bundle is the only admissible proof of task completion.
- Gate reads only `results.jsonl`.
