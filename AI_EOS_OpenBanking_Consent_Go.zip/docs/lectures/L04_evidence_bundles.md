# Lecture 04 — Evidence Bundles (FPMS-style artifacts)

## Principle
**No Evidence, No Completion.**

Evidence must be:
- invariant-bound
- machine-consumable
- falsifiable
- auditable

## FPMS-style Evidence Bundle
This repo uses:

`artifacts/<TASK_ID>/`
- `commands.jsonl` — reproducibility record
- `git/` — diff + rev + status
- `outputs/` — tool logs (format/vet/test)
- `results.jsonl` — machine-readable gate inputs
- `summary.md` — human audit note (non-gate)

## Generate
```bash
make eos TASK=OB-AT-05
```

## Gate rule
Gates must read **only** `results.jsonl`.
