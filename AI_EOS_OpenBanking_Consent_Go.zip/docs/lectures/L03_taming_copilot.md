# Lecture 03 — Taming Copilot with Atomic Tasks (Open Banking)

## Copilot’s default optimization goals
Without constraints, Copilot converges to:
- caching
- “smart” upserts
- convenience middleware
- DRY managers
- implicit fallbacks

In consent setup, these are often governance violations.

## Discipline
You do not ask Copilot to be careful.
You forbid categories of outputs and require evidence artifacts.

## Demo path
- Non-Atomic prompt: “Implement consent setup end-to-end”
- Atomic prompt: “Implement ONLY request-hash binding for idempotency keys; change only one file; emit EVIDENCE lines.”

## Result
Copilot becomes a constrained executor, not a designer.
