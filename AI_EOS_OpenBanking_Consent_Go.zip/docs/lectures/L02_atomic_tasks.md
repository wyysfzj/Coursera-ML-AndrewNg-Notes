# Lecture 02 — Atomic Task as the minimum governance unit (Open Banking)

## Definition
An **Atomic Task** is a change unit whose correctness is **decidable enough** to be gated.

Atomic Tasks enforce:
- scope closure (allowed files/functions)
- negative constraints (forbidden moves)
- evidence requirements
- gate inputs

## Why story-level tasks fail here
“Implement consent setup” is open-ended:
- caching?
- retry semantics?
- token refresh?
- state machine framework?

AI will do “reasonable” things that expand the diff surface.

## This repo’s Atomic Task pack
See `tasks/atomic/`:
- OB-AT-01 … OB-AT-10

Each task defines:
- objective
- scope
- forbidden patterns
- evidence bundle expectations
- gates

## Key observation
Atomic Tasks do not make AI smarter.
They make the solution space smaller until dangerous outputs cannot appear.
