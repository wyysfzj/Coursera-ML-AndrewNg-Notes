# Lecture 05 — Gate-controlled engineering (Open Banking)

## Gate definition
A Gate is a deterministic function:
- Input: Evidence Bundle
- Output: pass/fail
No “mostly”.

## Gate categories
1) Static gates
- `gofmt` clean
- `go vet`
- forbidden pattern scans (optional)

2) Behavior gates (invariant tests)
- signature required
- idempotency hash binding
- client binding on reads
- expiry validation

3) Diff gates
- atomic tasks change only allowed files

## Human approval is an anti-pattern
Humans do not scale with AI throughput.
Gates must be non-bypassable.
