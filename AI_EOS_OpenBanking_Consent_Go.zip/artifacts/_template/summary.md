# Summary (Template)

- Task ID:
- Objective:
- Scope:
- Key evidence:
- Gate results:
- Notes / deviations (must be justified; does not override gates):
