# EOS tooling (teaching-grade)

`eos.sh` generates FPMS-style Evidence Bundles:
- records executed commands
- captures tool outputs
- records git state
- runs a diff gate (optional allowlist)
- writes `results.jsonl` (gate inputs)
