#!/usr/bin/env bash
set -euo pipefail

ALLOW_FILES="${1:-}"
if [[ -z "${ALLOW_FILES}" ]]; then
  echo "diff_gate: missing allowlist"
  exit 2
fi

IFS=',' read -r -a patterns <<< "${ALLOW_FILES}"

changed="$(git diff --name-only)"
if [[ -z "${changed}" ]]; then
  echo "diff_gate: no changes"
  exit 0
fi

is_allowed() {
  local f="$1"
  for p in "${patterns[@]}"; do
    if [[ "${f}" == ${p} ]]; then
      return 0
    fi
  done
  return 1
}

bad=0
while IFS= read -r f; do
  if ! is_allowed "${f}"; then
    echo "diff_gate: forbidden change: ${f}"
    bad=1
  fi
done <<< "${changed}"

if [[ "${bad}" -ne 0 ]]; then
  exit 1
fi

echo "diff_gate: ok"
