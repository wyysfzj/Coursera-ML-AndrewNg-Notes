#!/usr/bin/env bash
set -euo pipefail

TASK_ID="${1:-}"
if [[ -z "${TASK_ID}" ]]; then
  echo "Usage: tools/eos/eos.sh <TASK_ID>"
  exit 1
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
ART_DIR="${ROOT_DIR}/artifacts/${TASK_ID}"
OUT_DIR="${ART_DIR}/outputs"
GIT_DIR="${ART_DIR}/git"

mkdir -p "${OUT_DIR}" "${GIT_DIR}"

ts() { date -u +"%Y%m%dT%H%M%SZ"; }

COMMANDS_FILE="${ART_DIR}/commands.jsonl"
RESULTS_FILE="${ART_DIR}/results.jsonl"
SUMMARY_FILE="${ART_DIR}/summary.md"

: > "${COMMANDS_FILE}"
: > "${RESULTS_FILE}"

record_cmd() {
  local cmd="$1"
  echo "{\"ts\":\"$(ts)\",\"cmd\":\"${cmd//\"/\\\"}\"}" >> "${COMMANDS_FILE}"
}

run_and_capture() {
  local name="$1"; shift
  local logfile="${OUT_DIR}/$(ts)_${name}.log"
  local cmd="$*"
  record_cmd "${cmd}"
  set +e
  bash -lc "${cmd}" > "${logfile}" 2>&1
  local ec=$?
  set -e
  echo "${ec}" > "${logfile}.exitcode"
  return "${ec}"
}

# Git evidence
record_cmd "git rev-parse HEAD"
git rev-parse HEAD > "${GIT_DIR}/rev.txt"
record_cmd "git status --porcelain"
git status --porcelain > "${GIT_DIR}/status.txt"
record_cmd "git diff"
git diff > "${GIT_DIR}/diff.patch"

fmt_ec=0
vet_ec=0
test_ec=0
diff_ec=0

run_and_capture "format" "test -z \"\$(gofmt -l .)\""; fmt_ec=$? || true
run_and_capture "vet" "go vet ./..."; vet_ec=$? || true
run_and_capture "test" "go test ./..."; test_ec=$? || true

ALLOW_FILES="${ALLOW_FILES:-}"
if [[ -n "${ALLOW_FILES}" ]]; then
  run_and_capture "diff_gate" "bash tools/eos/gates/diff_gate.sh \"${ALLOW_FILES}\""; diff_ec=$? || true
else
  record_cmd "diff gate skipped (ALLOW_FILES not set)"
fi

jsonl() {
  local check="$1" result="$2"
  echo "{\"check\":\"${check}\",\"result\":\"${result}\"}" >> "${RESULTS_FILE}"
}

[[ "${fmt_ec}" -eq 0 ]] && jsonl "format" "pass" || jsonl "format" "fail"
[[ "${vet_ec}" -eq 0 ]] && jsonl "vet" "pass" || jsonl "vet" "fail"
[[ "${test_ec}" -eq 0 ]] && jsonl "test" "pass" || jsonl "test" "fail"
if [[ -n "${ALLOW_FILES}" ]]; then
  [[ "${diff_ec}" -eq 0 ]] && jsonl "diff_scope" "pass" || jsonl "diff_scope" "fail"
fi

if [[ ! -f "${SUMMARY_FILE}" ]]; then
  cp "${ROOT_DIR}/artifacts/_template/summary.md" "${SUMMARY_FILE}"
fi

echo "Evidence Bundle written to: ${ART_DIR}"
echo "Gate inputs: ${RESULTS_FILE}"
