package security

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"strings"
)

var demoSeedHex = "6636576d097ed085d9a283377f694e33d28b7a32a869df53544591e3c7d7b658"

// DemoClientPrivateKey returns a deterministic demo private key (teaching only).
func DemoClientPrivateKey() ed25519.PrivateKey {
	seed, _ := hex.DecodeString(demoSeedHex)
	return ed25519.NewKeyFromSeed(seed)
}

// DemoClientPublicKey returns the matching public key (teaching only).
func DemoClientPublicKey() ed25519.PublicKey {
	priv := DemoClientPrivateKey()
	return priv.Public().(ed25519.PublicKey)
}

type ClientRegistry struct {
	pubKeys map[string]ed25519.PublicKey
}

func NewClientRegistry() *ClientRegistry {
	return &ClientRegistry{pubKeys: map[string]ed25519.PublicKey{
		"demo-client": DemoClientPublicKey(),
	}}
}

func (r *ClientRegistry) PublicKey(clientID string) (ed25519.PublicKey, bool) {
	pk, ok := r.pubKeys[clientID]
	return pk, ok
}

func Canonical(method, path, idem, body string) string {
	if idem == "" {
		idem = "-"
	}
	sum := sha256.Sum256([]byte(body))
	bodyHash := fmt.Sprintf("%x", sum[:])
	return strings.ToUpper(method) + "\n" + path + "\n" + idem + "\n" + bodyHash
}

func VerifyEd25519Signature(pub ed25519.PublicKey, canonical string, sigB64 string) bool {
	sig, err := base64.StdEncoding.DecodeString(sigB64)
	if err != nil {
		return false
	}
	return ed25519.Verify(pub, []byte(canonical), sig)
}
