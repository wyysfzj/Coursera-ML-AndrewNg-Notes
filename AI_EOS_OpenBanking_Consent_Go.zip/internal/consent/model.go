package consent

import (
	"errors"
	"time"
)

type Status string

const (
	StatusAwaitingAuthorization Status = "AWAITING_AUTHORIZATION"
	StatusAuthorized            Status = "AUTHORIZED"
	StatusRejected              Status = "REJECTED"
)

type Consent struct {
	ID          string    `json:"consent_id"`
	ClientID    string    `json:"client_id"`
	CustomerID  string    `json:"-"` // sensitive; never return or log
	Scopes      []string  `json:"scopes"`
	ExpiresAt   time.Time `json:"expires_at"`
	Status      Status    `json:"status"`
	Challenge   string    `json:"challenge"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
	RequestHash string    `json:"-"`
	Idempotency string    `json:"-"`
}

var (
	ErrUnauthorized           = errors.New("unauthorized")
	ErrInvalidRequest         = errors.New("invalid_request")
	ErrIdempotencyConflict    = errors.New("idempotency_conflict")
	ErrNotFound               = errors.New("not_found")
	ErrForbidden              = errors.New("forbidden")
	ErrExpired                = errors.New("expired")
	ErrSignatureInvalid       = errors.New("signature_invalid")
	ErrIdempotencyKeyRequired = errors.New("idempotency_key_required")
)

func ValidateExpiry(expiresAt time.Time, now time.Time) error {
	if expiresAt.IsZero() {
		return ErrInvalidRequest
	}
	if expiresAt.Before(now.Add(1 * time.Minute)) {
		return ErrExpired
	}
	return nil
}
