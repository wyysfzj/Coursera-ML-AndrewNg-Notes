package consent

import "context"

type Meta struct {
	ClientID       string
	IdempotencyKey string
	SignatureB64   string
	Method         string
	Path           string
	RawBody        string
}

type CreateRequest struct {
	CustomerID  string   `json:"customer_id"`
	Scopes      []string `json:"scopes"`
	ExpiresAt   string   `json:"expires_at"` // RFC3339
	RedirectURI string   `json:"redirect_uri"`
}

type CreateResponse struct {
	ConsentID string `json:"consent_id"`
	ExpiresAt string `json:"expires_at"`
	Status    Status `json:"status"`
	Challenge string `json:"challenge"`
}

type Service interface {
	CreateConsent(ctx context.Context, req CreateRequest, meta Meta) (CreateResponse, int, error)
	GetConsent(ctx context.Context, consentID string, meta Meta) (Consent, int, error)
}
