package consent

import (
	"context"
	"crypto/sha256"
	"fmt"

	core "ai-eos-openbanking-consent/internal/consent"
	"ai-eos-openbanking-consent/internal/security"
)

type SignatureVerifier struct {
	Reg *security.ClientRegistry
}

func NewSignatureVerifier(reg *security.ClientRegistry) *SignatureVerifier {
	return &SignatureVerifier{Reg: reg}
}

func (v *SignatureVerifier) VerifyOrReject(ctx context.Context, meta core.Meta) (canonical string, requestHash string, httpStatus int, err error) {
	pub, ok := v.Reg.PublicKey(meta.ClientID)
	if !ok {
		return "", "", 401, core.ErrUnauthorized
	}
	canonical = security.Canonical(meta.Method, meta.Path, meta.IdempotencyKey, meta.RawBody)
	if meta.SignatureB64 == "" {
		return canonical, "", 401, core.ErrSignatureInvalid
	}
	if !security.VerifyEd25519Signature(pub, canonical, meta.SignatureB64) {
		return canonical, "", 401, core.ErrSignatureInvalid
	}
	s := sha256.Sum256([]byte(canonical))
	requestHash = fmt.Sprintf("%x", s[:])
	return canonical, requestHash, 200, nil
}
