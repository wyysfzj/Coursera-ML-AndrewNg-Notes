package consent

import (
	"sync"

	core "ai-eos-openbanking-consent/internal/consent"
)

type idemRecord struct {
	RequestHash string
	Resp        core.CreateResponse
	ConsentID   string
}

type Store struct {
	mu       sync.Mutex
	consents map[string]core.Consent
	idem     map[string]idemRecord
}

func NewStore() *Store {
	return &Store{
		consents: make(map[string]core.Consent),
		idem:     make(map[string]idemRecord),
	}
}

func (s *Store) GetConsent(id string) (core.Consent, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	c, ok := s.consents[id]
	return c, ok
}

func (s *Store) PutConsent(c core.Consent) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.consents[c.ID] = c
}

func (s *Store) GetIdem(key string) (idemRecord, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	r, ok := s.idem[key]
	return r, ok
}

func (s *Store) PutIdem(key string, r idemRecord) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.idem[key] = r
}
