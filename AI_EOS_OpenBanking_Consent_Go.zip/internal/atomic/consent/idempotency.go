package consent

import (
	"context"

	core "ai-eos-openbanking-consent/internal/consent"
)

type EvidenceLogger interface {
	Evidencef(format string, args ...any)
}

type Idempotency struct {
	Store  *Store
	Logger EvidenceLogger
}

func NewIdempotency(store *Store, logger EvidenceLogger) *Idempotency {
	return &Idempotency{Store: store, Logger: logger}
}

func (i *Idempotency) Check(ctx context.Context, key string, requestHash string) (core.CreateResponse, bool, int, error) {
	if key == "" {
		return core.CreateResponse{}, false, 400, core.ErrIdempotencyKeyRequired
	}
	r, ok := i.Store.GetIdem(key)
	if !ok {
		return core.CreateResponse{}, false, 0, nil
	}
	if r.RequestHash != requestHash {
		i.Logger.Evidencef("EVIDENCE_IDEMPOTENCY_CONFLICT key=%s", key)
		return core.CreateResponse{}, true, 409, core.ErrIdempotencyConflict
	}
	i.Logger.Evidencef("EVIDENCE_IDEMPOTENCY_REPLAY key=%s", key)
	return r.Resp, true, 200, nil
}

func (i *Idempotency) Remember(key string, requestHash string, resp core.CreateResponse, consentID string) {
	i.Store.PutIdem(key, idemRecord{RequestHash: requestHash, Resp: resp, ConsentID: consentID})
	i.Logger.Evidencef("EVIDENCE_IDEMPOTENCY_STORED key=%s", key)
}
