package audit

import (
	"context"
	"time"
)

type Event struct {
	TS       time.Time         `json:"ts"`
	Type     string            `json:"type"`
	Consent  string            `json:"consent_id,omitempty"`
	ClientID string            `json:"client_id,omitempty"`
	Meta     map[string]string `json:"meta,omitempty"`
}

type Sink interface {
	Record(ctx context.Context, e Event) error
	Snapshot() []Event
}

type InMemorySink struct {
	events []Event
}

func NewInMemorySink() *InMemorySink {
	return &InMemorySink{events: make([]Event, 0, 64)}
}

func (s *InMemorySink) Record(ctx context.Context, e Event) error {
	s.events = append(s.events, e)
	return nil
}

func (s *InMemorySink) Snapshot() []Event {
	out := make([]Event, len(s.events))
	copy(out, s.events)
	return out
}
