package httpapi

import (
	"encoding/json"
	"log"
	"net/http"
	"strings"

	core "ai-eos-openbanking-consent/internal/consent"
	"ai-eos-openbanking-consent/internal/audit"
	"ai-eos-openbanking-consent/internal/security"
	atomic "ai-eos-openbanking-consent/internal/atomic/consent"
	nonatomic "ai-eos-openbanking-consent/internal/non_atomic/consent"
)

type Handler struct {
	mode   string
	logger *log.Logger

	atomicSvc    core.Service
	nonAtomicSvc core.Service
}

func NewHandler(mode string, logger *log.Logger) http.Handler {
	h := &Handler{mode: mode, logger: logger}

	// Atomic wiring
	store := atomic.NewStore()
	reg := security.NewClientRegistry()
	ver := atomic.NewSignatureVerifier(reg)
	auditSink := audit.NewInMemorySink()
	asvc := atomic.NewService(store, ver, nil, auditSink, logger)
	idem := atomic.NewIdempotency(store, asvc)
	asvc.Idem = idem
	h.atomicSvc = asvc

	// Non-atomic wiring
	h.nonAtomicSvc = nonatomic.NewService(logger)

	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", h.handleHealth)
	mux.HandleFunc("/consents", h.handleConsents)
	mux.HandleFunc("/consents/", h.handleConsentByID)
	return mux
}

func (h *Handler) svc() core.Service {
	if h.mode == "non-atomic" {
		return h.nonAtomicSvc
	}
	return h.atomicSvc
}

func (h *Handler) handleHealth(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	_, _ = w.Write([]byte(`{"ok":true}`))
}

func readMeta(r *http.Request, rawBody string) core.Meta {
	return core.Meta{
		ClientID:       r.Header.Get("X-Client-Id"),
		IdempotencyKey: r.Header.Get("Idempotency-Key"),
		SignatureB64:   r.Header.Get("X-Signature"),
		Method:         r.Method,
		Path:           r.URL.Path,
		RawBody:        rawBody,
	}
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, status int, code string) {
	writeJSON(w, status, map[string]any{"error": code})
}

func (h *Handler) handleConsents(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeErr(w, 405, "method_not_allowed")
		return
	}
	bodyBytes, _ := readAllLimit(r, 1<<20)
	raw := string(bodyBytes)

	var req core.CreateRequest
	if err := json.Unmarshal(bodyBytes, &req); err != nil {
		writeErr(w, 400, "invalid_json")
		return
	}

	meta := readMeta(r, raw)
	if meta.ClientID == "" {
		writeErr(w, 401, "missing_client_id")
		return
	}

	resp, httpStatus, err := h.svc().CreateConsent(r.Context(), req, meta)
	if err != nil {
		writeErr(w, httpStatus, strings.ReplaceAll(err.Error(), " ", "_"))
		return
	}
	writeJSON(w, httpStatus, resp)
}

func (h *Handler) handleConsentByID(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeErr(w, 405, "method_not_allowed")
		return
	}
	id := strings.TrimPrefix(r.URL.Path, "/consents/")
	meta := readMeta(r, "")
	if meta.ClientID == "" {
		writeErr(w, 401, "missing_client_id")
		return
	}

	c, httpStatus, err := h.svc().GetConsent(r.Context(), id, meta)
	if err != nil {
		writeErr(w, httpStatus, strings.ReplaceAll(err.Error(), " ", "_"))
		return
	}
	writeJSON(w, httpStatus, c)
}
