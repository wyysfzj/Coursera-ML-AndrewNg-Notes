package httpapi

import (
	"io"
	"net/http"
)

func readAllLimit(r *http.Request, limit int64) ([]byte, error) {
	defer r.Body.Close()
	lr := io.LimitReader(r.Body, limit)
	return io.ReadAll(lr)
}
