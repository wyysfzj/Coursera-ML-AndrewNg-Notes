#!/usr/bin/env bash
set -euo pipefail
BASE="http://localhost:8080"
echo "== Atomic demo against ${BASE} =="

echo "-- Health"
curl -s "${BASE}/healthz" | sed 's/.*/  &/'

echo
echo "-- 1) Missing signature should FAIL (401)"
payload='{"customer_id":"cust-001","scopes":["accounts.basic:read"],"expires_at":"2030-01-01T00:00:00Z","redirect_uri":"https://example.com/cb"}'
curl -s -o /dev/null -w "  status=%{http_code}\n" -X POST "${BASE}/consents" \
  -H "Content-Type: application/json" \
  -H "X-Client-Id: demo-client" \
  -H "Idempotency-Key: idem-1" \
  --data "${payload}"

echo
echo "-- 2) Valid signature should PASS (201)"
sig="$(go run ./cmd/sign --method POST --path /consents --idempotency idem-1 --body "${payload}")"
resp="$(curl -s -w "\n%{http_code}" -X POST "${BASE}/consents" \
  -H "Content-Type: application/json" \
  -H "X-Client-Id: demo-client" \
  -H "Idempotency-Key: idem-1" \
  -H "X-Signature: ${sig}" \
  --data "${payload}")"
body="$(echo "${resp}" | head -n1)"
code="$(echo "${resp}" | tail -n1)"
echo "  status=${code}"
echo "  body=${body}"

consent_id="$(echo "${body}" | sed -n 's/.*"consent_id":"\([^"]*\)".*/\1/p')"

echo
echo "-- 3) Reuse SAME idempotency key with DIFFERENT payload should FAIL (409)"
payload2='{"customer_id":"cust-001","scopes":["accounts.detail:read"],"expires_at":"2030-01-01T00:00:00Z","redirect_uri":"https://example.com/cb"}'
sig2="$(go run ./cmd/sign --method POST --path /consents --idempotency idem-1 --body "${payload2}")"
curl -s -o /dev/null -w "  status=%{http_code}\n" -X POST "${BASE}/consents" \
  -H "Content-Type: application/json" \
  -H "X-Client-Id: demo-client" \
  -H "Idempotency-Key: idem-1" \
  -H "X-Signature: ${sig2}" \
  --data "${payload2}"

echo
echo "-- 4) GET consent with signature should PASS (200)"
sig3="$(go run ./cmd/sign --method GET --path "/consents/${consent_id}" --idempotency "-" --body "")"
curl -s -w "\n  status=%{http_code}\n" -X GET "${BASE}/consents/${consent_id}" \
  -H "X-Client-Id: demo-client" \
  -H "X-Signature: ${sig3}" | sed 's/^/  /'
