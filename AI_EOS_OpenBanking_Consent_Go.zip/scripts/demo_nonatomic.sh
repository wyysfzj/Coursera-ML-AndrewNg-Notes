#!/usr/bin/env bash
set -euo pipefail
BASE="http://localhost:8081"
echo "== Non-Atomic demo against ${BASE} =="

echo "-- Health"
curl -s "${BASE}/healthz" | sed 's/.*/  &/'

echo
echo "-- 1) Missing signature should (incorrectly) PASS (201) — vulnerability"
payload='{"customer_id":"cust-001","scopes":["accounts.basic:read"],"expires_at":"2030-01-01T00:00:00Z","redirect_uri":"https://example.com/cb"}'
resp="$(curl -s -w "\n%{http_code}" -X POST "${BASE}/consents" \
  -H "Content-Type: application/json" \
  -H "X-Client-Id: demo-client" \
  -H "Idempotency-Key: idem-1" \
  --data "${payload}")"
body="$(echo "${resp}" | head -n1)"
code="$(echo "${resp}" | tail -n1)"
echo "  status=${code}"
echo "  body=${body}"

echo
echo "-- 2) Reuse SAME idempotency key with DIFFERENT payload should (incorrectly) PASS — malleability"
payload2='{"customer_id":"cust-001","scopes":["accounts.detail:read"],"expires_at":"2030-01-01T00:00:00Z","redirect_uri":"https://example.com/cb"}'
resp2="$(curl -s -w "\n%{http_code}" -X POST "${BASE}/consents" \
  -H "Content-Type: application/json" \
  -H "X-Client-Id: demo-client" \
  -H "Idempotency-Key: idem-1" \
  --data "${payload2}")"
body2="$(echo "${resp2}" | head -n1)"
code2="$(echo "${resp2}" | tail -n1)"
echo "  status=${code2}"
echo "  body=${body2}"

echo
echo "-- Note: Non-Atomic ignores signatures and does not bind idempotency to request hash."
