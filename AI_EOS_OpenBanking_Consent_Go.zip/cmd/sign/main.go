package main

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"flag"
	"fmt"
	"strings"
)

var demoSeedHex = "6636576d097ed085d9a283377f694e33d28b7a32a869df53544591e3c7d7b658"

func demoPrivateKey() ed25519.PrivateKey {
	seed, _ := hex.DecodeString(demoSeedHex)
	return ed25519.NewKeyFromSeed(seed)
}

func canonical(method, path, idem, body string) string {
	if idem == "" {
		idem = "-"
	}
	sum := sha256.Sum256([]byte(body))
	bodyHash := fmt.Sprintf("%x", sum[:])
	return strings.ToUpper(method) + "\n" + path + "\n" + idem + "\n" + bodyHash
}

func main() {
	method := flag.String("method", "POST", "HTTP method")
	path := flag.String("path", "/consents", "HTTP path")
	idempotency := flag.String("idempotency", "-", "Idempotency-Key (or '-')")
	body := flag.String("body", "", "raw JSON body")
	flag.Parse()

	priv := demoPrivateKey()
	msg := canonical(*method, *path, *idempotency, *body)
	sig := ed25519.Sign(priv, []byte(msg))
	fmt.Print(base64.StdEncoding.EncodeToString(sig))
}
