# Non-Atomic anti-pattern scripts (Copilot prompts)

These prompts are intentionally “reasonable”.
They reliably lead to governance-illegal implementations.

Use in demos to show why:
- code review cannot scale
- evidence must replace trust
- gates must be deterministic
