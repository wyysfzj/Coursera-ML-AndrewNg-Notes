# OB-AT-07 — Audit events (structured) + redaction rules

## Objective
Implement exactly the capabilities described for this task, and nothing else.

## Scope (allowed files)
- `internal/audit/*`
- `internal/atomic/consent/service.go`

## Forbidden moves (negative constraints)
- No customer_id in logs/events
- No raw request body logging

## Evidence Bundle requirements (FPMS-style)
Generate:
- `artifacts/OB-AT-07/commands.jsonl`
- `artifacts/OB-AT-07/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-07/outputs/*_format.log`, `*_vet.log`, `*_test.log`
- `artifacts/OB-AT-07/results.jsonl`
- `artifacts/OB-AT-07/summary.md`

## Required evidence / checks
- Audit event tests
- Static scan (optional) for PII patterns

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Scope completed
- Forbidden moves absent
- Evidence Bundle generated
