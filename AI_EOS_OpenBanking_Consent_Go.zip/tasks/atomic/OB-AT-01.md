# OB-AT-01 — Repo bootstrap & contract scaffolding

## Objective
Implement exactly the capabilities described for this task, and nothing else.

## Scope (allowed files)
- `cmd/server/main.go`
- `internal/httpapi/*`
- `api/openapi.yaml`
- `Makefile`
- `README.md`

## Forbidden moves (negative constraints)
- No business logic
- No storage implementation
- No caching

## Evidence Bundle requirements (FPMS-style)
Generate:
- `artifacts/OB-AT-01/commands.jsonl`
- `artifacts/OB-AT-01/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-01/outputs/*_format.log`, `*_vet.log`, `*_test.log`
- `artifacts/OB-AT-01/results.jsonl`
- `artifacts/OB-AT-01/summary.md`

## Required evidence / checks
- go test ./... (baseline green)
- Routes exist & match API spec (manual ok for v1)

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Scope completed
- Forbidden moves absent
- Evidence Bundle generated
