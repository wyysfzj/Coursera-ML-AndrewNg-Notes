# OB-AT-09 — Invariant test suite (behavior gate) for consent setup

## Objective
Implement exactly the capabilities described for this task, and nothing else.

## Scope (allowed files)
- `tests/*`

## Forbidden moves (negative constraints)
- No skipping in atomic mode
- No mocking away core invariants

## Evidence Bundle requirements (FPMS-style)
Generate:
- `artifacts/OB-AT-09/commands.jsonl`
- `artifacts/OB-AT-09/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-09/outputs/*_format.log`, `*_vet.log`, `*_test.log`
- `artifacts/OB-AT-09/results.jsonl`
- `artifacts/OB-AT-09/summary.md`

## Required evidence / checks
- Atomic passes invariants
- Non-atomic fails invariants

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Scope completed
- Forbidden moves absent
- Evidence Bundle generated
