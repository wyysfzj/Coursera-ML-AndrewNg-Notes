# OB-AT-06 — Consent retrieval (GET /consents/{id}) with client binding

## Objective
Implement exactly the capabilities described for this task, and nothing else.

## Scope (allowed files)
- `internal/httpapi/handler.go`
- `internal/atomic/consent/service.go`

## Forbidden moves (negative constraints)
- No list endpoints
- No admin bypass
- No leaking existence across clients

## Evidence Bundle requirements (FPMS-style)
Generate:
- `artifacts/OB-AT-06/commands.jsonl`
- `artifacts/OB-AT-06/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-06/outputs/*_format.log`, `*_vet.log`, `*_test.log`
- `artifacts/OB-AT-06/results.jsonl`
- `artifacts/OB-AT-06/summary.md`

## Required evidence / checks
- Wrong client cannot read
- EVIDENCE_ACCESS_* emitted

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Scope completed
- Forbidden moves absent
- Evidence Bundle generated
