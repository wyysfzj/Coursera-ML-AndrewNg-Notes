# OB-AT-03 — Client registry + signature verification (Ed25519)

## Objective
Implement exactly the capabilities described for this task, and nothing else.

## Scope (allowed files)
- `internal/security/*`
- `internal/atomic/consent/signature.go`

## Forbidden moves (negative constraints)
- No fallback auth
- No accepting unsigned requests
- No logging secrets

## Evidence Bundle requirements (FPMS-style)
Generate:
- `artifacts/OB-AT-03/commands.jsonl`
- `artifacts/OB-AT-03/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-03/outputs/*_format.log`, `*_vet.log`, `*_test.log`
- `artifacts/OB-AT-03/results.jsonl`
- `artifacts/OB-AT-03/summary.md`

## Required evidence / checks
- Signature verification tests pass
- EVIDENCE_SIGNATURE_* emitted

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Scope completed
- Forbidden moves absent
- Evidence Bundle generated
