# OB-AT-02 — Domain model + invariants (Consent, Status, Expiry)

## Objective
Implement exactly the capabilities described for this task, and nothing else.

## Scope (allowed files)
- `internal/consent/*`

## Forbidden moves (negative constraints)
- No HTTP handlers
- No persistence

## Evidence Bundle requirements (FPMS-style)
Generate:
- `artifacts/OB-AT-02/commands.jsonl`
- `artifacts/OB-AT-02/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-02/outputs/*_format.log`, `*_vet.log`, `*_test.log`
- `artifacts/OB-AT-02/results.jsonl`
- `artifacts/OB-AT-02/summary.md`

## Required evidence / checks
- Domain tests pass
- gofmt clean

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Scope completed
- Forbidden moves absent
- Evidence Bundle generated
