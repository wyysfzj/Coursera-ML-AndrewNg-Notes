# OB-AT-04 — Idempotency storage + request-hash binding

## Objective
Implement exactly the capabilities described for this task, and nothing else.

## Scope (allowed files)
- `internal/atomic/consent/idempotency.go`
- `internal/atomic/consent/store.go`

## Forbidden moves (negative constraints)
- No upsert on mismatch
- No returning existing regardless of payload

## Evidence Bundle requirements (FPMS-style)
Generate:
- `artifacts/OB-AT-04/commands.jsonl`
- `artifacts/OB-AT-04/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-04/outputs/*_format.log`, `*_vet.log`, `*_test.log`
- `artifacts/OB-AT-04/results.jsonl`
- `artifacts/OB-AT-04/summary.md`

## Required evidence / checks
- Invariant: mismatch -> 409
- EVIDENCE_IDEMPOTENCY_* emitted

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Scope completed
- Forbidden moves absent
- Evidence Bundle generated
