package tests

import (
	"bytes"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"io"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"testing"

	"ai-eos-openbanking-consent/internal/httpapi"
	"ai-eos-openbanking-consent/internal/security"
)

func TestInvariants(t *testing.T) {
	mode := os.Getenv("EOS_MODE")
	if mode == "" {
		mode = "atomic"
	}

	ts := httptest.NewServer(httpapi.NewHandler(mode, testLogger(t)))
	defer ts.Close()

	payload := map[string]any{
		"customer_id":  "cust-001",
		"scopes":       []string{"accounts.basic:read"},
		"expires_at":   "2030-01-01T00:00:00Z",
		"redirect_uri": "https://example.com/cb",
	}
	body, _ := json.Marshal(payload)

	// Invariant 1: signature required for POST /consents (this should FAIL in non-atomic mode)
	{
		req, _ := http.NewRequest("POST", ts.URL+"/consents", bytes.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Client-Id", "demo-client")
		req.Header.Set("Idempotency-Key", "idem-1")
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		_ = resp.Body.Close()

		if resp.StatusCode != 401 {
			t.Fatalf("%s: expected 401 without signature, got %d", mode, resp.StatusCode)
		}
	}

	if mode != "atomic" {
		return
	}

	// Create with valid signature -> 201/200
	var consentID string
	{
		sig := sign("POST", "/consents", "idem-1", string(body))
		req, _ := http.NewRequest("POST", ts.URL+"/consents", bytes.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Client-Id", "demo-client")
		req.Header.Set("Idempotency-Key", "idem-1")
		req.Header.Set("X-Signature", sig)

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != 201 && resp.StatusCode != 200 {
			b, _ := io.ReadAll(resp.Body)
			t.Fatalf("atomic: expected 201/200, got %d body=%s", resp.StatusCode, string(b))
		}
		var out map[string]any
		_ = json.NewDecoder(resp.Body).Decode(&out)
		consentID, _ = out["consent_id"].(string)
		if consentID == "" {
			t.Fatalf("atomic: missing consent_id in response")
		}
	}

	// Invariant 2: idempotency hash binding (mismatch -> 409)
	{
		payload2 := map[string]any{
			"customer_id":  "cust-001",
			"scopes":       []string{"accounts.detail:read"},
			"expires_at":   "2030-01-01T00:00:00Z",
			"redirect_uri": "https://example.com/cb",
		}
		body2, _ := json.Marshal(payload2)
		sig2 := sign("POST", "/consents", "idem-1", string(body2))
		req, _ := http.NewRequest("POST", ts.URL+"/consents", bytes.NewReader(body2))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("X-Client-Id", "demo-client")
		req.Header.Set("Idempotency-Key", "idem-1")
		req.Header.Set("X-Signature", sig2)

		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != 409 {
			b, _ := io.ReadAll(resp.Body)
			t.Fatalf("atomic: expected 409, got %d body=%s", resp.StatusCode, string(b))
		}
	}

	// Invariant 3: GET requires signature
	{
		req, _ := http.NewRequest("GET", ts.URL+"/consents/"+consentID, nil)
		req.Header.Set("X-Client-Id", "demo-client")
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		_ = resp.Body.Close()
		if resp.StatusCode != 401 {
			t.Fatalf("atomic: expected 401 on GET without signature, got %d", resp.StatusCode)
		}
	}

	// Invariant 4: response must not leak customer_id
	{
		sig := sign("GET", "/consents/"+consentID, "-", "")
		req, _ := http.NewRequest("GET", ts.URL+"/consents/"+consentID, nil)
		req.Header.Set("X-Client-Id", "demo-client")
		req.Header.Set("X-Signature", sig)
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatalf("request failed: %v", err)
		}
		defer resp.Body.Close()
		b, _ := io.ReadAll(resp.Body)
		if bytes.Contains(b, []byte("customer_id")) {
			t.Fatalf("atomic: leaked customer_id in response: %s", string(b))
		}
	}
}

func sign(method, path, idem, body string) string {
	priv := security.DemoClientPrivateKey()
	if len(priv) != ed25519.PrivateKeySize {
		panic("bad demo private key")
	}
	canonical := security.Canonical(method, path, idem, body)
	sig := ed25519.Sign(priv, []byte(canonical))
	return base64.StdEncoding.EncodeToString(sig)
}

func testLogger(t *testing.T) *log.Logger {
	return log.New(io.Discard, "", 0)
}
