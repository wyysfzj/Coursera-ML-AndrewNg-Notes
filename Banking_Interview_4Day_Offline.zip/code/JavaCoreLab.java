import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** Java 17. Run: java JavaCoreLab.java
 * Original teaching experiment, not a bank integration test.
 * Gates force a reproducible interleaving; no race depends on random timing.
 */
public class JavaCoreLab {
    private static volatile int brokenCount = 0;

    public static void main(String[] args) throws Exception {
        money();
        lostUpdate();
        timeoutIsNotCancellation();
        System.out.println("PASS: all teaching checks passed");
    }

    private static void money() {
        BigDecimal exact = new BigDecimal("0.10").add(new BigDecimal("0.20"));
        check(exact.compareTo(new BigDecimal("0.30")) == 0, "exact decimal sum");
        boolean representationEqual = new BigDecimal("2.0").equals(new BigDecimal("2.00"));
        int numericalComparison = new BigDecimal("2.0").compareTo(new BigDecimal("2.00"));
        check(!representationEqual && numericalComparison == 0, "scale semantics");
        BigDecimal installment = new BigDecimal("10.00").divide(new BigDecimal("3"), 2, RoundingMode.HALF_EVEN);
        BigDecimal finalInstallment = new BigDecimal("10.00").subtract(installment.multiply(new BigDecimal("2")));
        check(finalInstallment.equals(new BigDecimal("3.34")), "remainder allocation");
        System.out.println("Money: sum=" + exact + ", equals=" + representationEqual
                + ", compareTo=" + numericalComparison + ", installments="
                + installment + "," + installment + "," + finalInstallment);
    }

    private static void lostUpdate() throws Exception {
        CountDownLatch bothRead = new CountDownLatch(2);
        CountDownLatch allowWrite = new CountDownLatch(1);
        AtomicInteger correctCount = new AtomicInteger();
        ExecutorService pool = Executors.newFixedThreadPool(2);
        try {
            Callable<Void> task = () -> {
                // Explicitly split count++ to force one legal lost-update interleaving.
                int observed = brokenCount;
                bothRead.countDown();
                if (!allowWrite.await(5, TimeUnit.SECONDS)) throw new IllegalStateException("gate timeout");
                brokenCount = observed + 1;
                correctCount.incrementAndGet();
                return null;
            };
            Future<Void> a = pool.submit(task);
            Future<Void> b = pool.submit(task);
            check(bothRead.await(5, TimeUnit.SECONDS), "workers started");
            allowWrite.countDown();
            a.get(5, TimeUnit.SECONDS);
            b.get(5, TimeUnit.SECONDS);
            check(brokenCount == 1 && correctCount.get() == 2, "lost update versus atomic update");
            System.out.println("Concurrency: split volatile increment=" + brokenCount + ", atomic increment=" + correctCount.get());
        } finally {
            allowWrite.countDown();
            pool.shutdownNow();
            pool.awaitTermination(5, TimeUnit.SECONDS);
        }
    }

    private static void timeoutIsNotCancellation() throws Exception {
        ExecutorService pool = Executors.newSingleThreadExecutor();
        CountDownLatch started = new CountDownLatch(1);
        CountDownLatch resume = new CountDownLatch(1);
        CountDownLatch sideEffectDone = new CountDownLatch(1);
        AtomicBoolean sideEffect = new AtomicBoolean(false);
        try {
            CompletableFuture<String> result = CompletableFuture.supplyAsync(() -> {
                started.countDown();
                try {
                    if (!resume.await(5, TimeUnit.SECONDS)) throw new IllegalStateException("gate timeout");
                    sideEffect.set(true);
                    sideEffectDone.countDown();
                    return "worker completed";
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    throw new CompletionException(ex);
                }
            }, pool);
            check(started.await(5, TimeUnit.SECONDS), "worker started");
            result.orTimeout(30, TimeUnit.MILLISECONDS);
            try {
                result.get(5, TimeUnit.SECONDS);
                throw new AssertionError("expected exceptional completion");
            } catch (ExecutionException ex) {
                check(ex.getCause() instanceof TimeoutException, "timeout cause");
                System.out.println("Timeout: caller=" + ex.getCause().getClass().getSimpleName()
                        + ", sideEffectBeforeResume=" + sideEffect.get());
            }
            check(!sideEffect.get(), "work is still gated");
            resume.countDown();
            check(sideEffectDone.await(5, TimeUnit.SECONDS), "side effect occurred after timeout");
            check(sideEffect.get() && result.isCompletedExceptionally(), "result and work have different lifecycles");
            System.out.println("Timeout: sideEffectAfterResume=" + sideEffect.get()
                    + ", futureExceptional=" + result.isCompletedExceptionally());
        } finally {
            resume.countDown();
            pool.shutdownNow();
            pool.awaitTermination(5, TimeUnit.SECONDS);
        }
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
