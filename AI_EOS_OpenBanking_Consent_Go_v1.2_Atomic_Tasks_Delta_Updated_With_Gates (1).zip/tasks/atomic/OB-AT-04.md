
# OB‑AT‑04 — Consent Creation and Idempotency Enforcement (POST /consents)

## Objective
- Implement the `POST /consents` endpoint to create a consent.
- Ensure that the consent creation is idempotent, validates the necessary fields, and returns a `201` response with `consent_id`, `expires_at`, and `challenge`.

## Static Gate
- **检查点**：确保没有额外的端点或不必要的修改。
- **位置**：检查代码路径，确保没有意外的修改或功能添加。

## Behavior Gate
- **检查点**：测试 `POST /consents` 返回 `201` 且包含正确的字段。
- **位置**：运行时测试，确认响应是否符合预期。

## Scope (allowed files)
- `internal/httpapi/handler.go`
- `internal/atomic/consent/service.go`

## Forbidden moves (negative constraints)
- No GET implementation
- No additional endpoints
- No state machine framework (keep simple)

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-04/commands.jsonl`
- `artifacts/OB-AT-04/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-04/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-04/results.jsonl`
- `artifacts/OB-AT-04/summary.md`

## Required evidence / checks
- `POST /consents` should return `201` with correct fields
- Idempotency logic should work as expected
- `go test ./...` should pass
- `gofmt` clean

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Task scope completed
- Forbidden moves not present
- Evidence Bundle generated and gates pass
