
# OB‑AT‑02 — Idempotency Key + Request Hash Binding

## Objective
- Implement the functionality to bind the Idempotency-Key to the request hash, ensuring that requests with the same key and request hash return the same response.
- Reject requests with the same Idempotency-Key and different request hashes, returning a `409 Conflict`.

## Static Gate
- **检查点**：验证 `idempotency.go` 中的 **请求哈希绑定逻辑**。
- **位置**：确保 Idempotency-Key 和请求哈希绑定。

## Behavior Gate
- **检查点**：通过 **行为验证**，测试相同 `Idempotency-Key` 与不同请求内容是否返回 `409 Conflict`。
- **位置**：运行时测试，确认不同请求内容（相同 `Idempotency-Key`）是否会触发 `409`。

## Scope (allowed files)
- `internal/atomic/consent/idempotency.go`
- `internal/atomic/consent/store.go`

## Forbidden moves (negative constraints)
- No upsert logic without binding request hash
- No returning existing response without checking request hash

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-02/commands.jsonl`
- `artifacts/OB-AT-02/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-02/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-02/results.jsonl`
- `artifacts/OB-AT-02/summary.md`

## Required evidence / checks
- Same Idempotency-Key with different payload returns `409 Conflict`
- `go test ./...` should pass
- `gofmt` clean

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Task scope completed
- Forbidden moves not present
- Evidence Bundle generated and gates pass
