
# OB‑AT‑03 — PII Minimization and Logging Control

## Objective
- Ensure that no sensitive data (e.g., `customer_id`) is included in the response or logs.
- Implement logging control to redact any sensitive data before it is written to the logs.

## Static Gate
- **检查点**：确保没有日志记录原始请求体或 `customer_id`。
- **位置**：检查日志控制和数据脱敏机制。

## Behavior Gate
- **检查点**：确保返回的响应中不含 **`customer_id`**，并验证 PII 信息是否已被正确脱敏。
- **位置**：运行时行为验证，确保响应中没有泄露敏感信息。

## Scope (allowed files)
- `internal/httpapi/handler.go`
- `internal/atomic/consent/service.go`

## Forbidden Moves (negative constraints)
- No raw request body logging
- No `customer_id` in response or logs

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-03/commands.jsonl`
- `artifacts/OB-AT-03/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-03/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-03/results.jsonl`
- `artifacts/OB-AT-03/summary.md`

## Required evidence / checks
- No `customer_id` in response or logs
- PII redaction must be verified
- `gofmt` clean

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Task scope completed
- Forbidden moves not present
- Evidence Bundle generated and gates pass
