
# OB‑AT‑05 — Consent Retrieval and Client Binding (GET /consents/{consent_id})

## Objective
- Implement the `GET /consents/{consent_id}` endpoint to retrieve consent by `consent_id`.
- Ensure that the client retrieving consent is the one who created it (client binding).
- Return `404` for any other client attempting to access the consent.

## Static Gate
- **检查点**：禁止列出 **consents** 或绕过客户端绑定。
- **位置**：确保没有意外的代码修改或绕过。

## Behavior Gate
- **检查点**：验证跨客户端访问是否会返回 `404`，并确保客户端绑定。
- **位置**：运行时验证客户端绑定逻辑。

## Scope (allowed files)
- `internal/httpapi/handler.go`
- `internal/atomic/consent/service.go`

## Forbidden Moves (negative constraints)
- No listing of consents
- No admin bypass

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-05/commands.jsonl`
- `artifacts/OB-AT-05/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-05/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-05/results.jsonl`
- `artifacts/OB-AT-05/summary.md`

## Required evidence / checks
- GET request should fail with `404` for cross-client access
- `go test ./...` should pass
- `gofmt` clean

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Task scope completed
- Forbidden moves not present
- Evidence Bundle generated and gates pass
