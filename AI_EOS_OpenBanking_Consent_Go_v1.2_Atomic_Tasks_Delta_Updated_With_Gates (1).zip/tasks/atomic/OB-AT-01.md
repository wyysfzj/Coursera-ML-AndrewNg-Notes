
# OB‑AT‑01 — Request Signature Verification (Ed25519)

## Objective
- Implement signature verification for `POST /consents` requests using Ed25519 for client authentication.
- Ensure that requests are signed, and reject any requests that are not properly signed.

## Static Gate
- **检查点**：确保代码中没有遗漏签名验证的逻辑。
- **位置**：检查 `internal/atomic/consent/signature.go` 中的签名验证部分。

## Behavior Gate
- **检查点**：测试无签名请求是否被拒绝（401）。
- **位置**：通过运行时验证，确保没有签名的请求会被拒绝。

## Scope (allowed files)
- `internal/security/registry.go`
- `internal/atomic/consent/signature.go`

## Forbidden moves (negative constraints)
- No fallback authentication methods
- No accepting unsigned requests

## Evidence Bundle requirements (FPMS-style)
After completing the task, generate:
- `artifacts/OB-AT-01/commands.jsonl`
- `artifacts/OB-AT-01/git/diff.patch`, `rev.txt`, `status.txt`
- `artifacts/OB-AT-01/outputs/*_vet.log`, `*_test.log`, `*_format.log`
- `artifacts/OB-AT-01/results.jsonl`
- `artifacts/OB-AT-01/summary.md`

## Required evidence / checks
- Signature verification tests must pass (e.g., correct signature matching)
- `gofmt` clean

## Suggested commands
```bash
gofmt -w .
go vet ./...
go test ./...
```

## Definition of Done
- Task scope completed
- Forbidden moves not present
- Evidence Bundle generated and gates pass
