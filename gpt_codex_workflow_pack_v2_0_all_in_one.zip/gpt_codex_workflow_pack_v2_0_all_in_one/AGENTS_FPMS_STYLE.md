# AGENTS_FPMS_STYLE.md（All‑in‑One v2.0）

> 最高规则文件。**任何例外必须走 Decision。**

## 项目参数
- Project Type: Backend/API | Microservice | Mobile/SDK | Infra
- Stack:
- Data Store: NONE | SQLITE | SQL | NOSQL | LOCAL
- Schema Policy: NO_SCHEMA_CHANGES | FORWARD_ONLY | FREE
- Seed: NO_SEED | IDEMPOTENT
- Contract: OPENAPI | PROTO | EVENT_SCHEMA | NONE
- AuthZ: INJECTABLE_DEP | SDK_GUARD | GATEWAY | NONE
- Commands:
  - Lint: ./scripts/run_lint.sh
  - Test: ./scripts/run_test.sh
  - E2E:  ./scripts/run_e2e.sh

## Hard Rules
1. Atomic Task Only（一次一条）
2. Scope Freeze（禁止夹带）
3. Contract First（如适用）
4. Quality Gates 必须通过
5. Evidence Pack 必须存在
6. Task Gate / Release Gate 必须通过

## 强制门禁
- 单任务：`task_validate.sh <TASK-ID>`
- PR/CI：`task_validate_batch.sh`
- 发布前：`release_gate.sh`

