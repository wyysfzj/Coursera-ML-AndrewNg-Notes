# GPT + Codex/Copilot 开发加速包（All‑in‑One v2.0）

**目标**：一次性提供“流程 + 规则 + 模板 + 工程骨架 + 自动校验 + CI 门禁 + 报告”的完整能力，
避免多轮迭代升级成本，适用于 Backend / Microservice / Mobile / SDK / Infra 项目。

## 一次性包含的强化能力
- 流程：MDD → Atomic Tasks → Prompts → Code/Test → E2E → Checklist → Evidence
- 规则：AGENTS（通用 + FPMS 风格，参数化）
- 工程骨架：scripts/、Makefile、PR 模板
- Evidence Pack：自动落盘（logs/diff/env）
- Task Gate：单任务校验 + **批量校验**
- Change Surface：Allowlist 自动检查
- Checklist 覆盖率：AC → Tasks → Tests → **Matrix 报告**
- CI 集成：GitHub Actions / GitLab CI 示例
- 报告：Markdown + JSON（机器可读）
- Release Gate：发布前一键校验（P0 必须全绿）

## 快速落地（≤20 分钟）
1. 复制 `AGENTS_FPMS_STYLE.md` 到 repo root 并填写参数区
2. 复制 `scripts/` 到 repo，配置 run_lint/run_test/run_e2e
3. 初始化 checklist：`docs/acceptance/acceptance_checklist.md`
4. 每条任务：
   - `./scripts/task.sh <TASK-ID> "<desc>"`
   - `./scripts/evidence_run.sh ...`
   - `./scripts/evidence_finalize.sh <TASK-ID>`
   - `./scripts/task_validate.sh <TASK-ID>`
5. PR/CI：
   - `./scripts/task_validate_batch.sh`
   - `./scripts/e2e_matrix.sh`
   - `./scripts/release_gate.sh`

