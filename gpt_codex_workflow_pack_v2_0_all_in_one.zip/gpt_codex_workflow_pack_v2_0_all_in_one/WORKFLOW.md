# 工作流（All‑in‑One v2.0）
日期：2026-01-02

**闭环**：MDD → Tasks → Prompts → Evidence → Matrix → Gates → Release

## Gates
- Task Gate：证据/测试/变更面
- PR Gate：批量 Task 校验 + Matrix
- Release Gate：P0 AC 全覆盖 + 全绿
