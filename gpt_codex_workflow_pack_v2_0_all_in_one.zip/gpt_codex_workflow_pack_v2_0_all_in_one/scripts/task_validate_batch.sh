#!/usr/bin/env bash
set -euo pipefail
# Extract TASK-IDs from commits (pattern: ABC-123)
TASKS=$(git log --pretty=%s origin/main..HEAD | grep -oE '[A-Z]+-[0-9]+' | sort -u || true)
for t in $TASKS; do ./scripts/task_validate.sh "$t"; done
