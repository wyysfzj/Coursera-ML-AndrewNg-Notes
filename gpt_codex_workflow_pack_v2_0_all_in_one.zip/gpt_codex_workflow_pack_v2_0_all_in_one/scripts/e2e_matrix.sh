#!/usr/bin/env bash
set -euo pipefail
python3 scripts/checklist_to_matrix.py docs/acceptance/acceptance_checklist.md artifacts/e2e_matrix.json
