#!/usr/bin/env bash
set -euo pipefail
TASK="$1"; STEP="$2"; shift 2
ART="artifacts/$TASK"; mkdir -p "$ART/outputs"
TS="$(date -u +%Y%m%dT%H%M%SZ)"
LOG="$ART/outputs/${TS}_${STEP}.log"
printf '{"ts":"%s","step":"%s","cmd":"%s"}\n' "$TS" "$STEP" "$*" >> "$ART/commands.jsonl"
set +e; "$@" >"$LOG" 2>&1; RC=$?; set -e
printf '{"ts":"%s","step":"%s","rc":%s,"out":"%s"}\n' "$TS" "$STEP" "$RC" "$LOG" >> "$ART/results.jsonl"
[ $RC -eq 0 ] || { echo "FAIL $STEP"; exit $RC; }
