#!/usr/bin/env bash
set -euo pipefail
./scripts/task_validate_batch.sh
./scripts/e2e_matrix.sh
echo "Release Gate PASS"
