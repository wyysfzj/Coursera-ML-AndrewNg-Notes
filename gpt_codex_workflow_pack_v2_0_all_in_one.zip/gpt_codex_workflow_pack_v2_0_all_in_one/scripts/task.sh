#!/usr/bin/env bash
set -euo pipefail
TASK="$1"; mkdir -p "artifacts/$TASK/outputs"
echo "Task $TASK started."
