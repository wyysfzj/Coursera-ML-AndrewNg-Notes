#!/usr/bin/env bash
set -euo pipefail
TASK="$1"; ART="artifacts/$TASK"; mkdir -p "$ART/git" "$ART/env"
git diff >"$ART/git/diff.patch" || true
git status --porcelain >"$ART/git/status.txt" || true
git rev-parse HEAD >"$ART/git/rev.txt" || true
: >"$ART/summary.md"
