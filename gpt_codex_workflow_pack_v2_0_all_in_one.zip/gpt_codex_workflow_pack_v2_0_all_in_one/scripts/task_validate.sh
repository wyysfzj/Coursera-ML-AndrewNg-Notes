#!/usr/bin/env bash
set -euo pipefail
TASK="$1"; ART="artifacts/$TASK"
[ -d "$ART" ] || exit 1
[ -f "$ART/summary.md" ] || exit 1
grep -q '"step":"lint".*"rc":0' "$ART/results.jsonl" || exit 1
grep -q '"step":"test".*"rc":0' "$ART/results.jsonl" || exit 1
