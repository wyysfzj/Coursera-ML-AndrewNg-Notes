#!/usr/bin/env python3
# Simplified parser to generate coverage JSON/MD
import sys, json, re, pathlib
md = pathlib.Path(sys.argv[1]).read_text()
acs = re.findall(r'\|\s*(AC-[^|]+)\s*\|', md)
out = {"total": len(set(acs)), "acs": list(set(acs))}
pathlib.Path(sys.argv[2]).write_text(json.dumps(out, indent=2))
