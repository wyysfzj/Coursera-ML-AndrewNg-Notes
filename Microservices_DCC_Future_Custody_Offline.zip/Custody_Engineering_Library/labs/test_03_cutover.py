"""Teaching model: consistent snapshot and ordered CDC feed are ASSUMPTIONS.
Fencing below is a single-thread in-memory simulation, not a distributed lease.
"""
import unittest

class Mirror:
    def __init__(self,snapshot,watermark):self.rows=dict(snapshot);self.watermark=watermark;self.pending={}
    def event(self,seq,key,quantity):
        if seq<=self.watermark:return
        item=(key,quantity)
        if seq in self.pending and self.pending[seq]!=item:raise ValueError('CDC sequence conflict')
        self.pending[seq]=item
        while self.watermark+1 in self.pending:
            k,v=self.pending.pop(self.watermark+1)
            if v is None:self.rows.pop(k,None)
            else:self.rows[k]=v
            self.watermark+=1

def breaks(expected,actual):
    return [(k,expected.get(k),actual.get(k)) for k in sorted(set(expected)|set(actual)) if expected.get(k)!=actual.get(k)]

class Authority:
    def __init__(self):self.owner='OLD';self.epoch=1;self.records=[]
    def write(self,owner,epoch,item):
        if (owner,epoch)!=(self.owner,self.epoch):raise PermissionError('FENCED')
        self.records.append(item)
    def switch(self,target,expected_epoch,lag,unresolved):
        if expected_epoch!=self.epoch or lag!=0 or unresolved:raise ValueError('NO_GO')
        self.owner=target;self.epoch+=1;return self.epoch

class CutoverTests(unittest.TestCase):
    def test_gap_blocks_contiguous_watermark(self):
        m=Mirror({'A':100},10);m.event(12,'A',130)
        self.assertEqual(m.watermark,10);self.assertEqual(m.rows['A'],100)
        m.event(11,'A',120);self.assertEqual(m.watermark,12);self.assertEqual(m.rows['A'],130)
    def test_replay_and_delete(self):
        m=Mirror({'A':100},10);m.event(11,'A',None);m.event(11,'A',None)
        self.assertEqual(m.rows,{});self.assertEqual(m.watermark,11)
    def test_totals_can_hide_wrong_accounts(self):
        expected={'A':100,'B':200};bad={'A':200,'B':100}
        self.assertEqual(sum(expected.values()),sum(bad.values()));self.assertEqual(len(breaks(expected,bad)),2)
    def test_lag_or_breaks_prevent_cutover(self):
        a=Authority()
        for lag,diffs in [(1,[]),(0,['missing I1'])]:
            with self.assertRaises(ValueError):a.switch('NEW',1,lag,diffs)
        self.assertEqual(a.owner,'OLD')
    def test_old_writer_fenced(self):
        a=Authority();a.write('OLD',1,'I1');new_epoch=a.switch('NEW',1,0,[])
        with self.assertRaises(PermissionError):a.write('OLD',1,'I2')
        a.write('NEW',new_epoch,'I2');self.assertEqual(a.records,['I1','I2'])
    def test_returning_route_is_not_data_rollback(self):
        old={'I1':100};new=dict(old);new['I2']=200
        self.assertEqual(breaks(new,old),[('I2',200,None)])

if __name__=='__main__':unittest.main(verbosity=2)
