"""Teaching only: durable instruction identity, not real market settlement.
Trusted market receipts and single process are assumed. No network calls.
Receipt sequence is a positive integer, monotonic within one instruction.
An older receipt cannot change the latest state; this does not derive legal
settlement finality or authenticate the external market's messages.
"""
import sqlite3, tempfile, unittest
from pathlib import Path

def connect(path):
    db=sqlite3.connect(path)
    db.executescript('''CREATE TABLE IF NOT EXISTS instruction(
      ref TEXT PRIMARY KEY, account TEXT NOT NULL, isin TEXT NOT NULL,
      qty INTEGER NOT NULL CHECK(qty>0), status TEXT NOT NULL, seq INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS receipt(event_id TEXT PRIMARY KEY, ref TEXT, seq INTEGER, status TEXT);''')
    return db

def submit(db, ref, account, isin, qty):
    if type(qty) is not int or qty<=0: raise ValueError('positive integer quantity required')
    with db:
        db.execute('INSERT OR IGNORE INTO instruction VALUES(?,?,?,?,?,0)',(ref,account,isin,qty,'ACCEPTED'))
        row=db.execute('SELECT account,isin,qty,status FROM instruction WHERE ref=?',(ref,)).fetchone()
        if row[:3]!=(account,isin,qty): raise ValueError('IDEMPOTENCY_CONFLICT')
        return row[3]

def receipt(db, event_id, ref, seq, status):
    if type(seq) is not int or seq<=0:raise ValueError('positive integer sequence required')
    if status not in ('MATCHED','PENDING','SETTLED','REJECTED'):raise ValueError('unknown status')
    with db:
        previous=db.execute('SELECT ref,seq,status FROM receipt WHERE event_id=?',(event_id,)).fetchone()
        if previous:
            if previous!=(ref,seq,status):raise ValueError('EVENT_ID_CONFLICT')
            return 'DUPLICATE'
        row=db.execute('SELECT seq,status FROM instruction WHERE ref=?',(ref,)).fetchone()
        if row is None:raise ValueError('unknown instruction')
        db.execute('INSERT INTO receipt VALUES(?,?,?,?)',(event_id,ref,seq,status))
        if seq<=row[0]:return 'STALE'
        if row[1] in ('SETTLED','REJECTED') and status!=row[1]:raise ValueError('TERMINAL_CONFLICT')
        db.execute('UPDATE instruction SET status=?,seq=? WHERE ref=?',(status,seq,ref))
        return status

class IdempotencyTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'lab.db';self.db=connect(self.path)
    def tearDown(self):self.db.close();self.temp.cleanup()
    def test_same_intent_survives_reconnect(self):
        self.assertEqual(submit(self.db,'I1','A1','TEST-ISIN',100),'ACCEPTED')
        self.db.close();self.db=connect(self.path)
        self.assertEqual(submit(self.db,'I1','A1','TEST-ISIN',100),'ACCEPTED')
        self.assertEqual(self.db.execute('SELECT count(*) FROM instruction').fetchone()[0],1)
    def test_same_key_changed_intent_rejected(self):
        submit(self.db,'I1','A1','TEST-ISIN',100)
        with self.assertRaisesRegex(ValueError,'CONFLICT'):submit(self.db,'I1','A1','TEST-ISIN',101)
    def test_timeout_does_not_imply_failure(self):
        submit(self.db,'I1','A1','TEST-ISIN',100)
        # Simulated response loss: client receives nothing; query/retry same intent.
        receipt(self.db,'E1','I1',3,'SETTLED')
        self.assertEqual(submit(self.db,'I1','A1','TEST-ISIN',100),'SETTLED')
    def test_duplicate_and_stale_receipts(self):
        submit(self.db,'I1','A1','TEST-ISIN',100)
        receipt(self.db,'E3','I1',3,'SETTLED')
        self.assertEqual(receipt(self.db,'E3','I1',3,'SETTLED'),'DUPLICATE')
        self.assertEqual(receipt(self.db,'E2','I1',2,'PENDING'),'STALE')
        self.assertEqual(submit(self.db,'I1','A1','TEST-ISIN',100),'SETTLED')
    def test_conflicting_receipt_rolls_back(self):
        submit(self.db,'I1','A1','TEST-ISIN',100);receipt(self.db,'E1','I1',1,'SETTLED')
        with self.assertRaisesRegex(ValueError,'TERMINAL'):receipt(self.db,'E2','I1',2,'REJECTED')
        self.assertEqual(self.db.execute('SELECT count(*) FROM receipt').fetchone()[0],1)
    def test_invalid_quantity(self):
        for qty in (0,-1,1.5,True):
            with self.assertRaises(ValueError):submit(self.db,'I1','A1','TEST-ISIN',qty)
    def test_invalid_receipt_sequence_does_not_write(self):
        submit(self.db,'I1','A1','TEST-ISIN',100)
        for seq in (0,-1,True,1.5,None,'1'):
            with self.assertRaisesRegex(ValueError,'sequence'):receipt(self.db,'E1','I1',seq,'SETTLED')
        self.assertEqual(self.db.execute('SELECT count(*) FROM receipt').fetchone()[0],0)
        self.assertEqual(submit(self.db,'I1','A1','TEST-ISIN',100),'ACCEPTED')

if __name__=='__main__':unittest.main(verbosity=2)
