"""Synthetic corporate action: 1 new share for every 5, per-account floor.
This rounding/election policy is invented for this exercise, not a market rule.
Eligible balances are GIVEN, already validated at the assumed record date;
this function does not calculate record-date entitlement or trade/claim effects.
Numbers must be decimal strings, integers or Decimal values (never binary float).
Cash rounding uses the explicit classroom policy ROUND_HALF_EVEN to 2 places.
"""
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_HALF_EVEN
from datetime import datetime, timezone
import unittest

def exact_number(value):
    if isinstance(value,bool) or not isinstance(value,(str,int,Decimal)):
        raise ValueError('exact decimal input required')
    try:return Decimal(value)
    except InvalidOperation as exc:raise ValueError('invalid decimal input') from exc

def rights(eligible):
    q=exact_number(eligible)
    if not q.is_finite() or q<0:raise ValueError('invalid eligible quantity')
    exact=q/Decimal(5)
    whole=exact.quantize(Decimal('1'),rounding=ROUND_DOWN)
    return whole,exact-whole

def elect(event_version,supplied_version,eligible,requested,received,cutoff,price='2.50'):
    if event_version!=supplied_version:raise ValueError('STALE_TERMS')
    if received.utcoffset() is None or cutoff.utcoffset() is None:raise ValueError('timezone required')
    # This classroom contract accepts exactly at the cutoff.
    if received>cutoff:raise ValueError('LATE_ELECTION')
    max_qty,_=rights(eligible);q=exact_number(requested)
    if not q.is_finite() or q<0 or q!=q.to_integral_value() or q>max_qty:raise ValueError('EXCEEDS_RIGHTS')
    p=exact_number(price)
    if not p.is_finite() or p<=0:raise ValueError('positive finite price required')
    return (q*p).quantize(Decimal('.01'),rounding=ROUND_HALF_EVEN)

class EntitlementTests(unittest.TestCase):
    def setUp(self):self.cutoff=datetime(2026,11,10,12,tzinfo=timezone.utc)
    def test_fraction_is_explicit(self):self.assertEqual(rights('103'),(Decimal('20'),Decimal('.6')))
    def test_no_aggregate_rounding_substitution(self):
        each=sum(rights(q)[0] for q in ('103','102'))
        self.assertEqual(each,Decimal(40));self.assertEqual(rights('205')[0],Decimal(41))
    def test_cost_at_exact_cutoff(self):
        self.assertEqual(elect(2,2,'103','20',self.cutoff,self.cutoff),Decimal('50.00'))
    def test_stale_terms_rejected(self):
        with self.assertRaisesRegex(ValueError,'STALE'):elect(2,1,'103','20',self.cutoff,self.cutoff)
    def test_late_and_over_election(self):
        with self.assertRaisesRegex(ValueError,'LATE'):elect(2,2,'103','20',self.cutoff.replace(second=1),self.cutoff)
        with self.assertRaisesRegex(ValueError,'EXCEEDS'):elect(2,2,'103','21',self.cutoff,self.cutoff)
    def test_invalid_quantity_and_timezone(self):
        for q in ('-1','NaN','Infinity'):
            with self.assertRaises(ValueError):rights(q)
        with self.assertRaisesRegex(ValueError,'timezone'):elect(2,2,'103','1',self.cutoff.replace(tzinfo=None),self.cutoff)
    def test_binary_float_and_boolean_are_rejected(self):
        for q in (0.1,True):
            with self.assertRaisesRegex(ValueError,'exact'):rights(q)
        with self.assertRaisesRegex(ValueError,'exact'):elect(2,2,'103',1.0,self.cutoff,self.cutoff)
    def test_price_must_be_positive_and_finite(self):
        for price in ('NaN','Infinity','-2.50','0'):
            with self.assertRaisesRegex(ValueError,'price'):elect(2,2,'103','1',self.cutoff,self.cutoff,price)
    def test_cash_rounding_policy_is_explicit(self):
        self.assertEqual(elect(2,2,'103','1',self.cutoff,self.cutoff,'2.505'),Decimal('2.50'))
        self.assertEqual(elect(2,2,'103','1',self.cutoff,self.cutoff,'2.515'),Decimal('2.52'))

if __name__=='__main__':unittest.main(verbosity=2)
