"""Two SQLite connections simulate producer and consumer local transactions.
The broker is a Python value; replay is at least once. No real messaging system.
"""
import sqlite3, unittest

def producer():
    db=sqlite3.connect(':memory:')
    db.executescript('CREATE TABLE instruction(ref TEXT PRIMARY KEY,qty INT);CREATE TABLE outbox(event_id TEXT PRIMARY KEY,ref TEXT,qty INT);')
    return db
def consumer():
    db=sqlite3.connect(':memory:')
    db.executescript('CREATE TABLE inbox(event_id TEXT PRIMARY KEY,ref TEXT,qty INT);CREATE TABLE posting(ref TEXT PRIMARY KEY,qty INT);')
    return db
def create(db,ref,qty,fail=False):
    with db:
        db.execute('INSERT INTO instruction VALUES(?,?)',(ref,qty))
        if fail:raise RuntimeError('crash before outbox insert')
        db.execute('INSERT INTO outbox VALUES(?,?,?)',('event-'+ref,ref,qty))
def consume(db,event,fail=False):
    eid,ref,qty=event
    with db:
        seen=db.execute('SELECT ref,qty FROM inbox WHERE event_id=?',(eid,)).fetchone()
        if seen:
            if seen!=(ref,qty):raise ValueError('event payload conflict')
            return 'duplicate'
        db.execute('INSERT INTO inbox VALUES(?,?,?)',event)
        old=db.execute('SELECT qty FROM posting WHERE ref=?',(ref,)).fetchone()
        if old and old[0]!=qty:raise ValueError('business intent conflict')
        if fail:raise RuntimeError('crash before posting')
        db.execute('INSERT OR IGNORE INTO posting VALUES(?,?)',(ref,qty))
        return 'applied' if old is None else 'business duplicate'

class OutboxTests(unittest.TestCase):
    def setUp(self):self.p=producer();self.c=consumer()
    def tearDown(self):self.p.close();self.c.close()
    def test_producer_atomicity(self):
        with self.assertRaises(RuntimeError):create(self.p,'I1',100,True)
        self.assertEqual(self.p.execute('SELECT count(*) FROM instruction').fetchone()[0],0)
        self.assertEqual(self.p.execute('SELECT count(*) FROM outbox').fetchone()[0],0)
    def test_lost_ack_replays_without_duplicate_effect(self):
        create(self.p,'I1',100);e=self.p.execute('SELECT * FROM outbox').fetchone()
        self.assertEqual(consume(self.c,e),'applied')
        self.assertEqual(consume(self.c,e),'duplicate')
        self.assertEqual(self.c.execute('SELECT sum(qty) FROM posting').fetchone()[0],100)
    def test_consumer_atomicity(self):
        e=('E1','I1',100)
        with self.assertRaises(RuntimeError):consume(self.c,e,True)
        self.assertEqual(self.c.execute('SELECT count(*) FROM inbox').fetchone()[0],0)
        self.assertEqual(consume(self.c,e),'applied')
    def test_new_event_id_same_business_intent(self):
        consume(self.c,('E1','I1',100));self.assertEqual(consume(self.c,('E2','I1',100)),'business duplicate')
        self.assertEqual(self.c.execute('SELECT count(*) FROM posting').fetchone()[0],1)
    def test_payload_conflict_not_swallowed(self):
        consume(self.c,('E1','I1',100))
        with self.assertRaises(ValueError):consume(self.c,('E1','I1',101))
        with self.assertRaises(ValueError):consume(self.c,('E2','I1',101))
        self.assertEqual(self.c.execute('SELECT count(*) FROM inbox').fetchone()[0],1)

if __name__=='__main__':unittest.main(verbosity=2)
