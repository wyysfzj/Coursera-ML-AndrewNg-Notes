# Source References

These references were used to frame the PSD2 regulatory abstraction. Review current local legal and regulatory obligations before production deployment.

## PSD2 / European Commission

- European Commission — Payment Services Directive 2 overview and strong customer authentication context:
  https://ec.europa.eu/newsroom/fisma/items/607684

## EBA Single Rulebook

- EBA Interactive Single Rulebook — PSD2 Article 65, 66, 67, 95, 96, 97, 98 references:
  https://www.eba.europa.eu/regulation-and-policy/single-rulebook/interactive-single-rulebook/14575

## EBA RTS / SCA / CSC

- EBA — amendment to RTS on SCA and secure communication, including account information access SCA renewal changes:
  https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-final-report-amendment-its-technical-standards

## Incident Reporting / DORA Interaction

- EBA — repeal of Guidelines on major incident reporting under PSD2 due to DORA framework:
  https://www.eba.europa.eu/publications-and-media/press-releases/eba-repeals-guidelines-major-incident-reporting-under-revised-payment-services-directive

## Security Measures Under PSD2

- EBA — final guidelines on security measures under PSD2:
  https://www.eba.europa.eu/publications-and-media/press-releases/eba-publishes-final-guidelines-security-measures-under-psd2

## Dedicated Interface / SCA / Secure Communication

- CSSF — obligations regarding SCA and common and secure open standards of communication under Commission Delegated Regulation EU 2018/389:
  https://www.cssf.lu/en/2019/02/obligations-regarding-strong-customer-authentication-and-common-and-secure-open-standards-of-communication-under-commission-delegated-regulation-eu-2018-389/

## Open Banking CoF proposition

- Open Banking Standards — Confirmation of Funds proposition and constraints:
  https://standards.openbanking.org.uk/get-started/propositions/p6/
