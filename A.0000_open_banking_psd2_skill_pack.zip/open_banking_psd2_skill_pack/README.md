# Open Banking PSD2 AI Agent Skill Pack

版本：0.1.0  
用途：把 PSD2 Open Banking 监管 API 要求抽象成 AI Agent 可执行的 Skill Pack，用于 AIS、PIS、CoF、Consent/Auth、Security Monitoring 等场景。

## 文件结构

```text
open_banking_psd2_skill_pack/
├── README.md
├── SKILL.md
├── skill_pack.yaml
├── mcp_tools.json
├── langchain_tools.py
├── compliance_checklist.md
├── normalized_error_model.yaml
└── source_refs.md
```

## 核心设计原则

PSD2 不应该被完整塞进 Agent prompt。法规应只进入以下位置：

- 前置条件：TPP 身份、eIDAS/mTLS、consent、SCA、scope。
- 能力边界：AIS 只读，PIS 只发起支付，CoF 只返回 yes/no。
- 拒绝条件：无 consent、无授权角色、SCA 失败、scope 越界、证书无效。
- 审计字段：request_id、consent_id_hash、aspsp_id、tpp_role、decision。
- 错误处理：统一错误码，避免把银行原始错误直接暴露给 Agent。
- 升级路径：incident candidate、fraud review、manual compliance review。

## 5 个 Skill

| Skill | 作用 |
|---|---|
| `psd2.consent_auth` | 处理 consent、SCA、OAuth/Redirect、mTLS/eIDAS、TPP role 校验 |
| `psd2.ais` | 读取账户列表、账户详情、余额、交易 |
| `psd2.pis` | 发起支付、启动 SCA、查询支付状态 |
| `psd2.cof_compliance` | CoF 资金确认与数据最小化，只返回 yes/no |
| `psd2.security_monitoring` | 错误归一化、交易监控、incident candidate、fraud signal |

## 重要实现提醒

不要把 AIS 的 SCA renewal 直接硬编码成“90 天 consent 有效期”。建议使用：

```yaml
consent.valid_until: 由 ASPSP / API profile 返回或配置
sca_renewal_due_at: SCA 重新认证截止时间
```

实际部署时，`ais_sca_renewal_days` 应根据本地监管、ASPSP profile、API 标准和组织政策配置，例如 90、180 或 bank-specific value。

## 如何使用

### Claude Skill

将 `SKILL.md` 放入 Claude Skill 目录。实际银行 API connector、证书、token secret、SCA secret 不应放入 Skill 文件，而应放在受控工具层。

### MCP

使用 `mcp_tools.json` 作为 MCP tool manifest 的起点。每个 tool 需要在服务端实现合规 middleware：

```text
validate_schema
→ validate_tpp_role_and_certificate
→ validate_consent_and_scope
→ validate_sca_state
→ execute_connector
→ normalize_response
→ audit_event
```

### LangChain

使用 `langchain_tools.py` 作为 `StructuredTool` 骨架。生产环境中需要替换 `connector_call()`、`validate_access()` 和 `audit_event()`。

## 免责声明

本 Skill Pack 是监管要求的工程化抽象，不构成法律意见。生产上线前应由法律、合规、安全、风险、工程团队共同审查，并根据具体市场、ASPSP profile、API standard、DORA/本地 incident reporting 要求进行配置。
