"""
LangChain StructuredTool skeleton for PSD2 Open Banking AI Agent Skill Pack.

This file is intentionally connector-agnostic. Replace the following functions before production use:

- validate_tpp_role_and_certificate
- validate_consent_and_scope
- validate_sca_state_or_exemption
- execute_connector_call
- audit_event

Do not store PSU credentials, SCA secrets, private keys, OAuth client secrets, or raw access tokens in this layer.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import Enum
from typing import Any, Dict, List, Literal, Optional

try:
    from pydantic import BaseModel, Field, field_validator
except ImportError as exc:  # pragma: no cover
    raise RuntimeError("Install pydantic before using this skeleton: pip install pydantic") from exc


class NormalizedError(str, Enum):
    CONSENT_REQUIRED = "CONSENT_REQUIRED"
    CONSENT_EXPIRED = "CONSENT_EXPIRED"
    CONSENT_REVOKED = "CONSENT_REVOKED"
    SCA_REQUIRED = "SCA_REQUIRED"
    SCA_FAILED = "SCA_FAILED"
    TPP_CERT_INVALID = "TPP_CERT_INVALID"
    TPP_ROLE_NOT_ALLOWED = "TPP_ROLE_NOT_ALLOWED"
    SCOPE_NOT_ALLOWED = "SCOPE_NOT_ALLOWED"
    ACCOUNT_NOT_FOUND = "ACCOUNT_NOT_FOUND"
    ACCOUNT_NOT_ACCESSIBLE_ONLINE = "ACCOUNT_NOT_ACCESSIBLE_ONLINE"
    ASPSP_UNAVAILABLE = "ASPSP_UNAVAILABLE"
    RATE_LIMITED = "RATE_LIMITED"
    USER_CONFIRMATION_REQUIRED = "USER_CONFIRMATION_REQUIRED"
    PAYMENT_REJECTED = "PAYMENT_REJECTED"
    PAYMENT_STATUS_UNKNOWN = "PAYMENT_STATUS_UNKNOWN"
    PAYMENT_DYNAMIC_LINK_MISMATCH = "PAYMENT_DYNAMIC_LINK_MISMATCH"
    INSUFFICIENT_FUNDS_SIGNAL = "INSUFFICIENT_FUNDS_SIGNAL"
    COF_NOT_SUPPORTED = "COF_NOT_SUPPORTED"
    FRAUD_RISK_BLOCK = "FRAUD_RISK_BLOCK"
    INCIDENT_CANDIDATE = "INCIDENT_CANDIDATE"


class TppRole(str, Enum):
    AISP = "AISP"
    PISP = "PISP"
    CBPII = "CBPII"


class AccessDecision(BaseModel):
    allowed: bool
    reason: str
    sca_required: bool = False
    normalized_error: Optional[NormalizedError] = None


class AISRequest(BaseModel):
    operation: Literal["list_accounts", "get_account_details", "get_balances", "get_transactions"]
    aspsp_id: str
    consent_id: str
    account_id: Optional[str] = None
    date_from: Optional[date] = None
    date_to: Optional[date] = None
    include_pending: bool = False

    @field_validator("date_to")
    @classmethod
    def validate_date_order(cls, v: Optional[date], info: Any) -> Optional[date]:
        date_from = info.data.get("date_from")
        if v and date_from and v < date_from:
            raise ValueError("date_to must be greater than or equal to date_from")
        return v


class AccountRef(BaseModel):
    iban: Optional[str] = None
    account_id: Optional[str] = None


class CreditorAccount(BaseModel):
    iban: str


class PISRequest(BaseModel):
    operation: Literal["prepare_payment", "initiate_payment", "start_payment_authorisation", "get_payment_status"]
    aspsp_id: str
    payment_product: Literal[
        "sepa_credit_transfer",
        "instant_sepa_credit_transfer",
        "domestic_credit_transfer",
        "bank_profile_specific",
    ]
    debtor_account: AccountRef
    creditor_account: CreditorAccount
    creditor_name: str
    amount: float = Field(gt=0)
    currency: str
    payment_id: Optional[str] = None
    remittance_information: Optional[str] = None
    requested_execution_date: Optional[date] = None
    user_confirmed: bool = False


class CoFRequest(BaseModel):
    aspsp_id: str
    cof_consent_id: str
    account_id: str
    amount: float = Field(gt=0)
    currency: str
    card_transaction_reference: str


class SecurityEvent(BaseModel):
    event_type: Literal[
        "api_error",
        "sca_failure",
        "payment_anomaly",
        "consent_anomaly",
        "certificate_failure",
        "aspsp_downtime",
        "suspected_fraud",
        "data_leak_signal",
    ]
    aspsp_id: str
    raw_event: Dict[str, Any]
    payment_id: Optional[str] = None
    consent_id: Optional[str] = None
    severity_hint: Optional[Literal["low", "medium", "high", "critical"]] = None


@dataclass
class RuntimeContext:
    tpp_role: TppRole
    request_id: str
    psu_id_hash: Optional[str] = None
    api_profile: str = "bank_specific"


# -----------------------------
# Replace these stubs in production
# -----------------------------


def validate_tpp_role_and_certificate(ctx: RuntimeContext, required_role: TppRole) -> AccessDecision:
    """Validate TPP role and certificate binding using trust registry / mTLS / eIDAS infrastructure."""
    if ctx.tpp_role != required_role:
        return AccessDecision(
            allowed=False,
            reason=f"Required role {required_role}; got {ctx.tpp_role}",
            normalized_error=NormalizedError.TPP_ROLE_NOT_ALLOWED,
        )
    return AccessDecision(allowed=True, reason="TPP role and certificate accepted")


def validate_consent_and_scope(consent_id: str, requested_scope: List[str]) -> AccessDecision:
    """Validate consent state, expiry, SCA renewal, and scope against consent store."""
    if not consent_id:
        return AccessDecision(
            allowed=False,
            reason="Missing consent",
            sca_required=False,
            normalized_error=NormalizedError.CONSENT_REQUIRED,
        )
    # Production implementation should check:
    # - status: valid / revoked / expired
    # - valid_until
    # - sca_renewal_due_at
    # - account scope
    # - frequency per day
    # - purpose limitation
    return AccessDecision(allowed=True, reason="Consent and scope accepted")


def validate_sca_state_or_exemption(resource_id: str) -> AccessDecision:
    """Validate SCA state or allowed exemption."""
    # Production implementation should check ASPSP authorisation state and SCA renewal policy.
    return AccessDecision(allowed=True, reason="SCA state accepted")


def execute_connector_call(operation: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Call the approved ASPSP/Open Banking connector. Never call untrusted bank endpoints directly."""
    raise NotImplementedError("Wire this to an approved Open Banking connector.")


def audit_event(event_name: str, ctx: RuntimeContext, payload: Dict[str, Any]) -> None:
    """Write minimal compliance audit event."""
    # Production implementation should hash consent_id/payment_id/psu_id and avoid raw sensitive payloads.
    pass


# -----------------------------
# Skill functions
# -----------------------------


def psd2_ais(request: AISRequest, ctx: RuntimeContext) -> Dict[str, Any]:
    role_decision = validate_tpp_role_and_certificate(ctx, TppRole.AISP)
    if not role_decision.allowed:
        return role_decision.model_dump()

    scope_map = {
        "list_accounts": ["accounts"],
        "get_account_details": ["account_details"],
        "get_balances": ["balances"],
        "get_transactions": ["transactions"],
    }
    consent_decision = validate_consent_and_scope(request.consent_id, scope_map[request.operation])
    if not consent_decision.allowed:
        return consent_decision.model_dump()

    sca_decision = validate_sca_state_or_exemption(request.consent_id)
    if not sca_decision.allowed:
        return sca_decision.model_dump()

    payload = request.model_dump(mode="json")
    audit_event(f"AIS_{request.operation.upper()}_REQUESTED", ctx, payload)
    response = execute_connector_call(f"ais.{request.operation}", payload)
    audit_event(f"AIS_{request.operation.upper()}_COMPLETED", ctx, {"aspsp_id": request.aspsp_id})
    return response


def psd2_pis(request: PISRequest, ctx: RuntimeContext) -> Dict[str, Any]:
    role_decision = validate_tpp_role_and_certificate(ctx, TppRole.PISP)
    if not role_decision.allowed:
        return role_decision.model_dump()

    if request.operation == "initiate_payment" and not request.user_confirmed:
        return AccessDecision(
            allowed=False,
            reason="Explicit user confirmation is required before initiating payment.",
            normalized_error=NormalizedError.USER_CONFIRMATION_REQUIRED,
        ).model_dump()

    dynamic_linking_fields = {
        "amount": request.amount,
        "currency": request.currency,
        "creditor_account": request.creditor_account.model_dump(),
        "creditor_name": request.creditor_name,
        "remittance_information": request.remittance_information,
    }

    payload = request.model_dump(mode="json")
    payload["dynamic_linking_fields"] = dynamic_linking_fields

    audit_event(f"PIS_{request.operation.upper()}_REQUESTED", ctx, payload)
    response = execute_connector_call(f"pis.{request.operation}", payload)
    audit_event(f"PIS_{request.operation.upper()}_COMPLETED", ctx, {"aspsp_id": request.aspsp_id})
    return response


def psd2_cof_confirm_funds(request: CoFRequest, ctx: RuntimeContext) -> Dict[str, Any]:
    role_decision = validate_tpp_role_and_certificate(ctx, TppRole.CBPII)
    if not role_decision.allowed:
        return role_decision.model_dump()

    consent_decision = validate_consent_and_scope(request.cof_consent_id, ["confirmation_of_funds"])
    if not consent_decision.allowed:
        return consent_decision.model_dump()

    payload = request.model_dump(mode="json")
    audit_event("COF_REQUESTED", ctx, payload)
    raw_response = execute_connector_call("cof.confirm_funds", payload)

    # Enforce data minimization at the Skill boundary: yes/no only.
    minimized = {
        "funds_available": bool(raw_response.get("funds_available")),
        "response_valid_for": "this_card_transaction_only",
        "normalized_error": raw_response.get("normalized_error"),
    }
    audit_event("COF_RESPONSE_RECEIVED", ctx, {"aspsp_id": request.aspsp_id})
    return minimized


def psd2_security_monitor(event: SecurityEvent, ctx: RuntimeContext) -> Dict[str, Any]:
    error_map = {
        "certificate_failure": NormalizedError.TPP_CERT_INVALID,
        "sca_failure": NormalizedError.SCA_FAILED,
        "aspsp_downtime": NormalizedError.ASPSP_UNAVAILABLE,
        "payment_anomaly": NormalizedError.FRAUD_RISK_BLOCK,
        "suspected_fraud": NormalizedError.FRAUD_RISK_BLOCK,
        "consent_anomaly": NormalizedError.SCOPE_NOT_ALLOWED,
        "data_leak_signal": NormalizedError.INCIDENT_CANDIDATE,
        "api_error": NormalizedError.PAYMENT_STATUS_UNKNOWN,
    }
    high_risk_types = {"certificate_failure", "payment_anomaly", "suspected_fraud", "data_leak_signal"}
    incident_candidate = event.event_type in high_risk_types or event.severity_hint in {"high", "critical"}

    result = {
        "normalized_error": error_map[event.event_type].value,
        "risk_score": 0.9 if incident_candidate else 0.4,
        "incident_candidate": incident_candidate,
        "recommended_action": "manual_review" if incident_candidate else "retry",
    }
    audit_event("SECURITY_EVENT_NORMALIZED", ctx, {"event_type": event.event_type, "aspsp_id": event.aspsp_id})
    return result


# Optional LangChain registration helper

def build_langchain_tools() -> List[Any]:
    """Return LangChain StructuredTool objects if langchain_core is installed."""
    try:
        from langchain_core.tools import StructuredTool
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("Install langchain-core before using build_langchain_tools().") from exc

    # In real deployments, ctx should be injected by your runtime, not user-supplied.
    return [
        StructuredTool.from_function(
            func=psd2_ais,
            name="psd2_ais",
            description="Read accounts, balances, details, or transactions within active AIS consent.",
        ),
        StructuredTool.from_function(
            func=psd2_pis,
            name="psd2_pis",
            description="Prepare, initiate, authorize, or check status of a PSD2 payment initiation.",
        ),
        StructuredTool.from_function(
            func=psd2_cof_confirm_funds,
            name="psd2_cof_confirm_funds",
            description="Confirm funds for a specific card transaction. Returns yes/no only.",
        ),
        StructuredTool.from_function(
            func=psd2_security_monitor,
            name="psd2_security_monitor",
            description="Normalize security/API errors and create incident candidate signals.",
        ),
    ]
