# PSD2 Regulatory Core Extraction

目标：把 PSD2 Open Banking 监管要求提炼成 Agent 可执行的能力边界，而不是把整部法规塞进 prompt。

## 1. AIS: Account Information Service

### 强制要求

- PSU 明确同意。
- TPP 具备 AISP 授权角色。
- TPP 身份通过 eIDAS/mTLS 或本地信任源验证。
- SCA 状态有效，或满足本地规则下允许的豁免。
- 请求的数据必须在 consent scope 内。
- 通过 ASPSP dedicated interface 或 approved connector 访问。

### API 能力边界

允许：

- 读取账户列表。
- 读取账户详情。
- 读取余额。
- 读取交易。

禁止：

- 发起支付。
- 修改账户状态。
- 读取 consent scope 外账户。
- 读取用户未授权的历史区间。
- 将账户信息用于未声明目的。

## 2. PIS: Payment Initiation Service

### 强制要求

- PSU 明确支付指令。
- TPP 具备 PISP 授权角色。
- 支付发起前必须验证 TPP 身份和证书绑定。
- SCA 必须执行，除非本地规则明确允许豁免。
- SCA 必须动态链接到金额和收款方。
- 支付状态必须从 ASPSP 或 approved connector 获取。

### API 能力边界

允许：

- 准备支付。
- 发起支付。
- 启动支付 SCA。
- 查询支付状态。

禁止：

- 未经用户确认发起支付。
- SCA 后静默修改金额、币种、收款人或收款账户。
- 声称支付已最终清算，除非 ASPSP 返回最终执行状态。
- 创建用户未明确请求的周期性付款或未来付款。

## 3. CoF: Confirmation of Funds

### 强制要求

- 调用方具备 CBPII 或本地等价角色。
- PSU 对 CoF 已明确同意。
- 请求必须绑定具体 card-based transaction。
- 只能用于特定金额的资金可用性确认。

### API 能力边界

允许：

- 返回 funds_available: true/false。

禁止：

- 返回余额。
- 返回交易历史。
- 冻结、保留、阻塞资金。
- 将 yes/no 结果用于信用评分、账户画像或非交易目的。

## 4. Consent & Authentication

### 强制要求

- TPP role validation。
- eIDAS/mTLS certificate validation。
- Consent lifecycle 管理。
- SCA orchestration。
- OAuth2 / Redirect / Embedded / Decoupled flow 按 API profile 处理。

### API 能力边界

允许：

- 创建 AIS consent。
- 启动授权流程。
- 检查 access 是否允许。
- 撤销 consent。
- 在允许的情况下 refresh access。

禁止：

- 获取或保存 PSU 网银密码。
- 保存 OTP、SCA secret、private key、raw token。
- 扩大 consent scope。
- 绕过 SCA。

## 5. Security Monitoring

### 强制要求

- 归一化错误码。
- 监控 SCA failure spike。
- 监控证书失败、role mismatch、scope abuse。
- 监控 payment dynamic linking mismatch。
- 监控 ASPSP dedicated interface availability/performance。
- 生成 incident candidate 和 fraud/security escalation。

### API 能力边界

允许：

- error normalization。
- risk signal generation。
- incident candidate creation。
- manual review routing。

禁止：

- 自动提交监管报告，除非组织政策明确允许。
- 为了完成任务而压制安全事件。
- 向 PSU 暴露未经批准的 raw incident details。
