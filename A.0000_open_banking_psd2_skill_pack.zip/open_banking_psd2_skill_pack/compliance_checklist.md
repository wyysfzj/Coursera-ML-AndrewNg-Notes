# PSD2 AI Agent Skill Compliance Checklist

用于上线前审查。建议由 Legal、Compliance、Security、Risk、Engineering 共同确认。

## 1. Regulatory Core Extraction

### AIS

- [ ] AIS Skill 只读。
- [ ] 账户列表、账户详情、余额、交易均受 consent scope 控制。
- [ ] date range、account_id、include_pending 等参数受到 schema 限制。
- [ ] 不允许 AIS Skill 发起支付或修改账户状态。
- [ ] 不返回 scope 外数据。
- [ ] account identifier 默认脱敏，除非业务和合规政策明确允许完整返回。

### PIS

- [ ] PIS Skill 只由 PISP 角色调用。
- [ ] 发起支付前要求用户明确确认金额、币种、收款人、收款账户、汇款信息。
- [ ] SCA 动态链接绑定金额和收款方。
- [ ] SCA 启动后，amount、currency、creditor_account、creditor_name、remittance_information 不可静默变更。
- [ ] payment status 不被误解释为最终清算，除非 ASPSP 明确返回最终状态。
- [ ] recurring / future-dated payment 只有在用户明确请求且 connector 支持时才允许。

### CoF

- [ ] CoF 只由 CBPII 或本地配置等价角色调用。
- [ ] CoF 请求必须绑定具体 card-based transaction。
- [ ] CoF 输出只包含 yes/no。
- [ ] CoF 不返回账户余额。
- [ ] CoF 不返回交易历史。
- [ ] CoF 不冻结、不保留、不阻塞资金。
- [ ] CoF 结果不用于 credit scoring、账户画像或非交易目的。

## 2. Consent & Authentication

- [ ] Consent lifecycle 包含 create、authorize、check、revoke、expire。
- [ ] `consent.valid_until` 与 `sca_renewal_due_at` 分离。
- [ ] AIS SCA renewal days 可配置，不硬编码为 90 天。
- [ ] 支持 redirect / embedded / decoupled / OAuth2 profile 的本地配置。
- [ ] 不保存 PSU 网银凭证。
- [ ] 不保存 SCA secret、OTP、raw authentication factor。
- [ ] 不保存私钥、OAuth client secret、raw access token 于 Agent Skill 层。
- [ ] 所有敏感 secret 在 secure infrastructure / vault / connector 层处理。

## 3. TPP Role & Certificate

- [ ] 调用前校验 TPP role：AISP / PISP / CBPII。
- [ ] 证书有效性检查已接入 QWAC/QSealC 或本地信任源。
- [ ] mTLS 绑定检查已实现。
- [ ] role mismatch 立即拒绝。
- [ ] certificate expired / revoked / invalid 立即拒绝并触发 security event。

## 4. Dedicated Interface / API Connector

- [ ] Agent 不直接调用未经批准的银行接口。
- [ ] 所有调用都经 approved ASPSP / Open Banking connector。
- [ ] connector 实现 rate limit、retry、timeout、idempotency。
- [ ] raw ASPSP response 不直接暴露给 Agent 或用户。
- [ ] raw payload retention 默认关闭，除非合规政策允许。

## 5. Error Model

- [ ] 原始银行错误已映射到 normalized error code。
- [ ] 主要错误码至少包含：
  - [ ] CONSENT_REQUIRED
  - [ ] CONSENT_EXPIRED
  - [ ] SCA_REQUIRED
  - [ ] SCA_FAILED
  - [ ] TPP_CERT_INVALID
  - [ ] TPP_ROLE_NOT_ALLOWED
  - [ ] SCOPE_NOT_ALLOWED
  - [ ] ASPSP_UNAVAILABLE
  - [ ] RATE_LIMITED
  - [ ] USER_CONFIRMATION_REQUIRED
  - [ ] PAYMENT_REJECTED
  - [ ] PAYMENT_STATUS_UNKNOWN
  - [ ] PAYMENT_DYNAMIC_LINK_MISMATCH
  - [ ] FRAUD_RISK_BLOCK
  - [ ] INCIDENT_CANDIDATE
- [ ] 不把 internal connector exception 原样暴露给最终用户。

## 6. Security Monitoring

- [ ] SCA failure spike 检测已实现。
- [ ] certificate failure 检测已实现。
- [ ] payment dynamic linking mismatch 检测已实现。
- [ ] consent scope abuse 检测已实现。
- [ ] ASPSP dedicated interface downtime / performance issue 检测已实现。
- [ ] suspected fraud signal 已接入 manual review。
- [ ] data leak signal 已接入 incident candidate。
- [ ] 不自动提交外部监管报告，除非组织政策明确允许。

## 7. Audit

- [ ] 每次调用记录 minimal audit event。
- [ ] audit event 包含：skill_id、operation、request_id、aspsp_id、tpp_role、timestamp、decision。
- [ ] consent_id、payment_id、psu_id 采用 hash 或 tokenized reference。
- [ ] audit event 不包含 PSU 凭证、SCA secret、raw OTP、private key。
- [ ] audit retention 按本地法律和组织政策配置。

## 8. Data Minimization

- [ ] AIS 只返回当前任务所需字段。
- [ ] PIS 只处理支付执行所需字段。
- [ ] CoF 只返回 yes/no。
- [ ] 默认 mask sensitive identifiers。
- [ ] 默认不保留 raw payload。
- [ ] 明确记录 purpose limitation。

## 9. Human Review

以下情况应要求人工审查：

- [ ] money movement 高风险或字段冲突。
- [ ] suspected fraud。
- [ ] incident candidate。
- [ ] data leak signal。
- [ ] TPP role / certificate mismatch。
- [ ] consent scope conflict。
- [ ] repeated SCA failure。
- [ ] ASPSP interface outage crossing reporting threshold。

## 10. Production Readiness

- [ ] 各市场 API profile 已配置，例如 Berlin Group、OBIE、STET 或 bank-specific。
- [ ] 本地法律、监管、DORA/PSD2 incident reporting 路径已配置。
- [ ] Legal/Compliance sign-off 完成。
- [ ] Security threat model 完成。
- [ ] Integration test 覆盖 AIS/PIS/CoF happy path 与 refusal path。
- [ ] Red-team prompt injection 测试完成。
- [ ] User-facing explanations 已经过合规审查。
