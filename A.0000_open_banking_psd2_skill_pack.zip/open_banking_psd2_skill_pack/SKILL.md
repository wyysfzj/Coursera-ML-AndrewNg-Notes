# PSD2 Open Banking Agent Skill

## Purpose

This Skill enables an AI Agent to interact with PSD2-style Open Banking APIs through compliant capability blocks:

1. Account Information Service, AIS.
2. Payment Initiation Service, PIS.
3. Confirmation of Funds, CoF.
4. Consent and Authentication.
5. Error and Security Monitoring.

The Skill converts PSD2 regulatory boundaries into executable checks, refusal rules, audit events, and API behavior constraints.

## Regulatory Boundary

The Agent must not treat PSD2 as general knowledge for unrestricted banking actions. The Agent may only perform actions exposed by approved Open Banking connectors and only when all required regulatory preconditions are satisfied.

### Core PSD2 Services

- AIS: read account information, balances, transactions, and account details within active consent.
- PIS: initiate payment orders with explicit user instruction, SCA, and dynamic linking.
- CoF: confirm availability of funds for a specific card-based transaction, returning only yes/no.

### Core Compliance Controls

- Strong Customer Authentication, SCA.
- OAuth2/Redirect/Embedded/Decoupled authorisation flows, depending on API profile.
- eIDAS certificate and/or mTLS validation.
- TPP role validation: AISP, PISP, CBPII.
- Consent lifecycle management.
- Dedicated interface or approved API connector usage.
- Transaction monitoring, incident candidate generation, fraud/security escalation.

## Global Guardrails

The Agent must always obey these rules:

1. Never ask the PSU for online banking credentials.
2. Never store PSU credentials, SCA factors, OTPs, authentication secrets, private keys, or raw access tokens in the Skill layer.
3. Never bypass SCA.
4. Never expand consent scope without a new PSU authorisation journey.
5. Never infer TPP permission from user text alone; always validate role and connector configuration.
6. Never initiate a payment without explicit user confirmation of amount, currency, creditor account, creditor name, and remittance information where applicable.
7. Never modify amount, currency, creditor account, creditor name, or remittance information after payment SCA has started.
8. Never return account balance from CoF.
9. Never use CoF result for credit scoring, account profiling, or non-transaction purposes.
10. Never suppress security events to complete a task.
11. Never submit external regulatory reports automatically unless deployment policy explicitly permits it.

## Skill Routing Rules

### When the user asks to view account data

Use `psd2.consent_auth.check_access` first.

If access is allowed, call `psd2.ais`.

If SCA is required, call `psd2.consent_auth.start_authorisation`.

Do not call PIS.

### When the user asks to send money

Extract:

- debtor account
- creditor account
- creditor name
- amount
- currency
- remittance information
- execution date, if relevant

If any payment-critical field is missing or ambiguous, require explicit user confirmation before initiating.

Call `psd2.pis.prepare_payment`, then start SCA with dynamic linking. Only call `psd2.pis.initiate_payment` after user confirmation and successful authorisation.

### When the user asks whether funds are available

Use `psd2.cof_compliance.confirm_funds` only if:

- caller role is CBPII or equivalent configured role,
- request relates to a specific card-based payment transaction,
- valid consent exists,
- ASPSP supports CoF.

Return yes/no only.

### When any API, authentication, security, or fraud anomaly occurs

Call `psd2.security_monitoring.normalize_error`.

If the event is high risk, call `psd2.security_monitoring.raise_incident_candidate`.

Use manual review for suspected fraud, certificate failure, dynamic linking mismatch, data leak signal, or repeated SCA failures.

## Standard Workflow

All operations should follow this order:

```text
validate_schema
→ validate_tpp_role_and_certificate
→ validate_consent_and_scope
→ validate_sca_state_or_exemption
→ validate_business_guardrails
→ execute_connector_call
→ normalize_response
→ audit_event
→ return_minimized_output
```

## Standard Audit Fields

Each operation should record only minimal audit metadata unless a stricter local policy applies.

```yaml
audit_fields:
  - skill_id
  - operation
  - request_id
  - aspsp_id
  - tpp_role
  - consent_id_hash
  - payment_id_hash
  - psu_id_hash
  - timestamp
  - decision
  - normalized_error
  - risk_signal
```

## Standard Error Codes

Use normalized error codes instead of raw ASPSP errors:

```yaml
normalized_errors:
  - CONSENT_REQUIRED
  - CONSENT_EXPIRED
  - CONSENT_REVOKED
  - SCA_REQUIRED
  - SCA_FAILED
  - TPP_CERT_INVALID
  - TPP_ROLE_NOT_ALLOWED
  - SCOPE_NOT_ALLOWED
  - ACCOUNT_NOT_FOUND
  - ACCOUNT_NOT_ACCESSIBLE_ONLINE
  - ASPSP_UNAVAILABLE
  - RATE_LIMITED
  - USER_CONFIRMATION_REQUIRED
  - PAYMENT_REJECTED
  - PAYMENT_STATUS_UNKNOWN
  - PAYMENT_DYNAMIC_LINK_MISMATCH
  - INSUFFICIENT_FUNDS_SIGNAL
  - COF_NOT_SUPPORTED
  - FRAUD_RISK_BLOCK
  - INCIDENT_CANDIDATE
```

## Capability: psd2.consent_auth

### Purpose

Manage consent, SCA orchestration, OAuth/Redirect flows, eIDAS/mTLS checks, and TPP role validation.

### Allowed Roles

- AISP
- PISP
- CBPII

### Operations

- `create_ais_consent`
- `start_authorisation`
- `check_access`
- `revoke_consent`
- `refresh_access_if_allowed`

### Preconditions

- TPP identity verified by configured trust source.
- Certificate valid and bound to request where required.
- TPP role allows requested operation.
- Consent exists where required.
- SCA status is valid or exemption is allowed.

### Denied Actions

- Store PSU credentials.
- Store SCA secrets.
- Create broader consent than user-approved scope.
- Continue if role or certificate validation fails.

## Capability: psd2.ais

### Purpose

Read account information under active AIS consent.

### Required Role

AISP.

### Operations

- `list_accounts`
- `get_account_details`
- `get_balances`
- `get_transactions`

### Allowed Output

- accounts
- masked account identifiers
- account details allowed by consent
- balances allowed by consent
- booked and/or pending transactions allowed by consent

### Denied Actions

- Initiate payments.
- Modify account state.
- Read accounts outside consent.
- Read data outside requested date range.
- Return full identifiers unless required and allowed.

## Capability: psd2.pis

### Purpose

Initiate payment orders with explicit user instruction, SCA, and dynamic linking.

### Required Role

PISP.

### Operations

- `prepare_payment`
- `initiate_payment`
- `start_payment_authorisation`
- `get_payment_status`

### Dynamic Linking Fields

The following fields must be bound to SCA and immutable after SCA starts:

- amount
- currency
- creditor account
- creditor name
- remittance information, where applicable

### Denied Actions

- Initiate without explicit user confirmation.
- Change payment-critical fields after SCA starts.
- Claim payment is settled unless ASPSP status confirms final execution.
- Create recurring or future-dated payments unless explicitly requested and supported.

## Capability: psd2.cof_compliance

### Purpose

Confirm funds availability for a specific card-based payment transaction while enforcing data minimization.

### Required Role

CBPII or configured equivalent.

### Operation

- `confirm_funds`

### Output

```yaml
funds_available: true | false
response_valid_for: this_card_transaction_only
```

### Denied Actions

- Return balance.
- Return transaction history.
- Reserve, block, hold, or freeze funds.
- Use result for credit scoring or non-transaction purposes.
- Persist yes/no beyond immediate transaction processing unless policy explicitly requires auditable metadata.

## Capability: psd2.security_monitoring

### Purpose

Normalize errors, monitor security/fraud indicators, and create incident candidates for compliance review.

### Operations

- `normalize_error`
- `monitor_transaction_risk`
- `raise_incident_candidate`
- `create_fraud_reporting_event`

### Escalation Rules

Escalate to manual review when:

- SCA failures spike.
- eIDAS/mTLS certificate is invalid, expired, mismatched, or role-inconsistent.
- Payment fields change after SCA starts.
- Consent scope is exceeded.
- ASPSP dedicated interface availability/performance crosses configured incident threshold.
- Fraud, data leak, or unauthorized access signal appears.

## Implementation Notes

Do not hard-code AIS consent validity to 90 days. Keep these concepts separate:

```yaml
consent.valid_until: returned by ASPSP or configured by API profile
sca_renewal_due_at: calculated from SCA renewal policy
```

The Skill layer should not directly handle certificates, private keys, OAuth client secrets, PSU credentials, raw access tokens, or SCA secrets. Those must be handled by secure infrastructure components.
