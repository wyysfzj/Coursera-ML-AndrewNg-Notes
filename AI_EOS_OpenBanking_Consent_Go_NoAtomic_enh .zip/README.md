
# Open Banking Consent Setup

This is a simplified Open Banking Consent Setup service in Go, demonstrating AI‑EOS principles in action.

## Structure

- `cmd/server/main.go`: Service entry point.
- `internal/consent/`: Consent logic and data model.
- `internal/httpapi/`: API handler and routes.
- `api/openapi.yaml`: OpenAPI spec.
- `Makefile`: Simplifies common tasks.

## Running the Service

### 1. Start server
```bash
make run-atomic
```

### 2. Test with curl
```bash
curl -X POST http://localhost:8080/consents -d '{"customer_id": "123", "scopes": ["read"], "expires_at": "2030-01-01T00:00:00Z"}'
```

### 3. Run tests
```bash
make test
```
