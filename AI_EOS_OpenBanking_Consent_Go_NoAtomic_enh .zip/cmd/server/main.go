
package main

import (
	"log"
	"net/http"
	"openbanking-consent/internal/httpapi"
)

func main() {
	// Initialize handler
	handler := httpapi.NewHandler()

	// Setup server
	server := &http.Server{
		Addr:    ":8080",
		Handler: handler,
	}

	log.Println("Server started on :8080")
	err := server.ListenAndServe()
	if err != nil {
		log.Fatalf("Error starting server: %v", err)
	}
}
