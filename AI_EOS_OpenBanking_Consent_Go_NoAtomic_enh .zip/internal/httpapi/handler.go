
package httpapi

import (
	"encoding/json"
	"net/http"
	"openbanking-consent/internal/consent"
	"log"
)

type Handler struct {
	consentService *consent.Service
}

func NewHandler() *Handler {
	// Simple in-memory service (for now, without persistence layer)
	service := consent.NewService()
	return &Handler{consentService: service}
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" && r.URL.Path == "/consents" {
		h.createConsent(w, r)
	} else {
		http.NotFound(w, r)
	}
}

func (h *Handler) createConsent(w http.ResponseWriter, r *http.Request) {
	// Basic request parsing
	var req consent.CreateRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		return
	}

	// Call service to create consent
	resp, err := h.consentService.CreateConsent(req)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Respond with consent ID and status
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp)
}
