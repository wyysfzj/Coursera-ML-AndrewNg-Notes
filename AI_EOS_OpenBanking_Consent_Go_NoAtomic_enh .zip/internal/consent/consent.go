
package consent

import "time"

type Consent struct {
	ConsentID  string    `json:"consent_id"`
	CustomerID string    `json:"customer_id"`
	Scopes     []string  `json:"scopes"`
	ExpiresAt  time.Time `json:"expires_at"`
	Status     string    `json:"status"`
	CreatedAt  time.Time `json:"created_at"`
	UpdatedAt  time.Time `json:"updated_at"`
}

type CreateRequest struct {
	CustomerID string   `json:"customer_id"`
	Scopes     []string `json:"scopes"`
	ExpiresAt  string   `json:"expires_at"` // RFC3339 format
}
