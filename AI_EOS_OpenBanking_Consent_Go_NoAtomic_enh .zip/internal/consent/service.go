
package consent

import (
	"errors"
	"time"
)

var (
	ErrInvalidRequest = errors.New("invalid request")
)

type Service struct {
	// In-memory consent store (for simplicity)
	consents map[string]Consent
}

func NewService() *Service {
	return &Service{
		consents: make(map[string]Consent),
	}
}

func (s *Service) CreateConsent(req CreateRequest) (Consent, error) {
	// Basic validation
	expiresAt, err := time.Parse(time.RFC3339, req.ExpiresAt)
	if err != nil {
		return Consent{}, ErrInvalidRequest
	}

	// Generate consent ID (using a timestamp for simplicity)
	consentID := "consent_" + time.Now().Format("20060102_150405")

	// Create consent object
	consent := Consent{
		ConsentID:  consentID,
		CustomerID: req.CustomerID,
		Scopes:     req.Scopes,
		ExpiresAt:  expiresAt,
		Status:     "AWAITING_AUTHORIZATION",
		CreatedAt:  time.Now(),
		UpdatedAt:  time.Now(),
	}

	// Store consent
	s.consents[consentID] = consent

	return consent, nil
}
