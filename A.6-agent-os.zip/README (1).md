# Codex 6-Agent Team OS

A project-scoped Codex scaffold that turns a custom 6-agent team into a **team operating system** instead of a loose set of personas.

This scaffold is designed to fix the most common failure modes in role-based Codex setups:

1. **Roles are too wide** → each role has a narrow contract, explicit inputs, and explicit outputs.
2. **Permissions and responsibilities conflict** → read-heavy roles stay read-only; only one implementation role writes code at a time.
3. **No artifact contract** → every task lives under `.codex/tasks/<TASK_ID>/` with gated files and statuses.
4. **AGENTS.md / Skills / MCP / worktrees / monitor are underused** → the scaffold splits durable rules, reusable workflows, external tools, and runtime orchestration into the right layers.

## What is included

```text
AGENTS.md
.codex/
  config.toml
  requirements.example.toml
  mcp.project.example.toml
  agents/
    team_lead.toml
    architect.toml
    be_developer.toml
    fe_developer.toml
    tester.toml
    reviewer.toml
    native-explorer.toml
    native-monitor.toml
  scripts/
    new-task.sh
    check-gates.py
    create-worktree.sh
  templates/
    task/
      00-task.md
      10-plan.md
      20-architecture.md
      21-openapi.yaml
      30-implement.md
      40-documentation.md
      50-test-plan.md
      60-test-report.md
      70-review.md
      80-release-checklist.md
.agents/
  skills/
    contract-bootstrap/
    docs-research/
    browser-evidence/
    validation-gate/
    release-synthesis/
    worktree-bootstrap/
PROMPTS.md
```

## Operating model

### Layer 1: durable repository guidance
Keep repo-wide, always-on rules in `AGENTS.md`.

### Layer 2: reusable workflows
Put focused, repeatable jobs in `.agents/skills/*`.

### Layer 3: runtime orchestration
Let Codex spawn the 6 custom roles plus tuned native roles (`explorer`, `monitor`) from `.codex/config.toml`.

### Layer 4: file-based contract
Every non-trivial task gets a task folder:

```text
.codex/tasks/TASK-YYYYMMDD-short-slug/
  00-task.md
  10-plan.md
  20-architecture.md      # optional if no architecture change
  21-openapi.yaml         # optional if no API change
  30-implement.md
  40-documentation.md
  50-test-plan.md
  60-test-report.md
  70-review.md
  80-release-checklist.md
```

## The 6 custom roles

| Role | Default write access | Primary job | Must not do |
|---|---:|---|---|
| `team_lead` | docs/artifacts | plan, gate, synthesize, assign the single writer | broad source edits |
| `architect` | no | architecture, contracts, data model, risks | implementation |
| `be_developer` | yes | backend code + closest backend tests for the active milestone | frontend work, broad refactors |
| `fe_developer` | yes | frontend code + closest frontend tests for the active milestone | backend work, broad refactors |
| `tester` | no | test plan, validation audit, failure triage, coverage gaps | editing code or tests |
| `reviewer` | no | final correctness/security/regression gate | style-only review noise |

Native `explorer` is tuned for fast read-only code mapping. Native `monitor` is tuned for long-running commands, polling, and waiting.

## One-writer rule

This scaffold intentionally separates **read-heavy** roles from **write-heavy** roles.

- `team_lead`, `architect`, `tester`, `reviewer`, `explorer` should stay read-heavy.
- Only one implementation role should edit source code at a time.
- If both backend and frontend changes are needed, split the task into serial milestones.
- For parallel work, prefer parallel **reading** and **evidence gathering**. If you need true parallel writing, use separate worktrees and merge deliberately later.

## Recommended task lifecycle

1. Create a task folder with `contract-bootstrap` or `.codex/scripts/new-task.sh`.
2. Fill `00-task.md` and `10-plan.md`.
3. If the task changes architecture, APIs, or data models, run `architect` and materialize `20-architecture.md` and optionally `21-openapi.yaml`.
4. Write `30-implement.md` to define the active milestone, allowed edit scope, and validation commands.
5. Start exactly one writer: `be_developer` or `fe_developer`.
6. Use native `monitor` for long-running build/test/polling tasks.
7. Ask `tester` to produce `50-test-plan.md` and `60-test-report.md`.
8. Ask `reviewer` to produce `70-review.md` or use `/review` as an extra gate.
9. Finish with `80-release-checklist.md`.

## Installation

### Option A: copy the scaffold into a repository
From your repository root, copy the contents of this bundle into the repo root and commit them.

### Option B: merge selectively
If you already have `.codex/` or `AGENTS.md`, merge these parts first:

- `AGENTS.md`
- `.codex/config.toml`
- `.codex/agents/*.toml`
- `.codex/templates/task/*`
- `.agents/skills/*`

## First-time setup checklist

1. Trust the project so Codex loads project-scoped `.codex/config.toml`.
2. Review `AGENTS.md` and fill in repo-native commands if they are known.
3. Merge `.codex/mcp.project.example.toml` into your user or project `config.toml` if you use docs or browser MCP servers.
4. Run a verification prompt such as:
   - `codex --ask-for-approval never "Summarize the current instructions."`
   - `codex --ask-for-approval never "Show which instruction files are active."`
5. Start Codex from the repository root.

## Suggested first prompt

See `PROMPTS.md`.

## Notes

- This scaffold assumes Codex is used in a **trusted Git repository**.
- The scaffold is project-scoped by default. If you want a global version, adapt the files under `~/.codex/`.
- The role configs are intentionally conservative. Tighten or relax them once you observe your team’s real usage patterns.
