package com.hsbc.openbanking.smartmockexecutor.admin;

import com.hsbc.openbanking.smartmockexecutor.common.model.MockEndpointDefinition;
import com.hsbc.openbanking.smartmockexecutor.core.MockEndpointManager;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@RestController
public class OpenApiImportController {

    private final MockEndpointManager manager;

    public OpenApiImportController(MockEndpointManager manager) {
        this.manager = manager;
    }

    @PostMapping(value = "/admin/dev-ops/openapi/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String,Object> importOpenApi(@RequestParam("file") MultipartFile file) throws Exception {
        // MVP: create one demo endpoint from uploaded file name (placeholder for parser)
        String name = file.getOriginalFilename();
        String script = """
        import com.hsbc.openbanking.smartmockexecutor.script.Req
        import com.hsbc.openbanking.smartmockexecutor.script.Resp
        import com.hsbc.openbanking.smartmockexecutor.func.FuncFacade
        class DemoScript {
          public Object handle(Req $req, Resp $resp, FuncFacade $func) {
            $resp.status = 200
            $resp.headers.put('content-type','application/json')
            $resp.body = ['imported':true,'file':'""" + name + """']
            return null
          }
        }
        """;

        MockEndpointDefinition def = MockEndpointDefinition.builder()
                .id(System.currentTimeMillis())
                .projectId(1L)
                .groupId(1L)
                .method("GET")
                .path("/demo/" + name.replaceAll("[^a-zA-Z0-9]","-"))
                .consumes("*/*")
                .scriptSource(script)
                .validateSchema(false)
                .activeForward(false)
                .build();

        manager.register(def);
        return Map.of("status","imported","endpoint", def.getPath());
    }
}
