package com.hsbc.openbanking.smartmockexecutor.common.dto;
import lombok.Builder;
import lombok.Getter;

@Getter @Builder
public class JsonTemplateDefinition {
    private String name;
    private String json;
}
