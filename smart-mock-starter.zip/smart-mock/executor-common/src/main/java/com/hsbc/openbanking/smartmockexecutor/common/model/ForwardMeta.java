package com.hsbc.openbanking.smartmockexecutor.common.model;

import lombok.Builder;
import lombok.Getter;
import java.util.Map;

@Getter
@Builder
public class ForwardMeta {
    private String targetUrlTemplate; // e.g. https://{domain}/v1/payments/{id}
    private Map<String, String> headers;
    private int timeoutMs;
    private String methodOverride; // optional
}
