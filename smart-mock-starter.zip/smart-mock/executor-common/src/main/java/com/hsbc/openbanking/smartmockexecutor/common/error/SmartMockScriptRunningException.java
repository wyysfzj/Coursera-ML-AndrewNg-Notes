package com.hsbc.openbanking.smartmockexecutor.common.error;

import com.hsbc.openbanking.smartmockexecutor.common.model.HandlerExecutionMeta;
import java.util.Map;

public class SmartMockScriptRunningException extends BaseSmartMockException {
    public SmartMockScriptRunningException(String msg, HandlerExecutionMeta meta, Throwable cause) {
        super(msg, meta, 500, Map.of(), Map.of("code","script_error","message", msg), cause);
    }
}
