package com.hsbc.openbanking.smartmockexecutor.common.error;

import com.hsbc.openbanking.smartmockexecutor.common.model.HandlerExecutionMeta;
import java.util.Map;

public class SmartMockInterruptException extends BaseSmartMockException {
    public SmartMockInterruptException(int status, Map<String,String> headers, Object body, HandlerExecutionMeta meta) {
        super("interrupt", meta, status, headers, body, null);
    }
}
