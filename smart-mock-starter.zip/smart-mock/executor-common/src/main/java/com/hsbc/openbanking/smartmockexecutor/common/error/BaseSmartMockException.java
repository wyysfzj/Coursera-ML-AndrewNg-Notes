package com.hsbc.openbanking.smartmockexecutor.common.error;

import com.hsbc.openbanking.smartmockexecutor.common.model.HandlerExecutionMeta;
import lombok.Getter;

import java.util.Map;

@Getter
public class BaseSmartMockException extends RuntimeException {
    private final HandlerExecutionMeta meta;
    private final int status;
    private final Map<String,String> headers;
    private final Object body;

    public BaseSmartMockException(String message, HandlerExecutionMeta meta, int status, Map<String,String> headers, Object body, Throwable cause) {
        super(message, cause);
        this.meta = meta;
        this.status = status;
        this.headers = headers;
        this.body = body;
    }
}
