package com.hsbc.openbanking.smartmockexecutor.common.error;

import com.hsbc.openbanking.smartmockexecutor.common.model.HandlerExecutionMeta;
import java.util.Map;

public class SmartMockBusinessException extends BaseSmartMockException {
    public SmartMockBusinessException(String msg, HandlerExecutionMeta meta, int status, Object body) {
        super(msg, meta, status, Map.of(), body, null);
    }
}
