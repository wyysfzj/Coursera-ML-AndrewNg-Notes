package com.hsbc.openbanking.smartmockexecutor.common.model;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
public class HandlerExecutionMeta {
    private Long endpointId;
    private Long projectId;
    private Long groupId;
    private String wholeUrl;
    private boolean activeForward;
    private String correlationId;
    private long createdAtEpochMs;
}
