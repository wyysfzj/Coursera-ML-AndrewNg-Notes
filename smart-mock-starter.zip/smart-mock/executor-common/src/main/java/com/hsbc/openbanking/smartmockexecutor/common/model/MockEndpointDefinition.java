package com.hsbc.openbanking.smartmockexecutor.common.model;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import java.util.List;

@Getter
@Builder
@ToString
public class MockEndpointDefinition {
    private Long id;
    private Long projectId;
    private Long groupId;
    private String method;
    private String path;
    private String consumes;  // e.g. application/json
    private String scriptSource;
    private boolean validateSchema;
    private boolean activeForward;
    private ForwardMeta forwardMeta;
    private List<String> schemaRefs;
}
