# Smart Mock Execution Engine (Starter)

This is a **starter multi-module Gradle project** for the Smart Mock Execution Engine.
It mirrors the structure described in `Smart-Mock-Execution-Engine-Overview.md` and
includes initial scaffolding for core managers, dynamic mapping, Groovy execution,
admin endpoints, and Liquibase.

## Modules
- `executor-common`: shared DTOs & error types
- `executor-core`: runtime engine (handlers, caches, Groovy, forward proxy)
- `executor-admin`: Spring Boot app exposing admin APIs and bootstrapping the engine

## Build & Run
```bash
# run with a local Gradle
./gradlew :executor-admin:bootRun
```

## Import sample OpenAPI
```bash
curl -X POST http://localhost:8080/admin/dev-ops/openapi/import       -H "Content-Type: multipart/form-data"       -F "file=@samples/openapi-sample.yaml"
```
