package com.hsbc.openbanking.smartmockexecutor.script;

import groovy.lang.GroovyClassLoader;

public class GroovyUtil {
    private final GroovyClassLoader loader = new GroovyClassLoader();

    public Class<?> compile(String source) {
        return loader.parseClass(source);
    }
}
