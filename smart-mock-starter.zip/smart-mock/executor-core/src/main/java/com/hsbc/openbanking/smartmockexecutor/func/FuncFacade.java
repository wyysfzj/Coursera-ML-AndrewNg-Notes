package com.hsbc.openbanking.smartmockexecutor.func;

import java.util.Map;

import com.hsbc.openbanking.smartmockexecutor.common.error.SmartMockInterruptException;
import com.hsbc.openbanking.smartmockexecutor.common.model.HandlerExecutionMeta;

public class FuncFacade {
    private final HandlerExecutionMeta meta;
    public FuncFacade(HandlerExecutionMeta meta) {
        this.meta = meta;
    }

    public void error(int status, Map<String,String> headers, Object body) {
        throw new SmartMockInterruptException(status, headers, body, meta);
    }

    public Templates template() {
        return new Templates();
    }

    // Minimal stub
    public static class Templates {
        public Object json(String name) {
            // TODO: load from cache/DB; return minimal placeholder
            return Map.of("template", name, "ok", true);
        }
    }
}
