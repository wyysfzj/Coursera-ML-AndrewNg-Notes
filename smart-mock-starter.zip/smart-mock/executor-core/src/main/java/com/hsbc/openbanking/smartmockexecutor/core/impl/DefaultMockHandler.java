package com.hsbc.openbanking.smartmockexecutor.core.impl;

import com.hsbc.openbanking.smartmockexecutor.common.error.BaseSmartMockException;
import com.hsbc.openbanking.smartmockexecutor.common.error.SmartMockScriptRunningException;
import com.hsbc.openbanking.smartmockexecutor.common.model.HandlerExecutionMeta;
import com.hsbc.openbanking.smartmockexecutor.func.FuncFacade;
import com.hsbc.openbanking.smartmockexecutor.script.EndpointHandlerScriptManager;
import com.hsbc.openbanking.smartmockexecutor.script.Req;
import com.hsbc.openbanking.smartmockexecutor.script.Resp;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

public class DefaultMockHandler {
    private static final Logger log = LoggerFactory.getLogger(DefaultMockHandler.class);
    private final long endpointId;
    private final String functionName;
    private final EndpointHandlerScriptManager scriptMgr;
    private final HandlerExecutionMeta meta;

    public DefaultMockHandler(long endpointId, String functionName, EndpointHandlerScriptManager scriptMgr, HandlerExecutionMeta meta) {
        this.endpointId = endpointId;
        this.functionName = functionName;
        this.scriptMgr = scriptMgr;
        this.meta = meta;
    }

    public void doMockHandling(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Resp r = new Resp();
        try {
            Map<String,String> headers = new HashMap<>();
            Enumeration<String> h = req.getHeaderNames();
            while (h.hasMoreElements()) {
                String k = h.nextElement();
                headers.put(k, req.getHeader(k));
            }
            var request = new Req(req.getMethod(), req.getRequestURI(), headers, req.getParameterMap(), null /* TODO parse body */);
            var func = new FuncFacade(meta);
            scriptMgr.invoke(endpointId, functionName, request, r, func);
            // write response
            resp.setStatus(r.status);
            r.headers.forEach(resp::setHeader);
            if (r.body != null) {
                resp.setContentType(r.headers.getOrDefault("content-type", "application/json"));
                resp.getWriter().write(String.valueOf(com.fasterxml.jackson.databind.json.JsonMapper.builder().build().valueToTree(r.body)));
            }
        } catch (BaseSmartMockException e) {
            resp.setStatus(e.getStatus());
            e.getHeaders().forEach(resp::setHeader);
            if (e.getBody() != null) {
                resp.setContentType("application/json");
                resp.getWriter().write(String.valueOf(com.fasterxml.jackson.databind.json.JsonMapper.builder().build().valueToTree(e.getBody())));
            }
        } catch (Exception ex) {
            throw new SmartMockScriptRunningException(ex.getMessage(), meta, ex);
        }
    }
}
