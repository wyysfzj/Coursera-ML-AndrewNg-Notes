package com.hsbc.openbanking.smartmockexecutor.script;

import java.util.HashMap;
import java.util.Map;

public class Resp {
    public int status = 200;
    public final Map<String,String> headers = new HashMap<>();
    public Object body;

    public Resp status(int s) { this.status = s; return this; }
    public Resp header(String k, String v) { headers.put(k, v); return this; }
    public Resp body(Object b) { this.body = b; return this; }
}
