package com.hsbc.openbanking.smartmockexecutor.script;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.hsbc.openbanking.smartmockexecutor.func.FuncFacade;

public class EndpointHandlerScriptManager {
    private final GroovyUtil groovy = new GroovyUtil();
    private final Map<Long, Class<?>> cache = new ConcurrentHashMap<>();

    public Class<?> loadOrCompile(long endpointId, String src) {
        return cache.computeIfAbsent(endpointId, id -> groovy.compile(src));
    }

    public Class<?> swap(long endpointId, String src) {
        var old = cache.get(endpointId);
        var compiled = groovy.compile(src);
        cache.put(endpointId, compiled);
        return old;
    }

    public Object invoke(long endpointId, String functionName, Req req, Resp resp, FuncFacade func) throws Exception {
        Class<?> cls = cache.get(endpointId);
        Object instance = cls.getDeclaredConstructor().newInstance();
        Method m = cls.getMethod(functionName, Req.class, Resp.class, FuncFacade.class);
        return m.invoke(instance, req, resp, func);
    }
}
