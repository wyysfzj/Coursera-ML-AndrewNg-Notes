package com.hsbc.openbanking.smartmockexecutor.core;

import com.hsbc.openbanking.smartmockexecutor.common.model.HandlerExecutionMeta;
import com.hsbc.openbanking.smartmockexecutor.common.model.MockEndpointDefinition;
import com.hsbc.openbanking.smartmockexecutor.core.impl.DefaultMockHandler;
import com.hsbc.openbanking.smartmockexecutor.script.EndpointHandlerScriptManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

@Component
public class MockEndpointManager {

    private final RequestMappingHandlerMapping mapping;
    private final EndpointHandlerScriptManager scripts = new EndpointHandlerScriptManager();
    private final Map<Long, ReentrantLock> locks = new ConcurrentHashMap<>();

    @Autowired
    public MockEndpointManager(RequestMappingHandlerMapping mapping) {
        this.mapping = mapping;
    }

    private ReentrantLock lock(Long id) {
        return locks.computeIfAbsent(id, k -> new ReentrantLock());
    }

    public void register(MockEndpointDefinition def) {
        lock(def.getId()).lock();
        try {
            // compile once
            scripts.loadOrCompile(def.getId(), def.getScriptSource());

            var meta = HandlerExecutionMeta.builder()
                    .endpointId(def.getId())
                    .projectId(def.getProjectId())
                    .groupId(def.getGroupId())
                    .wholeUrl(def.getPath())
                    .activeForward(def.isActiveForward())
                    .createdAtEpochMs(System.currentTimeMillis())
                    .build();

            var handler = new DefaultMockHandler(def.getId(), "handle", scripts, meta);
            RequestMappingInfo info = RequestMappingInfo
                    .paths(def.getPath())
                    .methods(org.springframework.http.HttpMethod.valueOf(def.getMethod()))
                    .build();

            Method method = DefaultMockHandler.class.getMethod("doMockHandling",
                    jakarta.servlet.http.HttpServletRequest.class,
                    jakarta.servlet.http.HttpServletResponse.class);

            mapping.registerMapping(info, handler, method);
        } catch (Exception e) {
            throw new RuntimeException("Failed to register endpoint " + def.getId(), e);
        } finally {
            lock(def.getId()).unlock();
        }
    }
}
