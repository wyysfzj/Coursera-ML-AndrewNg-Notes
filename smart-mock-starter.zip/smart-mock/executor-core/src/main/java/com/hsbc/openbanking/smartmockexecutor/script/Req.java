package com.hsbc.openbanking.smartmockexecutor.script;

import java.util.Map;

public class Req {
    public final String method;
    public final String path;
    public final Map<String, String> headers;
    public final Map<String, String[]> query;
    public final Object body;

    public Req(String method, String path, Map<String,String> headers, Map<String,String[]> query, Object body) {
        this.method = method;
        this.path = path;
        this.headers = headers;
        this.query = query;
        this.body = body;
    }
}
