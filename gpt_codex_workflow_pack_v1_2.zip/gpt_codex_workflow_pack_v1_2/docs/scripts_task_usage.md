# scripts/task.sh 使用说明（v1.2）

目的：统一每条 task 的执行入口，自动创建 artifacts/<TASK-ID>/ 并生成 summary 模板。

推荐顺序：
1) ./scripts/task.sh <TASK-ID> "<short desc>"
2) ./scripts/evidence_run.sh <TASK-ID> lint ./scripts/run_lint.sh
3) ./scripts/evidence_run.sh <TASK-ID> test ./scripts/run_test.sh
4) ./scripts/evidence_run.sh <TASK-ID> e2e  ./scripts/run_e2e.sh
5) ./scripts/evidence_finalize.sh <TASK-ID>
6) 填写 artifacts/<TASK-ID>/summary.md，并贴到 PR
