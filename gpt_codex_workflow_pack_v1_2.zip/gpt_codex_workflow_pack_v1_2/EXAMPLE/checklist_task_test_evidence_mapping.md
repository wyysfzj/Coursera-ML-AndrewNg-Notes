# EXAMPLE：Checklist ↔ Tasks ↔ Tests ↔ Evidence 映射示例（v1.2）

| AC-ID | 验收项 | Task(s) | Test(s) | Evidence |
|---|---|---|---|---|
| AC-01 | 服务健康检查可用 | API-EX-01 | tests/test_healthz.py | artifacts/API-EX-01/ |
| AC-02 | 关键 E2E 旅程通过 | E2E-01 | scripts/run_e2e.sh | artifacts/E2E-01/ |

建议：
- Evidence 路径作为 Review 入口
- 失败时新增 BUG-FIX task，并产生新的 artifacts/BUG-FIX-xx
