# PR 模板（建议）

## 关联 TASK
- TASK-ID: <...>
- 任务文件: tasks/.../<TASK-ID>_*.md

## 变更摘要
- ...

## 验证
- Lint: ✅（见 Evidence）
- Test: ✅
- E2E/Contract: ✅ / N/A

## Evidence Pack
- artifacts/<TASK-ID>/
  - summary.md
  - outputs/
  - git/diff.patch
