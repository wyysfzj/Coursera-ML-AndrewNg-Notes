# MDD（Minimum Design Doc）模板 v1.2

Doc ID: <...>  
Owner: <...>  
Status: Draft | Approved  
Date:

## 1. Goal
## 2. Non-goals
## 3. Contract / Interface
## 4. Data & State（可选）
## 5. Security & Privacy
## 6. Observability
## 7. Performance / Resilience
## 8. Rollout / Backout
## 9. Acceptance（Checklist ↔ Tests ↔ Tasks）
