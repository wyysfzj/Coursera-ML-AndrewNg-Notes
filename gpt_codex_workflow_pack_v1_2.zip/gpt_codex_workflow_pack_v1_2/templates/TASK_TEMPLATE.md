# TASK（Atomic Task 模板 v1.2）

TASK-ID: <...>  
Owner: <...>  
Status: TODO | DOING | DONE  
Priority: P0 | P1 | P2  
Scope: MVP | Phase-2 | Refactor  
Project Type: Backend/API | Microservice | Mobile/SDK | Infra/Platform

## 1. 目标（Goal）
（可验证能力，1-3 句）

## 2. 非目标（Non-Goals）
（防止发散）

## 3. 约束（Constraints）
- 遵守 AGENTS.md（atomic task、禁止发散、证据回填、质量门禁）
- Contract/Data/Permission 模式（若适用）
- 禁止项（例如：No schema changes / No new deps）

## 4. 实现要求（Implementation Notes）
- 影响模块/文件（尽量少）：
- 核心行为：
- 边界条件/错误语义：
- 安全/隐私（如涉及）：

## 5. 验收标准（Acceptance）
必须包含：
- Lint：`./scripts/run_lint.sh`
- Test：`./scripts/run_test.sh`
- E2E/Contract（如适用）：`./scripts/run_e2e.sh`

## 6. Evidence（必须）
- 运行 `./scripts/evidence_finalize.sh <TASK-ID>`
- 附上 `artifacts/<TASK-ID>/summary.md` 链接/内容
