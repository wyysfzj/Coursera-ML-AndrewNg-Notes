# Codex 执行 Prompt 模板（FPMS 风格 v1.2）

你是一个严格遵守仓库最高规则（AGENTS.md）的 coding 代理。  
请只实现 **一个** atomic task：`<TASK-ID>`。除非任务允许，否则禁止扩展范围。

## 目标（Goal）
<1-3 句，必须可验证>

## 硬性约束（Hard Rules）
- 必须遵守 `AGENTS.md`（atomic task、禁止发散、证据回填、质量门禁）。
- 禁止引入新依赖/升级依赖（除非任务明确要求）。
- 禁止跨模块重构/全仓格式化；只做最小必要改动。
- 运行命令必须通过 `scripts/evidence_run.sh` 执行（记录证据）。

## 允许修改的文件（白名单）
- `<path/to/file1>`
- `<path/to/file2>`
> 若必须修改白名单外文件：停止并说明原因，不要自行扩展。

## 实现要求
- <行为 1>
- <行为 2>
- 边界条件/错误处理：<...>

## 验证（必须执行并通过）
依次运行（用 evidence wrapper）：
1) `./scripts/evidence_run.sh <TASK-ID> lint ./scripts/run_lint.sh`
2) `./scripts/evidence_run.sh <TASK-ID> test ./scripts/run_test.sh`
3) `./scripts/evidence_run.sh <TASK-ID> e2e  ./scripts/run_e2e.sh`（如适用）

## 完成收尾（必须）
- `./scripts/evidence_finalize.sh <TASK-ID>`
- 把 `artifacts/<TASK-ID>/summary.md` 填好（按模板）

## 输出回填（必须）
- 变更摘要（3–8 条）
- 修改的文件列表
- Evidence Pack 路径：`artifacts/<TASK-ID>/`
- 若失败：贴完整错误日志（从 artifacts/outputs/ 复制）
