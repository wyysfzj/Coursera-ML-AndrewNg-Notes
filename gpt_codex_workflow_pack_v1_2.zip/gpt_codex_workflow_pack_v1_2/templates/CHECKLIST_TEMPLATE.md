# Acceptance Checklist（模板 v1.2）

| AC-ID | 验收项 | 覆盖范围 | 验证方法 | 对应 Task(s) | 对应 Test(s) | Evidence |
|---|---|---|---|---|---|---|
| AC-01 | 示例：可启动且健康检查可用 | backend | `./scripts/run_test.sh` + `curl ...` | API-01 | tests/... | artifacts/API-01 |

规则：
- 每条 AC 必须有可运行验证
- 每条 AC 必须能定位到 task 与证据包
