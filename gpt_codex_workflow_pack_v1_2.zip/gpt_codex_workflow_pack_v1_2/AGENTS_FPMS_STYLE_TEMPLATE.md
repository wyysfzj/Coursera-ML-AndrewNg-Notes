# AGENTS_FPMS_STYLE_TEMPLATE.md（FPMS 风格强化模板 v1.2）

> 兼顾 FPMS 的强约束与跨项目可复用（Mobile/API/Microservice/无 DB/Infra）。  
> 重点新增：Evidence Pack 强制、标准 scripts 入口建议。

---

## 0. 项目参数（初始化时必须填写）

- Project Type: [ ] Backend/API  [ ] Microservice  [ ] Mobile/SDK  [ ] Infra/Platform
- Stack: <...>
- Data Store Mode: [ ] NONE  [ ] SQLITE  [ ] SQL  [ ] NOSQL  [ ] LOCAL
- Schema Change Policy: [ ] NO_SCHEMA_CHANGES  [ ] FORWARD_ONLY  [ ] FREE（需决策文档）
- Seed Policy: [ ] NO_SEED  [ ] IDEMPOTENT_SEED
- Contract Mode: [ ] OPENAPI  [ ] PROTO  [ ] EVENT_SCHEMA  [ ] NONE
- Permission/AuthZ Mode: [ ] INJECTABLE_DEP  [ ] SDK_GUARD  [ ] GATEWAY_POLICY  [ ] NONE
- Response Convention: [ ] FOLLOW_EXISTING_MODULE  [ ] RFC7807_PROBLEM_JSON  [ ] CUSTOM
- Commands（建议统一走 scripts）:
  - Lint: `./scripts/run_lint.sh`
  - Test: `./scripts/run_test.sh`
  - E2E: `./scripts/run_e2e.sh`（无则返回 0 并提示 N/A）

---

## 1. Hard Rules（FPMS 风格）

### 1.1 Atomic Task（强制）
- 一次只做一个 TASK-ID；PR/commit message：`<TASK-ID>: <short desc>`
- 任何额外需求：新建 task；不得夹带实现

### 1.2 Change Surface（强制）
- 禁止跨模块重构、全仓格式化、顺手升级依赖/配置/目录结构
- 只做最小必要改动；文件修改范围必须可解释

### 1.3 Contract First（按参数启用）
- 若 Contract Mode != NONE：先更新契约文件，再实现与测试

### 1.4 Data Rules（按 Data Store Mode 启用）
- NONE：禁止引入 DB；状态管理必须在 task 中说明
- SQLITE：遵循 SQLite 兼容规则（按项目具体化）
- SQL：若 FORWARD_ONLY，禁止编辑历史迁移
- NOSQL：必须声明幂等/一致性策略
- LOCAL：必须声明数据生命周期与隐私策略（Mobile 特别重要）

### 1.5 Permission/AuthZ（按参数启用）
- INJECTABLE_DEP：鉴权必须可注入、可测、lint-safe（写法需固化）
- 其他模式：必须在契约/架构文档中说明

### 1.6 Quality Gates（强制）
- Lint/Test/E2E 必须通过（任务明确豁免除外）
- 禁止带病前行

### 1.7 Evidence Pack（强制）
- 每个 task 必须生成 `artifacts/<TASK-ID>/`，并回填 `summary.md`
- 运行命令必须通过 `scripts/evidence_run.sh` 执行，以记录 stdout/stderr 与返回码

---

## 2. Codex/Copilot 执行协议（严格）

Codex 必须：
1) 仅修改 prompt 白名单文件（或停止请求扩展）
2) 用 `scripts/evidence_run.sh` 跑 lint/test/e2e
3) 完成后运行 `scripts/evidence_finalize.sh <TASK-ID>`
4) 回填 summary（变更摘要、风险、回滚点、证据路径）

---

## 3. Exception
任何违反 Hard Rules 的行为必须新建 `docs/decisions/DECISION-<id>.md` 并获 Owner 批准。
