#!/usr/bin/env bash
set -euo pipefail
echo "N/A: no e2e configured yet."
exit 0
