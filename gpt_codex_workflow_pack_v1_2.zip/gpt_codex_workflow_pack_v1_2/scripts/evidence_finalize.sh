#!/usr/bin/env bash
set -euo pipefail

TASK_ID="${1:-}"
if [[ -z "$TASK_ID" ]]; then
  echo "Usage: scripts/evidence_finalize.sh <TASK-ID>"
  exit 2
fi

ART_DIR="artifacts/${TASK_ID}"
GIT_DIR="${ART_DIR}/git"
ENV_DIR="${ART_DIR}/env"
mkdir -p "${GIT_DIR}" "${ENV_DIR}"

# git evidence
git rev-parse HEAD > "${GIT_DIR}/rev.txt" 2>/dev/null || true
git status --porcelain=v1 > "${GIT_DIR}/status.txt" 2>/dev/null || true
git diff > "${GIT_DIR}/diff.patch" 2>/dev/null || true

# env evidence (minimal + safe)
uname -a > "${ENV_DIR}/uname.txt" 2>/dev/null || true
( python --version 2>/dev/null || true ) > "${ENV_DIR}/python_version.txt" 2>&1 || true
( node --version 2>/dev/null || true ) > "${ENV_DIR}/node_version.txt" 2>&1 || true
( go version 2>/dev/null || true ) > "${ENV_DIR}/go_version.txt" 2>&1 || true
( java -version 2>/dev/null || true ) > "${ENV_DIR}/java_version.txt" 2>&1 || true
( swift --version 2>/dev/null || true ) > "${ENV_DIR}/swift_version.txt" 2>&1 || true

# summary skeleton (do not overwrite if exists)
SUM="${ART_DIR}/summary.md"
if [[ ! -f "${SUM}" ]]; then
cat > "${SUM}" <<'MD'
# Task Summary

- TASK-ID:
- Short description:
- Status: DONE

## Change Summary
- 

## Files Changed
- 

## Verification
- Lint: ✅ (log: artifacts/<TASK-ID>/outputs/...)
- Test: ✅
- E2E/Contract: ✅ / N/A

## Risks / Rollback
- 

## Evidence Pack
- artifacts/<TASK-ID>/
  - commands.jsonl
  - results.jsonl
  - outputs/
  - git/diff.patch
MD
fi

echo "Evidence finalized at: ${ART_DIR}"
