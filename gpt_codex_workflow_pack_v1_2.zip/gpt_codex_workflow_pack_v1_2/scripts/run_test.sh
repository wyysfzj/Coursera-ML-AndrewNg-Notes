#!/usr/bin/env bash
set -euo pipefail
echo "TODO: configure test command for this repo."
echo "Examples:"
echo "  pytest -q"
echo "  go test ./..."
echo "  mvn test"
echo "  xcodebuild test -scheme <scheme> -destination 'platform=iOS Simulator,name=iPhone 15'"
exit 1
