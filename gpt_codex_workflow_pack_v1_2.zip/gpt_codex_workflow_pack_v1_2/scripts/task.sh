#!/usr/bin/env bash
set -euo pipefail

TASK_ID="${1:-}"
DESC="${2:-}"

if [[ -z "$TASK_ID" ]]; then
  echo "Usage: scripts/task.sh <TASK-ID> \"<short desc>\""
  exit 2
fi

ART_DIR="artifacts/${TASK_ID}"
mkdir -p "${ART_DIR}/outputs" "${ART_DIR}/git" "${ART_DIR}/env"

if [[ -n "$DESC" ]]; then
  echo "$DESC" > "${ART_DIR}/desc.txt"
fi

echo "Task started: ${TASK_ID}"
echo "Artifacts: ${ART_DIR}"
echo
echo "Recommended sequence:"
echo "  ./scripts/evidence_run.sh ${TASK_ID} lint ./scripts/run_lint.sh"
echo "  ./scripts/evidence_run.sh ${TASK_ID} test ./scripts/run_test.sh"
echo "  ./scripts/evidence_run.sh ${TASK_ID} e2e  ./scripts/run_e2e.sh"
echo "  ./scripts/evidence_finalize.sh ${TASK_ID}"
