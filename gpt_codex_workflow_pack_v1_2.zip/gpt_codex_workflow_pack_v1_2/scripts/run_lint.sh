#!/usr/bin/env bash
set -euo pipefail
echo "TODO: configure lint command for this repo."
echo "Examples:"
echo "  ruff check ."
echo "  eslint ."
echo "  swiftlint"
echo "  ktlint"
exit 1
