# AGENTS.md（通用模板 v1.2）

> 复制到 repo root 并按项目类型填写“项目参数区”。  
> 本文件是最高规则：AGENTS.md > 其他约定。任何例外必须走 Exception。

---

## 0. 项目参数区（初始化必须填写）

- Project Type: [ ] Backend/API  [ ] Microservice  [ ] Mobile/SDK  [ ] Infra/Platform
- Language/Stack: <...>
- Data Store: [ ] None  [ ] SQLite  [ ] Postgres  [ ] MySQL  [ ] NoSQL  [ ] Local storage
- Contract: [ ] OpenAPI  [ ] Proto  [ ] Event schema  [ ] N/A
- Commands:
  - Lint: `<command or scripts/run_lint.sh>`
  - Test: `<command or scripts/run_test.sh>`
  - E2E: `<command or scripts/run_e2e.sh>`
- Evidence Pack:
  - Artifacts path: `artifacts/<TASK-ID>/`
  - Wrapper: `scripts/evidence_run.sh`

---

## 1. Hard Rules（不可违反）

1) Atomic Task Only（一次一条 task）
2) Scope Freeze（禁止夹带需求/重构）
3) Contract First（如适用）
4) Quality Gates Must Pass（lint/test/e2e 必须通过）
5) Dependency Discipline（禁随意加/升级依赖）
6) Security Baseline（不泄露 secrets/PII）
7) Data/Migration/Seed（如适用：forward-only、seed 幂等）
8) Evidence Required（必须生成 Evidence Pack，并回填 summary）

---

## 2. Execution Protocol（每个 task 必须回填）

- TASK-ID：
- 变更范围（文件列表）：
- 行为变化摘要：
- 验证命令（lint/test/e2e）：
- 验证结果（关键输出）：
- 风险与回滚点：
- Evidence Pack 路径：`artifacts/<TASK-ID>/`

---

## 3. Exception

任何违反 Hard Rules 的行为必须新增 `docs/decisions/DECISION-<id>.md` 并获 Owner 批准。
