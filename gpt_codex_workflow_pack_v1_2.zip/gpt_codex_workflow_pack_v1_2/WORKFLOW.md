# GPT + Codex/Copilot 协作开发流程（通用增强版）

版本：v1.2  
日期：2026-01-02（America/Los_Angeles）

本版本在 v1.1 的基础上新增“可落地的工程骨架”：
- 标准 `scripts/`：统一 lint/test/e2e/task 入口
- Evidence Pack：每个 TASK 自动生成可审计的交付证据包（logs/diff/env/summary）

---

## 1. 关键原则（不变）

- 先验收（Checklist/Contract）再实现
- 一次只做一个 atomic task（绑定 TASK-ID）
- 质量门禁必须通过（lint/test/e2e）
- 证据回填必须完整（Evidence Pack）

---

## 2. 新增：Evidence Pack（交付证据包）

### 2.1 为什么要 Evidence Pack
在 AI 协作场景中，“口头描述”不可审计、不可复现。Evidence Pack 将每个 task 的证据固化，便于：
- Code Review 与审计（知道改了什么、怎么验证的）
- 回归定位（失败时快速复现）
- 并行协作（不同人/不同代理产出的证据一致）

### 2.2 Evidence Pack 包含什么
每个 task 生成目录：`artifacts/<TASK-ID>/`
- `summary.md`：变更摘要、风险、回滚点（可直接贴 PR）
- `commands.jsonl`：运行的命令与返回码（结构化）
- `outputs/`：命令 stdout/stderr（逐条落盘）
- `git/`：`diff.patch`、`status.txt`、`rev.txt`
- `env/`：OS、工具版本、关键环境变量（可选白名单）

### 2.3 推荐工作流（强烈建议）
- 进入任务：`./scripts/task.sh <TASK-ID> "<short desc>"`
- 在提示下运行（或让 Codex 运行）：
  - `./scripts/run_lint.sh`
  - `./scripts/run_test.sh`
  - `./scripts/run_e2e.sh`（如适用）
- 完成后运行：`./scripts/evidence_finalize.sh <TASK-ID>`
- 将 `artifacts/<TASK-ID>/summary.md` 的内容复制到 PR 描述

---

## 3. 新增：统一命令入口（scripts / Makefile）

### 3.1 scripts（推荐）
- `scripts/run_lint.sh`：只跑 lint/format check
- `scripts/run_test.sh`：只跑 unit/integration
- `scripts/run_e2e.sh`：只跑 e2e/contract（无则 N/A）
- `scripts/task.sh`：启动任务，记录元数据，并提供“标准运行顺序”
- `scripts/evidence_run.sh`：以“可记录”的方式执行命令
- `scripts/evidence_finalize.sh`：固化 git diff/status/rev 与 summary 模板

### 3.2 Makefile（可选）
适合团队统一习惯 `make lint/test/e2e` 的仓库，可用变量覆盖具体命令。

---

## 4. 多项目类型适配（与 v1.1 一致）

- Backend/API：Contract First + error model + timeout/retry
- Microservice：契约 + 集成测试 + 依赖隔离（mock/contract）
- Mobile/SDK：public API surface + versioning + privacy
- Infra/Platform：plan/apply 可复现 + policy-as-code + 最小权限

---

## 5. 仍然强制的闭环

MDD → Atomic Tasks → Codex Prompts → Code + Tests → E2E/Contract → Acceptance Checklist → Evidence Pack

