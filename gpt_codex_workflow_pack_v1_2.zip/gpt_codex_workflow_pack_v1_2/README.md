# GPT + Codex/Copilot 开发加速包（通用增强版 v1.2）

v1.2 迭代目标：把 v1.1 的“流程与规则”进一步落地为“可直接拷贝复用的工程骨架”，降低新项目初始化成本。

## v1.2 新增内容
1) `scripts/` 标准入口骨架（lint/test/e2e + task wrapper）
2) Evidence Pack 自动落盘脚本（把 task 的证据、命令输出、diff、环境信息结构化保存到 `artifacts/`）
3) PR/任务回填模板（Markdown），确保提交物一致、可审计
4) `Makefile.template`（可选）统一开发入口：`make lint/test/e2e/task`（适配不同栈，通过变量覆盖）
5) 更细的“多项目类型参数化”说明：Backend/Microservice/Mobile/Infra

## 推荐用法（新项目 15 分钟落地）
1. 复制 `AGENTS_FPMS_STYLE_TEMPLATE.md` 到 repo root，改名 `AGENTS.md`，填写“项目参数区”
2. 复制 `templates/` 到 repo 的 `templates/`（或保持本结构）
3. 复制 `scripts/` 到 repo 的 `scripts/`，按项目修改命令
4. （可选）复制 `Makefile.template` 为 `Makefile`，配置 LINT_CMD/TEST_CMD/E2E_CMD
5. 开始写 MDD → 拆 tasks → 逐条 Codex prompt 执行
6. 每条 task 用 `./scripts/task.sh <TASK-ID> "<desc>"` 作为统一执行/证据入口

