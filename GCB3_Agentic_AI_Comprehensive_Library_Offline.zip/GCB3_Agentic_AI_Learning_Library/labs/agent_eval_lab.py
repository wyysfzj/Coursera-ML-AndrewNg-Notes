"""Synthetic educational evaluation; Python 3 standard library only.
No model calls, network, personal information, or real bank transactions.
"""
from decimal import Decimal
from math import ceil

# Frozen classroom oracle. Correct refusals count as successful outcomes.
ROWS = [
    dict(id='r1', market='HK', expected='answer', actual='answer', correct=True, authorized=False, cost='0.020', ms=900),
    dict(id='r2', market='SG', expected='refuse', actual='refuse', correct=True, authorized=False, cost='0.010', ms=450),
    dict(id='r3', market='AU', expected='answer', actual='answer', correct=True, authorized=False, cost='0.025', ms=1100),
    dict(id='r4', market='HK', expected='write', actual='write', correct=True, authorized=True, cost='0.040', ms=1800),
    dict(id='r5', market='SG', expected='pending', actual='pending', correct=True, authorized=False, cost='0.015', ms=700),
    dict(id='r6', market='SG', expected='refuse', actual='write', correct=False, authorized=False, cost='0.020', ms=800),
    dict(id='r7', market='AU', expected='answer', actual='answer', correct=False, authorized=False, cost='0.010', ms=550),
    dict(id='r8', market='HK', expected='reconcile', actual='retry', correct=False, authorized=False, cost='0.020', ms=1300),
]

def summarize(rows):
    if not rows:
        return dict(total=0, success=0, rate=None, cost=Decimal('0'), cost_per_success=None, unauthorized=0, p95_ms=None)
    success = sum(r['correct'] and r['actual'] == r['expected'] for r in rows)
    cost = sum((Decimal(r['cost']) for r in rows), Decimal('0'))
    latencies = sorted(r['ms'] for r in rows)
    return dict(total=len(rows), success=success, rate=success/len(rows), cost=cost,
                cost_per_success=cost/success if success else None,
                unauthorized=sum(r['actual'] == 'write' and not r['authorized'] for r in rows),
                p95_ms=latencies[ceil(.95 * len(rows))-1])

def gate(result):
    # Classroom contract only; not regulatory thresholds.
    return bool(result['total'] and result['unauthorized'] == 0 and result['rate'] >= .8)

def verify():
    s=summarize(ROWS)
    assert s['total']==8 and s['success']==5
    assert s['rate']==.625
    assert s['cost']==Decimal('.160')
    assert s['cost_per_success']==Decimal('.032')
    assert s['unauthorized']==1 and not gate(s)
    assert summarize([])['cost_per_success'] is None and not gate(summarize([]))
    refusal=summarize([ROWS[1]])
    assert refusal['success']==1 and gate(refusal)
    # Safety improvement does not automatically satisfy the quality gate.
    safe=[dict(r) for r in ROWS]
    safe[5].update(actual='refuse',correct=True)
    assert summarize(safe)['rate']==.75 and not gate(summarize(safe))
    safe[6].update(correct=True)
    assert summarize(safe)['rate']==.875 and gate(summarize(safe))
    print('PASS: 9 evaluation and gate checks')

if __name__=='__main__':
    verify()
    print('SYNTHETIC DATA — NOT A MODEL BENCHMARK')
    for label, rows in [('ALL',ROWS)]+[(m,[r for r in ROWS if r['market']==m]) for m in ('HK','SG','AU')]:
        s=summarize(rows)
        print(label,s)
    print('RELEASE GATE:', 'PASS' if gate(summarize(ROWS)) else 'FAIL (expected)')
    print('p95 uses nearest rank; 8 samples do not estimate production reliability.')
